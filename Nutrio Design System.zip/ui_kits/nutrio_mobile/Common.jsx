// Common.jsx — Shared Nutrio components (dark-first)
// Loaded after React + Babel + Icons.jsx
// Exports to window: NC, EASE, Press, MacroRing, MacroBar, StatTile,
// FoodLogRow, MealHeader, Chip, MonoChip, PrimaryButton, GhostButton,
// SectionTitle, ScreenHeader, Avatar, FAB, GlowRing, BgDots

const NC = {
  canvas: '#0E1110',
  surface: '#191E1B',
  raised: '#222824',
  sunken: '#141816',
  border: '#2A312D',
  borderStrong: '#353D38',
  bone: '#FBF9F0',
  bone100: '#F1EEDF',
  bone200: '#DAD6C5',
  bone300: '#B0AC9C',
  bone400: '#888679',
  ink400: '#6C746F',
  ink300: '#8E958F',
  ink500: '#4A534D',
  ink600: '#353D38',
  ink700: '#222824',
  lime300: '#C8FF5E',
  lime200: '#D4FF80',
  lime400: '#B5F03F',
  lime600: '#7BB014',
  lime700: '#5C8410',
  limeDeep: '#1F2814',
  limeGlow: 'rgba(200, 255, 94, 0.25)',
  peach300: '#FFC9A8',
  peach400: '#FFB088',
  peachDeep: '#2A1B12',
  carbs: '#FFB547',
  protein: '#C8FF5E',
  fat: '#FF9F73',
  fiber: '#5FE3B0',
  success: '#5FE3B0',
  warning: '#FFB547',
  danger: '#FF7A6B',
  info: '#7CB8FF',
};
const EASE = 'cubic-bezier(0.2, 0.8, 0.2, 1)';
const SPRING = 'cubic-bezier(0.32, 1.4, 0.5, 1)';
const MONO = "'Geist Mono', 'JetBrains Mono', 'SF Mono', Menlo, monospace";

// ─── Press wrapper ───────────────────────────────
function Press({ children, onClick, style = {}, as = 'div', spring = false }) {
  const [p, setP] = React.useState(false);
  const E = as;
  return (
    <E
      onPointerDown={() => setP(true)}
      onPointerUp={() => setP(false)}
      onPointerLeave={() => setP(false)}
      onClick={onClick}
      style={{
        transition: `transform 100ms ${spring ? SPRING : EASE}`,
        transform: p ? 'scale(0.96)' : 'scale(1)',
        cursor: onClick ? 'pointer' : 'default',
        userSelect: 'none', WebkitTapHighlightColor: 'transparent',
        ...style,
      }}>
      {children}
    </E>
  );
}

// ─── Background: dot grid (used on hero surfaces) ─
function BgDots({ opacity = 0.07, size = 14, style = {} }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none',
      backgroundImage: `radial-gradient(circle at 1px 1px, rgba(251,249,240,${opacity}) 1px, transparent 0)`,
      backgroundSize: `${size}px ${size}px`,
      ...style,
    }}/>
  );
}

// ─── Glow ring (radial halo behind ring) ─────────
function GlowRing({ size = 280, color = NC.limeGlow, blur = 8 }) {
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '50%',
      transform: 'translate(-50%, -50%)',
      width: size, height: size, borderRadius: '50%',
      background: `radial-gradient(circle, ${color}, rgba(200,255,94,0.06) 35%, transparent 70%)`,
      filter: `blur(${blur}px)`,
      pointerEvents: 'none',
    }}/>
  );
}

// ─── Count-up hook ───────────────────────────────
function useCountUp(target, duration = 900, deps = []) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    let raf, start;
    const tick = (t) => {
      if (!start) start = t;
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setV(Math.round(target * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, duration, ...deps]);
  return v;
}

// ─── MacroRing — the hero viz ────────────────────
function MacroRing({ kcal = 1420, goal = 2000, size = 220, animateKey = 0 }) {
  const animated = useCountUp(kcal, 900, [animateKey]);
  const pct = Math.min(1, animated / goal);
  const C = 2 * Math.PI * 90;
  const left = Math.max(0, goal - animated);
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <GlowRing size={size * 1.4} />
      <svg width={size} height={size} viewBox="0 0 200 200" style={{ transform: 'rotate(-90deg)', position: 'relative' }}>
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={NC.lime200}/>
            <stop offset="100%" stopColor={NC.lime600}/>
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="90" fill="none" stroke={NC.sunken} strokeWidth="12"/>
        <circle cx="100" cy="100" r="90" fill="none"
                stroke="url(#ringGrad)" strokeWidth="12" strokeLinecap="round"
                strokeDasharray={C} strokeDashoffset={C * (1 - pct)}
                style={{ transition: `stroke-dashoffset 900ms ${EASE}`, filter: `drop-shadow(0 0 6px ${NC.limeGlow})` }}/>
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', textAlign: 'center',
      }}>
        <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300 }}>
          Today · kcal
        </div>
        <div style={{
          fontFamily: MONO, fontSize: 52, fontWeight: 500, color: NC.bone,
          fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.04em',
          lineHeight: 1, marginTop: 6,
        }}>
          {animated.toLocaleString()}
        </div>
        <div style={{ fontFamily: MONO, fontSize: 10, color: NC.bone300, marginTop: 6, letterSpacing: '0.06em' }}>
          <span style={{ color: NC.lime300 }}>{left.toLocaleString()}</span> to go · {Math.round(pct * 100)}%
        </div>
      </div>
    </div>
  );
}

// ─── Macro bar (a single legend row) ─────────────
function MacroBar({ name, color, value, goal, unit = 'g' }) {
  const pct = Math.min(100, Math.round((value / goal) * 100));
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{ width: 8, height: 8, borderRadius: '50%', background: color, flexShrink: 0 }}/>
      <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone200, width: 52 }}>{name}</div>
      <div style={{ flex: 1, height: 5, background: NC.sunken, borderRadius: 99, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: pct + '%', background: color, borderRadius: 99, transition: `width 700ms ${EASE}` }}/>
      </div>
      <div style={{ fontFamily: MONO, fontSize: 11, color: NC.bone, width: 60, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
        {value}{unit}
      </div>
    </div>
  );
}

// ─── Section title ───────────────────────────────
function SectionTitle({ children, action, onAction }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 20px', marginBottom: 12 }}>
      <h2 style={{ margin: 0, fontFamily: MONO, fontSize: 10, fontWeight: 500, color: NC.bone300, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
        {children}
      </h2>
      {action && (
        <span onClick={onAction} style={{ fontFamily: MONO, fontSize: 10, color: NC.lime300, letterSpacing: '0.06em', cursor: 'pointer' }}>
          {action}
        </span>
      )}
    </div>
  );
}

// ─── Food log row ────────────────────────────────
function FoodLogRow({ name, sub, kcal, swatch = NC.peachDeep, icon, onClick }) {
  return (
    <Press onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 14px', background: NC.surface, borderRadius: 16,
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: 12, background: swatch,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        {icon || <NIcon name="apple" size={20} color={NC.peach400} />}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>{sub}</div>
        <div style={{ fontSize: 15, fontWeight: 500, color: NC.bone, marginTop: 3, letterSpacing: '-0.008em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontFamily: MONO, fontSize: 18, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em', lineHeight: 1 }}>{kcal}</div>
        <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.18em', color: NC.bone300, textTransform: 'uppercase', marginTop: 4 }}>kcal</div>
      </div>
    </Press>
  );
}

// ─── Meal header (date strip above food rows) ────
function MealHeader({ meal, kcal, time }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 24px 8px' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
        <span style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, color: NC.bone, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{meal}</span>
        {time && <span style={{ fontFamily: MONO, fontSize: 10, color: NC.bone400, letterSpacing: '0.06em' }}>· {time}</span>}
      </div>
      <span style={{ fontFamily: MONO, fontSize: 11, color: NC.bone200, fontVariantNumeric: 'tabular-nums' }}>
        {kcal} kcal
      </span>
    </div>
  );
}

// ─── Chip / MonoChip ─────────────────────────────
function Chip({ children, active, onClick }) {
  return (
    <Press onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '7px 14px', borderRadius: 999, fontSize: 13, fontWeight: 500,
      background: active ? NC.lime300 : NC.surface,
      color: active ? NC.canvas : NC.bone,
      border: active ? 'none' : `1px solid ${NC.border}`,
      whiteSpace: 'nowrap',
    }}>{children}</Press>
  );
}
function MonoChip({ children, accent }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', padding: '5px 10px', borderRadius: 6,
      fontFamily: MONO, fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
      background: accent ? NC.limeDeep : NC.surface,
      color: accent ? NC.lime300 : NC.bone200,
      border: accent ? '1px solid rgba(200,255,94,0.16)' : `1px solid ${NC.border}`,
    }}>{children}</span>
  );
}

// ─── Buttons ─────────────────────────────────────
function PrimaryButton({ children, onClick, icon, full }) {
  return (
    <Press onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      padding: '14px 22px', borderRadius: 14, background: NC.lime300, color: NC.canvas,
      fontSize: 15, fontWeight: 500, minHeight: 48, width: full ? '100%' : undefined,
      boxSizing: 'border-box', border: 'none',
      boxShadow: `0 0 0 1px ${NC.limeDeep}, 0 8px 24px ${NC.limeGlow}`,
    }}>
      {icon}{children}
    </Press>
  );
}
function GhostButton({ children, onClick, icon }) {
  return (
    <Press onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '12px 18px', borderRadius: 14, background: NC.surface,
      color: NC.bone, border: `1px solid ${NC.border}`,
      fontSize: 15, fontWeight: 500, minHeight: 44,
    }}>{icon}{children}</Press>
  );
}

// ─── Stat tile (modular grid card) ───────────────
function StatTile({ label, value, unit, delta, deltaType = 'neutral', accent }) {
  const deltaColors = {
    up:      { bg: '#2A1E0A',          fg: NC.warning },
    down:    { bg: NC.limeDeep,        fg: NC.lime300 },
    neutral: { bg: NC.raised,          fg: NC.bone200 },
  }[deltaType];
  return (
    <div style={{
      padding: 16, background: accent ? NC.limeDeep : NC.surface, borderRadius: 18,
      border: accent ? '1px solid rgba(200,255,94,0.16)' : 'none',
    }}>
      <div style={{ fontFamily: MONO, fontSize: 9, fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: accent ? NC.lime700 : NC.bone300 }}>
        {label}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 10 }}>
        <span style={{
          fontFamily: MONO, fontSize: 30, fontWeight: 500,
          color: accent ? NC.lime300 : NC.bone, fontVariantNumeric: 'tabular-nums',
          letterSpacing: '-0.03em', lineHeight: 1,
        }}>{value}</span>
        {unit && <span style={{ fontFamily: MONO, fontSize: 11, color: accent ? NC.lime600 : NC.bone300 }}>{unit}</span>}
      </div>
      {delta && (
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 3,
          marginTop: 10, padding: '2px 8px', borderRadius: 6,
          fontFamily: MONO, fontSize: 10, letterSpacing: '0.04em',
          background: deltaColors.bg, color: deltaColors.fg,
        }}>{delta}</div>
      )}
    </div>
  );
}

// ─── FAB (lime, with pulse halo) ─────────────────
function FAB({ onClick, icon }) {
  return (
    <Press onClick={onClick} spring style={{ display: 'inline-block', position: 'relative' }}>
      <div style={{
        width: 56, height: 56, borderRadius: '50%', background: NC.lime300,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: `0 0 0 6px rgba(200,255,94,0.15), 0 8px 24px ${NC.limeGlow}`,
      }}>
        {icon || <NIcon name="plus" size={24} color={NC.canvas} strokeWidth={2.2}/>}
      </div>
    </Press>
  );
}

// ─── Bottom tab bar (floating capsule) ───────────
function TabBar({ tab, onTab, onAdd }) {
  const Tab = ({ id, icon, label }) => {
    const active = tab === id;
    return (
      <Press onClick={() => onTab(id)} style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
        padding: '4px 8px', minWidth: 56,
      }}>
        <div style={{
          width: 46, height: 26, borderRadius: 99,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: active ? NC.limeDeep : 'transparent',
          transition: `background 200ms ${EASE}`,
        }}>
          <NIcon name={icon} size={20} color={active ? NC.lime300 : NC.bone300} strokeWidth={1.6}/>
        </div>
        <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.08em', color: active ? NC.lime300 : NC.bone300 }}>
          {label}
        </span>
      </Press>
    );
  };
  return (
    <div style={{
      position: 'absolute', bottom: 18, left: 14, right: 14, height: 72,
      background: 'rgba(20,24,22,0.88)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      borderRadius: 26,
      border: '1px solid rgba(255,255,255,0.06)',
      boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      padding: '0 8px', zIndex: 100,
    }}>
      <Tab id="today" icon="home" label="Today" />
      <Tab id="trends" icon="trends" label="Trends" />
      <Press onClick={onAdd} spring style={{ padding: 0, position: 'relative', top: -10 }}>
        <FAB onClick={onAdd} />
      </Press>
      <Tab id="recipes" icon="recipe" label="Recipes" />
      <Tab id="you" icon="user" label="You" />
    </div>
  );
}

// ─── Screen header ───────────────────────────────
function ScreenHeader({ greeting, date, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', padding: '56px 20px 16px' }}>
      <div>
        <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300 }}>{date}</div>
        <div style={{ fontSize: 26, fontWeight: 500, color: NC.bone, letterSpacing: '-0.018em', marginTop: 4 }}>{greeting}</div>
      </div>
      {right}
    </div>
  );
}

// ─── Avatar ──────────────────────────────────────
function Avatar({ initials = 'A', size = 36, onClick }) {
  return (
    <Press onClick={onClick} style={{
      width: size, height: size, borderRadius: '50%', background: NC.peachDeep,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: MONO, fontSize: size * 0.35, fontWeight: 500, color: NC.peach300,
      border: `1px solid ${NC.border}`,
    }}>{initials}</Press>
  );
}

// ─── Icon button (header tools) ──────────────────
function IconBtn({ icon, onClick, badge }) {
  return (
    <Press onClick={onClick} style={{
      width: 40, height: 40, borderRadius: 12, background: NC.surface,
      border: `1px solid ${NC.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative',
    }}>
      <NIcon name={icon} size={18} color={NC.bone} />
      {badge && <div style={{ position: 'absolute', top: 8, right: 8, width: 6, height: 6, borderRadius: '50%', background: NC.lime300 }}/>}
    </Press>
  );
}

Object.assign(window, {
  NC, EASE, SPRING, MONO,
  Press, BgDots, GlowRing, useCountUp,
  MacroRing, MacroBar, SectionTitle, FoodLogRow, MealHeader,
  Chip, MonoChip, PrimaryButton, GhostButton, StatTile,
  FAB, TabBar, ScreenHeader, Avatar, IconBtn,
});

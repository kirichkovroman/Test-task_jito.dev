// AddSheet.jsx — Bottom sheet for adding food

function AddSheet({ open, onClose, defaultMeal, onAdd }) {
  const [query, setQuery] = React.useState('');
  const [meal, setMeal]   = React.useState(defaultMeal || 'Snacks');
  const [selected, setSelected] = React.useState(null);
  const [serving, setServing] = React.useState(100);
  const inputRef = React.useRef(null);

  // Reset transient state on each open. Don't unmount — keep the sheet in the
  // tree so the transform transition has a stable element to animate against.
  React.useEffect(() => {
    if (open) {
      setMeal(defaultMeal || 'Snacks');
      setQuery(''); setSelected(null); setServing(100);
      const focusT = setTimeout(() => inputRef.current && inputRef.current.focus(), 350);
      return () => clearTimeout(focusT);
    }
  }, [open, defaultMeal]);

  const FOODS = [
    { name: 'Greek yogurt',         k100: 93,  p: 9,  c: 3.6, f: 5.0, fi: 0,  swatch: '#1d2a16' },
    { name: 'Banana',               k100: 89,  p: 1,  c: 23,  f: 0.3, fi: 2.6, swatch: '#2a1e0a' },
    { name: 'Grilled chicken',      k100: 165, p: 31, c: 0,   f: 3.6, fi: 0,  swatch: '#2a1b12' },
    { name: 'Brown rice',           k100: 111, p: 2.6,c: 23,  f: 0.9, fi: 1.8, swatch: '#1a1410' },
    { name: 'Avocado',              k100: 160, p: 2,  c: 9,   f: 15,  fi: 7,  swatch: '#1d2a16' },
    { name: 'Salmon (baked)',       k100: 208, p: 22, c: 0,   f: 13,  fi: 0,  swatch: '#2a1b12' },
  ].filter(f => !query || f.name.toLowerCase().includes(query.toLowerCase()));

  const calc = selected ? Math.round(selected.k100 * serving / 100) : 0;

  // Sheet is ALWAYS rendered; visibility + animation driven by `open`.
  return (
    <>
      {/* Scrim */}
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(6,8,7,0.6)',
        zIndex: 200,
        opacity: open ? 1 : 0,
        pointerEvents: open ? 'auto' : 'none',
        transition: `opacity 280ms ${EASE}`,
      }}/>
      {/* Sheet — explicitly anchored top+bottom so flex children behave */}
      <div style={{
        position: 'absolute', left: 0, right: 0,
        top: '12%', bottom: 0,
        background: NC.surface,
        borderRadius: '32px 32px 0 0',
        boxShadow: '0 -16px 40px rgba(0,0,0,0.6)',
        zIndex: 201, overflow: 'hidden',
        transform: open ? 'translateY(0)' : 'translateY(100%)',
        transition: `transform 320ms ${EASE}`,
        pointerEvents: open ? 'auto' : 'none',
        display: 'flex', flexDirection: 'column',
        minHeight: 0,
      }}>

        {/* Drag handle */}
        <div style={{ padding: '10px 0 4px', display: 'flex', justifyContent: 'center' }}>
          <div style={{ width: 38, height: 4, borderRadius: 99, background: NC.border }}/>
        </div>

        {/* Header */}
        <div style={{ padding: '8px 20px 14px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300 }}>Add to {meal.toLowerCase()}</div>
            <div style={{ fontSize: 22, fontWeight: 500, color: NC.bone, letterSpacing: '-0.014em', marginTop: 4 }}>What did you eat?</div>
          </div>
          <Press onClick={onClose} style={{
            width: 36, height: 36, borderRadius: '50%', background: NC.raised,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <NIcon name="close" size={16} color={NC.bone} />
          </Press>
        </div>

        {/* Search input */}
        <div style={{ padding: '0 20px 14px', position: 'relative' }}>
          <div style={{ position: 'absolute', left: 32, top: 14 }}>
            <NIcon name="search" size={18} color={NC.bone300} />
          </div>
          <input ref={inputRef}
            value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Search foods, scan, or speak"
            style={{
              width: '100%', boxSizing: 'border-box',
              padding: '14px 14px 14px 42px',
              background: NC.canvas, border: `1.5px solid ${NC.border}`,
              borderRadius: 14, fontSize: 15, color: NC.bone,
              outline: 'none', fontFamily: 'inherit',
            }}
            onFocus={e => e.currentTarget.style.borderColor = NC.lime300}
            onBlur={e => e.currentTarget.style.borderColor = NC.border}
          />
        </div>

        {/* Quick actions */}
        <div style={{ padding: '0 20px 14px', display: 'flex', gap: 8 }}>
          {[
            { i: 'camera', l: 'Scan label' },
            { i: 'barcode', l: 'Barcode' },
            { i: 'edit', l: 'Manual' },
          ].map(a => (
            <Press key={a.i} style={{
              flex: 1, padding: '12px 8px', borderRadius: 12,
              background: NC.canvas, border: `1px solid ${NC.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
            }}>
              <NIcon name={a.i} size={18} color={NC.lime300} strokeWidth={1.5} />
              <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone200 }}>{a.l}</span>
            </Press>
          ))}
        </div>

        {/* Meal tabs */}
        <div style={{ padding: '0 20px 12px', display: 'flex', gap: 6 }}>
          {['Breakfast', 'Lunch', 'Dinner', 'Snacks'].map(m => (
            <Press key={m} onClick={() => setMeal(m)} style={{
              flex: 1, padding: '7px 0', textAlign: 'center', borderRadius: 99,
              background: meal === m ? NC.limeDeep : 'transparent',
              border: `1px solid ${meal === m ? 'rgba(200,255,94,0.2)' : NC.border}`,
              fontFamily: MONO, fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase',
              color: meal === m ? NC.lime300 : NC.bone300,
            }}>{m}</Press>
          ))}
        </div>

        {/* Results list — minHeight:0 lets flex actually scroll */}
        <div style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: '0 20px 100px', display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300, padding: '6px 4px 8px' }}>
            {query ? 'Matches' : 'Recents'} · {FOODS.length}
          </div>
          {FOODS.map((f, i) => (
            <Press key={i} onClick={() => setSelected(f)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 14,
              background: selected?.name === f.name ? NC.limeDeep : NC.canvas,
              border: `1px solid ${selected?.name === f.name ? 'rgba(200,255,94,0.2)' : NC.border}`,
            }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: f.swatch, flexShrink: 0 }}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 500, color: NC.bone }}>{f.name}</div>
                <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.06em', color: NC.bone300, marginTop: 2 }}>
                  {f.k100} kcal · P {f.p}g · C {f.c}g · F {f.f}g
                </div>
              </div>
              <span style={{ fontFamily: MONO, fontSize: 11, color: selected?.name === f.name ? NC.lime300 : NC.bone200 }}>per 100g</span>
            </Press>
          ))}
        </div>

        {/* Confirm bar */}
        {selected && (
          <div style={{
            position: 'absolute', left: 0, right: 0, bottom: 0,
            padding: '14px 20px 22px',
            background: 'linear-gradient(180deg, transparent, rgba(25,30,27,0.96) 30%)',
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300 }}>{selected.name} · {serving}g</div>
              <div style={{ fontFamily: MONO, fontSize: 28, fontWeight: 500, color: NC.lime300, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.03em', lineHeight: 1, marginTop: 4 }}>{calc}<span style={{ fontSize: 11, color: NC.bone300, marginLeft: 6 }}>kcal</span></div>
            </div>
            <Press onClick={() => {
              const m = serving / 100;
              onAdd({
                name: selected.name, meal, time: '12:42',
                serving: serving + 'g',
                kcal: calc,
                p: +(selected.p * m).toFixed(1),
                c: +(selected.c * m).toFixed(1),
                f: +(selected.f * m).toFixed(1),
                fi: +(selected.fi * m).toFixed(1),
                swatch: selected.swatch,
              });
              onClose();
            }} style={{
              padding: '14px 24px', borderRadius: 14, background: NC.lime300, color: NC.canvas,
              fontSize: 15, fontWeight: 500, boxShadow: `0 0 0 1px ${NC.limeDeep}, 0 8px 24px ${NC.limeGlow}`,
            }}>
              Add →
            </Press>
          </div>
        )}
      </div>
    </>
  );
}
window.AddSheet = AddSheet;

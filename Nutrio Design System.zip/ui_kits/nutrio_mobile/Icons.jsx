// Icons.jsx — Nutrio icon library (Lucide-derived, 1.5 stroke)
// Exposes window.NIcon — usage: <NIcon name="home" size={24} color="#161B19" />

const NUTRIO_ICONS = {
  home: 'M3 12l9-9 9 9 M5 10v10h14V10',
  trends: 'M3 3v18h18 M7 14l4-4 4 4 5-6',
  plus: 'M12 5v14 M5 12h14',
  search: 'CIRC 11 11 7 | m20 20-3-3',
  user: 'CIRC 12 8 4 | M4 21a8 8 0 0 1 16 0',
  bookmark: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z',
  recipe: 'M6 2h12v6a6 6 0 0 1-12 0z M6 22h12v-6a6 6 0 0 0-12 0z',
  bell: 'M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0',
  camera: 'M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z | CIRC 12 13 4',
  barcode: 'M3 5v14 M7 5v14 M11 5v10 M11 17v2 M15 5v14 M19 5v14',
  flame: 'M8.5 14.5C8.5 17 10 19 12 19s3.5-2 3.5-4.5c0-2-1-3-2-4-1.5 1-2 2-3 0-1 1-2 3-2 4z M12 3c1 4 6 6 6 11a6 6 0 0 1-12 0c0-3 1.5-5 3-7',
  chevron_right: 'M9 6l6 6-6 6',
  chevron_left: 'M15 6l-6 6 6 6',
  chevron_down: 'M6 9l6 6 6-6',
  close: 'M18 6L6 18 M6 6l12 12',
  check: 'M20 6L9 17l-5-5',
  edit: 'M12 20h9 M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4z',
  settings: 'CIRC 12 12 3 | M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
  apple: 'M12 7c0-3 2-5 5-5 0 3-2 5-5 5z M16 11c-1.5-1-3-1.5-4-1.5s-2.5.5-4 1.5C4.7 12.5 3 16 5 19c1.5 2 3 2.5 4 2 .5-.25 1.5-.5 3-.5s2.5.25 3 .5c1 .5 2.5 0 4-2 2-3 .3-6.5-3-8z',
  beef: 'CIRC 9 8 4 | M5 18a4 4 0 0 1 8 0 M13 14c3-1 6-1 7 2 1 2-1 5-4 5s-5-3-3-7z',
  wheat: 'M3 21v-3 M12 3v18 M9 8c0-2 1-3 3-3 M15 8c0-2-1-3-3-3 M9 13c0-2 1-3 3-3 M15 13c0-2-1-3-3-3 M9 18c0-2 1-3 3-3 M15 18c0-2-1-3-3-3',
  droplet: 'M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z',
  clock: 'CIRC 12 12 9 | M12 7v5l3 2',
  water: 'M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z',
  star: 'M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8l-6.2 3.2L7 14.2l-5-4.9 6.9-1z',
  filter: 'M3 4h18 M6 12h12 M10 20h4',
  arrow_right: 'M5 12h14 M13 5l7 7-7 7',
  arrow_up: 'M5 12l7-7 7 7 M12 19V5',
};

function NIcon({ name, size = 24, color = 'currentColor', strokeWidth = 1.5, style = {} }) {
  const def = NUTRIO_ICONS[name];
  if (!def) return null;
  const parts = def.split('|').map(p => p.trim());
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
         stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
         style={{ flexShrink: 0, ...style }}>
      {parts.map((p, i) => {
        if (p.startsWith('CIRC ')) {
          const [, cx, cy, r] = p.split(' ');
          return <circle key={i} cx={cx} cy={cy} r={r} />;
        }
        return <path key={i} d={p} />;
      })}
    </svg>
  );
}

window.NIcon = NIcon;

// App.jsx — Click-thru shell. Renders the active screen and tab bar.

function NutrioApp() {
  const [tab, setTab] = React.useState('today');
  const [sheetOpen, setSheetOpen] = React.useState(false);
  const [defaultMeal, setDefaultMeal] = React.useState(null);
  const [animateKey, setAnimateKey] = React.useState(0);

  // Mock initial log
  const [log, setLog] = React.useState([
    { name: 'Oatmeal with blueberries', meal: 'Breakfast', time: '08:14', serving: '320g',
      kcal: 312, p: 9, c: 56, f: 7, fi: 9, swatch: '#1d2a16' },
    { name: 'Greek yogurt with honey',  meal: 'Breakfast', time: '09:30', serving: '200g',
      kcal: 186, p: 18, c: 12, f: 8, fi: 0, swatch: '#1d2a16' },
    { name: 'Chicken Caesar salad',     meal: 'Lunch',     time: '12:42', serving: '280g',
      kcal: 468, p: 32, c: 18, f: 28, fi: 4, swatch: '#2a1b12' },
    { name: 'Apple',                    meal: 'Snacks',    time: '15:10', serving: '180g',
      kcal: 95, p: 0, c: 25, f: 0, fi: 4, swatch: '#2a1e0a' },
  ]);

  const handleAdd = (meal) => {
    setDefaultMeal(meal);
    setSheetOpen(true);
  };

  const handleAddFromSheet = (item) => {
    setLog(l => [...l, item]);
    setAnimateKey(k => k + 1);
    setTab('today');
  };

  return (
    <div style={{
      position: 'absolute', inset: 0, background: NC.canvas, color: NC.bone,
      fontFamily: "'Geist', system-ui, sans-serif", overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', inset: 0, overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
        {tab === 'today'   && <TodayScreen   log={log} animateKey={animateKey} onMealTap={()=>{}} onAdd={handleAdd} />}
        {tab === 'trends'  && <TrendsScreen />}
        {tab === 'recipes' && <RecipesScreen />}
        {tab === 'you'     && <YouScreen />}
      </div>

      <TabBar tab={tab} onTab={setTab} onAdd={() => handleAdd(null)} />

      <AddSheet open={sheetOpen} defaultMeal={defaultMeal} onClose={() => setSheetOpen(false)} onAdd={handleAddFromSheet} />
    </div>
  );
}

window.NutrioApp = NutrioApp;

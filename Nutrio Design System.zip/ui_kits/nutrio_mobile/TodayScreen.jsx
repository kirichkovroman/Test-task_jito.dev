// TodayScreen.jsx — the default screen

function TodayScreen({ log, animateKey, onMealTap, onAdd }) {
  const totalKcal = log.reduce((a, m) => a + m.kcal, 0);
  const goal = 2000;
  const macros = ['p','c','f','fi'].reduce((acc, k) => ({ ...acc, [k]: log.reduce((s, m) => s + (m[k] || 0), 0) }), {});

  const meals = [
    { name: 'BREAKFAST', goal: 500, items: log.filter(m => m.meal === 'Breakfast') },
    { name: 'LUNCH',     goal: 700, items: log.filter(m => m.meal === 'Lunch') },
    { name: 'DINNER',    goal: 600, items: log.filter(m => m.meal === 'Dinner') },
    { name: 'SNACKS',    goal: 200, items: log.filter(m => m.meal === 'Snacks') },
  ];

  return (
    <div style={{ paddingBottom: 120 }}>
      <ScreenHeader
        date="THU · 28 MAY"
        greeting="Good morning, Alex"
        right={<div style={{ display: 'flex', gap: 8 }}>
          <IconBtn icon="bell" badge />
          <Avatar initials="AC" />
        </div>}
      />

      {/* HERO RING — Brand Expression layer */}
      <div style={{
        margin: '0 20px 18px', padding: '24px 20px 22px',
        background: NC.raised, borderRadius: 28, position: 'relative', overflow: 'hidden',
      }}>
        <BgDots opacity={0.06} />
        {/* Decorative concentric rings — directional motif */}
        <div style={{ position: 'absolute', right: -60, top: -60, width: 200, height: 200, borderRadius: '50%', border: '1px solid rgba(200,255,94,0.06)' }}/>
        <div style={{ position: 'absolute', right: -100, top: -100, width: 280, height: 280, borderRadius: '50%', border: '1px solid rgba(200,255,94,0.04)' }}/>

        <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <MacroRing kcal={totalKcal} goal={goal} animateKey={animateKey} />
          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <MonoChip accent>↗ 8% week</MonoChip>
            <MonoChip>Protein 88%</MonoChip>
          </div>
        </div>

        <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 10, position: 'relative' }}>
          <MacroBar name="Carbs"   color={NC.carbs}   value={macros.c}  goal={250} />
          <MacroBar name="Protein" color={NC.protein} value={macros.p}  goal={110} />
          <MacroBar name="Fat"     color={NC.fat}     value={macros.f}  goal={70} />
          <MacroBar name="Fiber"   color={NC.fiber}   value={macros.fi} goal={28} />
        </div>
      </div>

      {/* QUICK STATS — modular asymmetric tiles */}
      <div style={{ margin: '0 20px 24px', display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 10 }}>
        <StatTile label="Streak" value="5" unit="days" accent />
        <StatTile label="Water"  value="1.4" unit="L" delta="↗ on track" deltaType="down" />
        <StatTile label="Sleep"  value="7.2" unit="h" delta="↘ –30m" deltaType="up" />
      </div>

      {/* MEALS */}
      <SectionTitle action="↗ Day plan">Meals</SectionTitle>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        {meals.map(group => (
          <div key={group.name}>
            <MealHeader meal={group.name} kcal={group.items.reduce((s,i)=>s+i.kcal,0)} time={group.items[0]?.time} />
            <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {group.items.length === 0 ? (
                <Press onClick={() => onAdd(group.name)} style={{
                  padding: '14px 16px', borderRadius: 16, border: `1px dashed ${NC.border}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                }}>
                  <span style={{ fontSize: 13, color: NC.bone300 }}>Add to {group.name.toLowerCase()}</span>
                  <NIcon name="plus" size={16} color={NC.bone300} />
                </Press>
              ) : group.items.map((item, i) => (
                <FoodLogRow
                  key={i}
                  name={item.name}
                  sub={`${item.time} · ${item.serving}`}
                  kcal={item.kcal}
                  swatch={item.swatch}
                  icon={item.icon}
                  onClick={() => onMealTap(item)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* RECOMMENDED — editorial composition */}
      <SectionTitle action="See all">Recommended for dinner</SectionTitle>
      <div style={{ padding: '0 20px', overflowX: 'auto', display: 'flex', gap: 12, scrollbarWidth: 'none' }}>
        {[
          { t: 'Lemon herb chicken bowl', k: 412, p: 38, min: 15, bg: 'linear-gradient(135deg,#2a1b12,#1a1410)' },
          { t: 'Salmon & wild rice',      k: 486, p: 32, min: 20, bg: 'linear-gradient(135deg,#1d2a16,#121810)' },
          { t: 'Lentil spinach soup',     k: 286, p: 18, min: 10, bg: 'linear-gradient(135deg,#101a14,#0d1110)' },
        ].map((r, i) => (
          <Press key={i} style={{
            flex: '0 0 220px', borderRadius: 20, background: NC.surface, overflow: 'hidden',
          }}>
            <div style={{ aspectRatio: '16/10', background: r.bg, position: 'relative' }}>
              <BgDots opacity={0.08} size={10} />
              <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '55%', background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.7))' }}/>
              <div style={{ position: 'absolute', top: 10, left: 10 }}>
                <MonoChip>{r.min} min</MonoChip>
              </div>
              <div style={{ position: 'absolute', bottom: 12, left: 12, right: 12, fontSize: 15, fontWeight: 500, color: NC.bone, letterSpacing: '-0.008em', lineHeight: 1.25 }}>{r.t}</div>
            </div>
            <div style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div>
                <div style={{ fontFamily: MONO, fontSize: 14, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{r.k}</div>
                <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>kcal</div>
              </div>
              <div style={{ width: 1, height: 26, background: NC.border }}/>
              <div>
                <div style={{ fontFamily: MONO, fontSize: 14, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{r.p}g</div>
                <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>protein</div>
              </div>
            </div>
          </Press>
        ))}
      </div>
    </div>
  );
}
window.TodayScreen = TodayScreen;

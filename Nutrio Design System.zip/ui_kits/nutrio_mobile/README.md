# nutrio_mobile · iOS UI Kit

A click-through, high-fidelity recreation of the Nutrio mobile app.

## Open
Open `index.html` in a browser. The phone frame mounts in the middle; brand context flanks it on the sides.

## Try
- **Tap +** in the tab bar (or any "Add to …" placeholder) → opens the add-food sheet.
- **Search** any food (try "yogurt", "salmon") → tap a row → tap **Add** to commit.
- **Switch tabs** — Today / Trends / Recipes / You.
- **Watch the ring count up** on tab return — the daily total animates 0 → total in 900ms.

## Files
- `index.html` — entry, mounts everything inside `IOSDevice`
- `ios-frame.jsx` — iOS 26 device chrome (status bar, dynamic island, home indicator)
- `Icons.jsx` — Lucide-derived icon set, `<NIcon name="...">`
- `Common.jsx` — shared components: `MacroRing`, `FoodLogRow`, `StatTile`, `TabBar`, `Chip`, `MonoChip`, `PrimaryButton`, `FAB`, `GlowRing`, `BgDots`, `ScreenHeader`, etc.
- `TodayScreen.jsx` — hero ring + macros + meal log + recommended carousel
- `TrendsScreen.jsx` — oversized weekly avg + bar chart + macro tiles + insight
- `RecipesScreen.jsx` — filter chips + featured hero + recipe grid
- `YouScreen.jsx` — profile + goal tiles + settings list
- `AddSheet.jsx` — bottom-sheet flow for logging food
- `App.jsx` — shell + state + screen switcher

## Conventions
- All numerics use `Geist Mono` with `tabular-nums` and negative tracking.
- All micro-labels (timestamps, units, section headings) are ALL CAPS mono with ≥0.14em tracking.
- Lime (`#C8FF5E`) appears only on: the macro ring fill, the daily-total numeric, the FAB, active states, focus rings, and the "insight" card. Never as decoration.
- Press states use `scale(0.96)` over 100ms with ease-out (or spring for the FAB).
- The ring uses an SVG `linearGradient` (lime-200 → lime-600) + a radial `GlowRing` behind it.
- The bottom tab bar floats with 14px side margin and a backdrop-blur capsule.

## Things this kit deliberately doesn't have
- Real food database — search hits a hard-coded 6-item list.
- Real charts — the weekly bar chart is a fixed array.
- Onboarding / sign-in — see `preview/brand-onboarding-narrative.html` for the visual direction.
- Camera scan flow — represented by an icon button in the add sheet.

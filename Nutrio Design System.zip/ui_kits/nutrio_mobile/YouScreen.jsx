// YouScreen.jsx — Profile / settings

function YouScreen() {
  return (
    <div style={{ paddingBottom: 120 }}>
      <ScreenHeader date="PROFILE" greeting="Alex Chen" right={<IconBtn icon="settings"/>} />

      {/* Profile hero */}
      <div style={{
        margin: '0 20px 18px', padding: 20, background: NC.surface, borderRadius: 24,
        display: 'flex', alignItems: 'center', gap: 16, position: 'relative', overflow: 'hidden',
      }}>
        <BgDots opacity={0.05} />
        <div style={{
          width: 64, height: 64, borderRadius: '50%', background: NC.peachDeep,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: MONO, fontSize: 22, fontWeight: 500, color: NC.peach300,
          border: `1px solid ${NC.border}`, position: 'relative',
        }}>AC</div>
        <div style={{ flex: 1, position: 'relative' }}>
          <div style={{ fontSize: 18, fontWeight: 500, color: NC.bone, letterSpacing: '-0.012em' }}>Alex Chen</div>
          <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone300, marginTop: 4 }}>
            Member since 2024 · 84 days logged
          </div>
        </div>
      </div>

      {/* Goal tiles */}
      <SectionTitle>Daily goals</SectionTitle>
      <div style={{ margin: '0 20px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <StatTile label="Calories" value="2,000" unit="kcal" />
        <StatTile label="Protein"  value="110" unit="g" accent />
        <StatTile label="Carbs"    value="250" unit="g" />
        <StatTile label="Fat"      value="70"  unit="g" />
      </div>

      {/* Settings list */}
      <SectionTitle>Settings</SectionTitle>
      <div style={{ margin: '0 20px 18px', padding: '4px 14px', background: NC.surface, borderRadius: 18 }}>
        {[
          { i: 'bell', l: 'Notifications', s: 'Daily at 12:00' },
          { i: 'droplet', l: 'Water tracking', s: 'On' },
          { i: 'settings', l: 'Units', s: 'Metric (g, ml)' },
          { i: 'user', l: 'Account', s: 'alex@nutrio.app' },
        ].map((r, i, arr) => (
          <Press key={i} style={{
            display: 'flex', alignItems: 'center', gap: 14, padding: '14px 6px',
            boxShadow: i < arr.length - 1 ? `inset 0 -1px 0 ${NC.border}` : 'none',
          }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: NC.raised, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <NIcon name={r.i} size={16} color={NC.bone200} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500, color: NC.bone }}>{r.l}</div>
              <div style={{ fontFamily: MONO, fontSize: 10, color: NC.bone300, letterSpacing: '0.04em', marginTop: 2 }}>{r.s}</div>
            </div>
            <NIcon name="chevron_right" size={16} color={NC.bone400} />
          </Press>
        ))}
      </div>
    </div>
  );
}
window.YouScreen = YouScreen;

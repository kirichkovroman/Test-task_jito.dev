// TrendsScreen.jsx — 7-day overview + editorial bar chart

function TrendsScreen() {
  const days = [
    { d: 'M', kcal: 1740 },
    { d: 'T', kcal: 1980 },
    { d: 'W', kcal: 2140 },
    { d: 'T', kcal: 1820 },
    { d: 'F', kcal: 1690 },
    { d: 'S', kcal: 2250 },
    { d: 'S', kcal: 1420, today: true },
  ];
  const max = 2400;
  const avg = Math.round(days.reduce((s,d)=>s+d.kcal,0) / days.length);

  return (
    <div style={{ paddingBottom: 120 }}>
      <ScreenHeader date="THIS WEEK" greeting="Trends" right={<IconBtn icon="settings"/>} />

      {/* OVERSIZED NUMERIC — Emotional / Brand Expression */}
      <div style={{ margin: '0 20px 16px', padding: '24px 20px 18px', background: NC.surface, borderRadius: 24, position: 'relative', overflow: 'hidden' }}>
        <BgDots opacity={0.05} />
        <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300, position: 'relative' }}>7-day avg · kcal</div>
        <div style={{
          fontFamily: MONO, fontSize: 64, fontWeight: 500, color: NC.lime300,
          fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.04em', lineHeight: 1,
          marginTop: 10, position: 'relative',
        }}>
          {avg.toLocaleString()}
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 14, position: 'relative' }}>
          <MonoChip accent>↘ 120 vs last</MonoChip>
          <MonoChip>Goal 2,000</MonoChip>
        </div>

        {/* Bar chart */}
        {(() => {
          const CHART_H = 130;
          return (
            <div style={{ marginTop: 26, position: 'relative', height: CHART_H + 22 /* + label row */ }}>
              <div style={{ position: 'absolute', inset: `0 0 22px 0`, display: 'flex', alignItems: 'flex-end', gap: 10, justifyContent: 'space-between' }}>
                {days.map((d, i) => {
                  const h = Math.round((d.kcal / max) * CHART_H);
                  return (
                    <div key={i} style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
                      <div style={{
                        width: '100%', maxWidth: 28, height: `${h}px`,
                        background: d.today ? NC.lime300 : NC.raised,
                        borderRadius: 4,
                        boxShadow: d.today ? `0 0 16px ${NC.limeGlow}` : 'none',
                      }}/>
                    </div>
                  );
                })}
              </div>
              {/* Day labels */}
              <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, display: 'flex', gap: 10, justifyContent: 'space-between' }}>
                {days.map((d, i) => (
                  <span key={i} style={{ flex: 1, textAlign: 'center', fontFamily: MONO, fontSize: 10, color: d.today ? NC.lime300 : NC.bone300, letterSpacing: '0.06em' }}>{d.d}</span>
                ))}
              </div>
              {/* Goal line */}
              <div style={{
                position: 'absolute', left: 0, right: 0,
                top: `${CHART_H - (2000 / max) * CHART_H}px`,
                height: 0, borderTop: `1px dashed ${NC.bone400}`, opacity: 0.5,
              }}>
                <div style={{ position: 'absolute', right: 0, top: -14, fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', color: NC.bone400, textTransform: 'uppercase' }}>Goal</div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* MACRO BREAKDOWN — modular grid */}
      <SectionTitle>Macros · weekly avg</SectionTitle>
      <div style={{ margin: '0 20px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <StatTile label="Carbs"   value="218" unit="g" delta="↗ 6%" deltaType="down" />
        <StatTile label="Protein" value="88"  unit="g · 80%" delta="on track" deltaType="neutral" accent />
        <StatTile label="Fat"     value="64"  unit="g" delta="↘ 8g" deltaType="up" />
        <StatTile label="Fiber"   value="26"  unit="g" delta="↗ 4g" deltaType="down" />
      </div>

      {/* INSIGHT — editorial copy moment */}
      <div style={{ margin: '0 20px', padding: 20, background: NC.limeDeep, borderRadius: 20, border: '1px solid rgba(200,255,94,0.16)' }}>
        <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.lime600 }}>Insight</div>
        <div style={{ fontSize: 17, fontWeight: 500, color: NC.bone, marginTop: 8, letterSpacing: '-0.008em', lineHeight: 1.35 }}>
          Protein up. Fiber holding. Your weekday averages are tighter than your weekends.
        </div>
      </div>
    </div>
  );
}
window.TrendsScreen = TrendsScreen;

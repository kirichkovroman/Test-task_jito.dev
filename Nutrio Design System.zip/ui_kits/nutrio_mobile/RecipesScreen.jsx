// RecipesScreen.jsx — Recipe browse

function RecipesScreen() {
  const filters = ['All', 'High protein', 'Quick', 'Vegan', 'Low carb'];
  const [active, setActive] = React.useState('All');

  const recipes = [
    { t: 'Lemon herb chicken bowl', k: 412, p: 38, min: 15, tag: 'High protein', bg: 'linear-gradient(135deg,#2a1b12,#1a1410)' },
    { t: 'Salmon & wild rice',      k: 486, p: 32, min: 20, tag: 'Omega-3',     bg: 'linear-gradient(135deg,#1d2a16,#121810)' },
    { t: 'Lentil spinach soup',     k: 286, p: 18, min: 10, tag: 'Vegan',       bg: 'linear-gradient(135deg,#101a14,#0d1110)' },
    { t: 'Greek bowl with feta',    k: 392, p: 22, min: 12, tag: 'Mediterranean', bg: 'linear-gradient(135deg,#1f1410,#1a1210)' },
  ];

  return (
    <div style={{ paddingBottom: 120 }}>
      <ScreenHeader date="DISCOVER" greeting="Recipes" right={<IconBtn icon="search"/>} />

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, padding: '0 20px 20px', overflowX: 'auto', scrollbarWidth: 'none' }}>
        {filters.map(f => (
          <Chip key={f} active={f === active} onClick={() => setActive(f)}>{f}</Chip>
        ))}
      </div>

      {/* FEATURED — full-bleed editorial card */}
      <div style={{ margin: '0 20px 20px', borderRadius: 24, overflow: 'hidden', position: 'relative', background: 'linear-gradient(135deg,#2a1b12 0%, #1a1410 100%)', height: 200 }}>
        <BgDots opacity={0.08} size={10} />
        <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '70%', background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.78))' }}/>
        <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', gap: 6 }}>
          <MonoChip>Featured</MonoChip>
          <MonoChip>25 min</MonoChip>
        </div>
        <div style={{ position: 'absolute', bottom: 16, left: 16, right: 16 }}>
          <div style={{ fontSize: 22, fontWeight: 500, color: NC.bone, letterSpacing: '-0.014em', lineHeight: 1.2 }}>
            Miso glazed cod with greens
          </div>
          <div style={{ display: 'flex', gap: 14, marginTop: 12 }}>
            <div>
              <div style={{ fontFamily: MONO, fontSize: 16, fontWeight: 500, color: NC.lime300, fontVariantNumeric: 'tabular-nums' }}>438</div>
              <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>kcal</div>
            </div>
            <div>
              <div style={{ fontFamily: MONO, fontSize: 16, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>42g</div>
              <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>protein</div>
            </div>
          </div>
        </div>
      </div>

      <SectionTitle>For your day</SectionTitle>

      {/* Recipe grid */}
      <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {recipes.map((r, i) => (
          <Press key={i} style={{ borderRadius: 20, background: NC.surface, overflow: 'hidden' }}>
            <div style={{ aspectRatio: '4/3', background: r.bg, position: 'relative' }}>
              <BgDots opacity={0.08} size={10} />
              <div style={{ position: 'absolute', top: 8, left: 8 }}>
                <MonoChip>{r.min} min</MonoChip>
              </div>
            </div>
            <div style={{ padding: 12 }}>
              <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>{r.tag}</div>
              <div style={{ fontSize: 14, fontWeight: 500, color: NC.bone, marginTop: 4, lineHeight: 1.25, letterSpacing: '-0.008em' }}>{r.t}</div>
              <div style={{ display: 'flex', gap: 12, marginTop: 8, alignItems: 'baseline' }}>
                <div style={{ fontFamily: MONO, fontSize: 12, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{r.k} <span style={{ color: NC.bone300, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase' }}>kcal</span></div>
                <div style={{ fontFamily: MONO, fontSize: 12, color: NC.lime300, fontVariantNumeric: 'tabular-nums' }}>{r.p}g <span style={{ color: NC.bone300, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase' }}>p</span></div>
              </div>
            </div>
          </Press>
        ))}
      </div>
    </div>
  );
}
window.RecipesScreen = RecipesScreen;

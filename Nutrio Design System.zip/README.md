# Nutrio Design System

Nutrio is a **mobile-first nutrition tracker** that turns food logging from a chore into a moment. The brand is **confident, calm, and distinctive** — futuristic without the science-fiction costume, expressive without becoming noise.

This system is **dark-first**, built for low-light, late-night, end-of-day use. Numbers are the brand. The accent is **chartreuse-lime** — a single, electric color used assertively and sparingly against deep green-black canvas.

---

## Sources

> No external assets, Figma, or codebase were attached. This system was authored from the brand brief. If a Figma file, repo, or asset pack exists, attach it and we will reconcile.

Brief, condensed:
> Mobile-first nutrition tracker. Dark-theme-first, modern, slightly unconventional. Calm + confident. WCAG AA. Visual hierarchy on data-heavy screens. Bold contrast, expressive accents, non-standard layouts where appropriate.

---

## Index

Root
- `README.md` — this file
- `SKILL.md` — Agent Skill manifest
- `colors_and_type.css` — Color + typography tokens (base + semantic)
- `tokens.css` — Spacing, radii, elevation, glow, motion

Folders
- `fonts/` — Loaded from Google Fonts (Geist + Geist Mono). See **Fonts** below.
- `assets/` — Logos, motifs, textures
- `preview/` — Design System tab cards
- `ui_kits/nutrio_mobile/` — Working iOS app prototype. Open `index.html`.

---

## v2 — The Expressive skin  *(2026 evolution)*

The product's visual style evolved from **"dark canvas + sparing lime accent"** into a **vibrant, expressive bento system**. This is an *evolution, not a replacement* — the dark/lime foundation below is fully intact and backward-compatible. The Expressive skin sits **on top** of it as the new default look.

What changed, at a glance:

| | v1 (original) | v2 (Expressive skin) |
|---|---|---|
| **Accent** | Lime alone, used sparingly | A **7-color semantic palette** (violet, amber, orange, lime, coral, mint, sky) used *together* as solid-fill tiles |
| **Layout** | Dark cards on dark canvas | **Asymmetric bento** of vibrant offset tiles (slight tilt, colored glow) |
| **Headline type** | Geist Mono + sans | **Bricolage Grotesque** display (700/800) + **Instrument Serif** italic counterpoint |
| **Data viz** | Single-color ring | **Multi-color segment donut**, bar fields, scallop/seal badges |
| **Surface mood** | Restrained, monochrome | Saturated, energetic, "each tile is a different color" |
| **Radii** | 6–36px base scale | **Organic** scale (~1.4–1.55× — `--radius-organic-*`) |
| **Motion** | Calm ease-out | Adds a **bolder spring** (`--ease-spring-bold`) + parallax tilt |

New tokens (all additive — see `colors_and_type.css` / `tokens.css`):
- **Vibrant palette:** `--v-{violet,amber,orange,lime,coral,mint,sky}-{fill,on,mut,ink,light,soft}`. Each color ships four+ roles; `on`/`mut` are AA-verified text colors for that fill.
- **Display type:** `--font-display` (Bricolage Grotesque), `--font-serif` (Instrument Serif, italic only), `--fs-disp-{xl,lg,md}`, `--fs-serif-{lg,md,sm}`. Classes `.t-disp-*` and `.t-serif`.
- **Organic radii:** `--radius-organic-{md,lg,xl,2xl}`. **Tile tilt:** `--tile-tilt-{sm,md,lg}`.
- **Per-tile glow:** `--glow-{violet,lime,coral,orange,sky,mint,amber}`. **Bold spring:** `--ease-spring-bold`.

How it maps to the three layers (below): the vibrant palette + bento + display type are the **Brand Expression layer** turned up; the multi-color "fuel" donut and scallop badges are **Emotional**; the Functional layer (lists, inputs, settings, body copy) stays on the restrained dark/bone/mono foundation so data-heavy screens never become noise.

> **When to stay restrained:** A bento of seven colors is for the *dashboard / home / summary*. Detail screens, forms, and long lists still use single-surface dark cards with one accent. Don't paint a settings list rainbow.

> The **Expressive skin is theme-driven** in the prototype: dials for accent family (lime/mint/peach/iris), expressiveness (calm→bold), shape (sharp→organic), and motion resolve into the concrete values above. The tokens here capture the **bold default**.

---

## The three-layer system

Every Nutrio surface is built from three layers, each with a different job.

### 1 · Functional layer  *(what the user uses)*
The durable, accessible foundation: tokens, type, spacing, components. This layer is conservative on purpose — it does the work. Body text, controls, lists, settings, inputs all live here. The visual budget here is tight: dark canvas, bone text, one accent, mono numerics, soft hairline borders. No glow, no expressive geometry, **no rainbow tiles.** **Always WCAG AA.**

### 2 · Brand expression layer  *(what the user remembers)*
The signatures that make Nutrio recognizable at a glance.
- **Numbers are the brand.** Big mono numerics, now often on a vibrant tile (white on violet, ink on lime). They are the headline of every screen.
- **The vibrant bento.** Asymmetric grid of solid-color tiles, each a different hue, slightly tilted, with a soft same-hue glow. The signature v2 layout.
- **Mixed-font headlines.** Bricolage Grotesque display with a colored word + an Instrument Serif *italic* counterpoint: "Hey, **Alex** *— let's eat well today.*"
- **Mono micro-labels.** `KCAL · FUEL`, `↗ 7-DAY`, `PROTEIN / 88%` — Geist Mono uppercase, wide tracking. The "control room" voice, now often set in a tile's `mut` color.
- **Dot-grid texture.** A 14–16px dot pattern on hero tiles (white dots on color, bone dots on dark).

### 3 · Emotional layer  *(what the user feels)*
Reserved for cinematic moments — onboarding, goal completion, day summary, milestones.
- **Oversized type moments.** The screen becomes the number.
- **Multi-color fuel donut + scallop badges.** The celebratory data viz — segmented rings in the macro palette, seal/starburst badges for streaks.
- **Colored glow.** Radial halo behind the hero ring, the FAB, a tile casting its own hue. The system's "lighting."
- **Floating layered compositions.** During onboarding, cards stack at offsets like a deck mid-shuffle. Used once per major flow.
- **Narrative micro-copy.** Two-line, present-tense statements: "You ate well today." "Closer to your protein goal than yesterday." No exclamation marks, no metrics in the headline.
- **Slow motion.** 600–900ms ring fills, 400ms count-ups. These moments breathe.

Each layer has a different budget. If you find yourself adding glow to a settings row or shipping a CTA without a number, you're using the wrong layer.

---

## CONTENT FUNDAMENTALS

The voice is **a calm, intelligent assistant that takes data seriously and isn't trying to be your friend.** Less coach, more cockpit.

### Tone & posture
- **Calm and direct.** "1,420 kcal today. 580 to go." Not "Great job!"
- **Specific over motivational.** "You're 18g short on protein" beats "Almost there!"
- **No streaks, no shame.** "Welcome back" — not "You broke your streak."
- **Editorial when appropriate.** On the daily summary or weekly recap, copy gets one short, observational sentence: "Protein up. Fiber holding."
- **Confident.** Active voice, present tense. "Nutrio reads labels." not "Labels can be read by Nutrio."

### Person & address
- **Second person ("you") for state.** "You've logged 1,420 kcal."
- **First person plural ("we") for app actions.** "We couldn't read that label — retry?"
- **Never "I" from the app.** Nutrio isn't a persona.

### Casing
- **Sentence case** for every UI control, title, and body sentence.
- **ALL CAPS in Geist Mono** for micro-labels (≤12px) with 0.1em+ tracking. This is the brand voice — use it deliberately on stat tiles, section dividers, badges.
- **Title Case** reserved for proper food names ("Greek Yogurt with Honey").
- **No ALL CAPS in sans serif.** Ever.

### Numbers & units
- **Tabular mono figures, always**, for any nutritional value. Geist Mono with `font-variant-numeric: tabular-nums`.
- **Round calories to whole numbers.** "412 kcal".
- **Round macros to one decimal max.** Drop trailing zeros: "24g" not "24.0g".
- **Units always lowercase** ("kcal", "g", "mg") except in micro-labels where the whole thing is uppercase mono.
- **Comma thousands separator** ("2,150 kcal").
- **Percentages of daily goal** as whole numbers with %: "71%".
- **Deltas with arrows** in micro labels: `↗ 8%`, `↘ 120`.

### Emoji
- **Never in product copy.** Conflict with the calm/technical tone.
- **Exception:** user-typed emoji inside custom food names are preserved verbatim.

### Punctuation
- **No exclamation marks** in product copy. They read as anxious.
- **Em dashes** welcome for asides — like this one.
- **Oxford comma** on.
- **Periods on full sentences** in body copy; **no periods** on UI labels, button text, headlines, or single-fragment toasts.
- **Mid-dots** (·) as separators in mono micro-labels: `8:14 AM · BREAKFAST · 312 KCAL`.

### Examples

| Don't ❌ | Do ✅ |
|---|---|
| "Great job! 🎉 You hit your goal!" | "Target hit. 1,980 of 2,000 kcal." |
| "You're OVER your daily limit by 240 cal!" | "240 kcal above target. Adjust tomorrow if you like." |
| "Add Your First Meal" | "Add a meal" |
| "1500 calories" | "1,500 kcal" |
| "Protein: 78g (Great!)" | "PROTEIN · 78g · 88%" |

---

## VISUAL FOUNDATIONS

### Color vibe
**Deep green-black canvas + electric chartreuse-lime accent.** The canvas is not pure black — it has a slight green undertone (`#0E1110`) that keeps the brand connected to its "nourishment" roots without going clinical-teal or sci-fi-cyan. Lime (`#C8FF5E`) is the single signature color. It is used **assertively but sparingly** — on the active state, the primary number, the FAB, the focus ring. Peach (`#FFB088`) is the only other accent and appears only in food-warmth contexts and the "fat" macro encoding.

**Macros** are a luminous palette tuned for dark: amber carbs, lime protein, peach fat, mint fiber. They read as data encoding, not Skittles.

### Type
**Geist** (sans) + **Geist Mono** — a modern, low-contrast pairing with excellent screen rendering. Geist for everything human-readable; Geist Mono for **all numerics**, **all micro-labels**, and the brand-expression moments. The Mono is the brand's signature voice — used for tabular nutrition data, ALL CAPS section labels, and timestamps.

Big numerics use weight 500 (medium) in Mono, with negative tracking (-0.04em) — they should feel **precise, not heavy**.

### Backgrounds
- **`--bg-canvas`** (`#0E1110`) — page default.
- **`--bg-surface`** (`#191E1B`) — cards.
- **`--bg-surface-raised`** (`#222824`) — modal, sheet, FAB context.
- **One gradient permitted:** a radial glow behind the macro ring on the Today screen, lime → transparent. This is the entire "lighting" budget for the app.
- **Dot-grid texture** at 6% opacity on the Today hero card and onboarding panels. Nowhere else.
- **No frosted glass / glassmorphism.** We use solid surfaces with hairline borders.
- **Full-bleed imagery** only on recipe heroes.

### Animation
- **All motion uses `cubic-bezier(0.2, 0.8, 0.2, 1)`** by default — a calm ease-out.
- **`cubic-bezier(0.32, 1.4, 0.5, 1)`** — a *gentle* spring for one place: the FAB tap.
- **Durations:** 120ms (state), 200ms (default), 280ms (sheet/modal), 600ms (ring fill), 900ms (count-up on daily summary).
- **Count-ups** on every appearance of the daily total (it doesn't just appear — it counts up from 0 in 900ms).
- **No confetti, no bounce-on-goal.** Goal hit = ring fills, value text pulses lime once, done.

### Hover / focus / press
- **Hover:** `rgba(255,255,255,0.04)` background tint. Primary CTA: shifts from lime-300 to lime-200.
- **Press:** scale `0.97` over 80ms.
- **Focus ring:** 2px `--lime-300` at 2px offset. Always visible.
- **Disabled:** 40% opacity.

### Borders
- **Default hairline:** 1px `--ink-650` (`#2A312D`) — a barely-there ink lift.
- **Strong border:** 1.5px `--ink-500` — used on inputs.
- **Accent border:** `--lime-300` — focus and selected states.
- **Cards have no border by default.** They rely on surface contrast + (occasional) shadow.

### Elevation (on dark)
On dark, "shadow" doesn't read — we layer **surface brightness** instead. A "raised" card is a brighter surface, not a deeper drop shadow. We keep shadow tokens for occasional realism (sheets, modals).
- `shadow-1` cards · `shadow-2` FAB · `shadow-3` sheets · `shadow-4` modals
- `glow-accent` — the lime halo for FAB, focus rings, and one ring-context only.

### Transparency & blur
- **Bottom tab bar** uses backdrop-blur(20px) at 85% opacity over scrolled content. This is the one place blur lives.
- **Modal scrim** is 70% `--ink-1000`, no blur.

### Corner radii
A 7-step scale tuned to dark surfaces (slightly larger than light defaults to feel more *modern*):
- `xs 6` — micro chips · `sm 10` — small controls · `md 14` — buttons, inputs · `lg 20` — cards · `xl 28` — large modules · `2xl 36` — bottom sheets · `full` — pills, FAB.

### Layout rules
- **Mobile design width: 390px.** Min 360px.
- **8pt grid.** Edge padding 20px.
- **Bottom tab bar floats** with 14px side margin (it's a floating capsule, not a full-width chrome).
- **Asymmetric modular grids** are allowed on the Today and Trends screens — uneven heights, hero+rail patterns. Lists stay symmetric.

### Cards
- Default: `--bg-surface`, `--radius-lg` (20px), `--shadow-1`, no border, 16px internal padding.
- Hero card (Today): `--bg-surface-raised`, `--radius-2xl` (36px), dot-grid overlay, lime radial glow behind ring.
- Modular tile: `--bg-surface`, `--radius-lg`, optional 1px hairline border, 14px padding.

### Imagery
- **Food photography:** moody, low-key, side-lit, warm midtones, deep shadows. The "restaurant at night" mood. Avoid bright top-down stock.
- **No 3D illustrations.** No isometric. No bluish-purple gradients. No holographic anything.
- **Empty-state illustrations:** single-line lime stroke on dark, geometric, used like a haiku not a graphic.

---

## ICONOGRAPHY

**System:** [Lucide](https://lucide.dev) — we use a small custom subset shipped inline as `Icons.jsx` in the UI kit (`NUTRIO_ICONS`).

> ⚠️ **Substitution flag:** Nutrio will likely want a custom food/macro icon set (apple, beef, wheat, fish, droplet). Until provided, we use Lucide for the shell and our own minimal versions where Lucide doesn't fit.

### Rules
- **Default size 24×24.** Dense rows 20×20. Inline-with-text 18×18. Feature contexts 32×32.
- **Stroke 1.5px** uniform. (Lucide default is 2px — we override.)
- **Color `currentColor`.** Icons inherit text color.
- **No filled icons in shell.** The active bottom tab gets a lime *pill* background behind an outline icon — no fill swap.
- **No emoji as icon.**
- **Directional arrows** (↗ ↘) ARE used as graphic elements at small mono-text sizes, never as standalone icons in lists.

### Logos
- `assets/logo-mark.svg` — lockup (mark + wordmark)
- `assets/logo-mark-only.svg` — just the trajectory-leaf mark
- `assets/logo-wordmark.svg` — wordmark only
- `assets/app-icon.svg` — squircle app icon

### Brand motifs (in `assets/`)
- `motif-trajectory.svg` — the swept arc + endpoint dot. Used as a graphic element on hero compositions, onboarding panels, the "you've come this far" moment.
- `grid-dots.svg` — 16px dot pattern. Overlay on hero surfaces at 6% opacity.

---

## Fonts

> ⚠️ **Substitution flag:** Loading four families from Google Fonts. If Nutrio licenses custom faces, drop the `.woff2` into `fonts/` and update the `@import` in `colors_and_type.css`.

| Family | Token | Role |
|---|---|---|
| **Geist** | `--font-sans` | Body, UI, labels |
| **Geist Mono** | `--font-mono` | **All numerics**, timestamps, ALL-CAPS micro-labels |
| **Bricolage Grotesque** *(v2)* | `--font-display` | Expressive headlines + "moment" type (700/800) |
| **Instrument Serif** *(v2)* | `--font-serif` | Italic-only editorial counterpoint inside headlines |

Weights used: **400** (body / serif), **500** (UI, numerics), **600** (sans display), **700–800** (Bricolage display).

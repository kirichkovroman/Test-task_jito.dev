---
name: nutrio-design
description: Use this skill to generate well-branded interfaces and assets for Nutrio — a mobile-first, dark-themed nutrition tracker. Contains essential design guidelines, dark-first color tokens, Geist typography, Lucide icon set, brand motifs, and a working mobile UI kit. Use for production work, prototypes, mocks, slide decks, or any visual artifact in the Nutrio brand.
user-invocable: true
---

# Nutrio Design Skill

Read `README.md` first — it covers the brand brief, content fundamentals, and the three-layer visual system (Functional / Brand Expression / Emotional).

Then explore:
- `colors_and_type.css` — color + type tokens (base + semantic)
- `tokens.css` — spacing, radii, elevation, glow, motion
- `assets/` — logos and brand motifs (trajectory arc, dot grid, app icon)
- `preview/` — every design system card. Useful for grabbing snippets.
- `ui_kits/nutrio_mobile/` — working iOS app prototype. Read `README.md` there for component inventory.

## Working with this brand

When creating visual artifacts (slides, mocks, throwaway prototypes):
1. **Start dark.** Canvas is `#0E1110`. Never default to white.
2. **Import the foundation CSS.** `<link rel="stylesheet" href="colors_and_type.css"><link rel="stylesheet" href="tokens.css">` — these provide every token you need.
3. **Use Geist + Geist Mono.** Body text in sans; **all** numerics, timestamps, and ALL CAPS micro-labels in mono.
4. **Lime sparingly.** `#C8FF5E` belongs on hero numerics, the primary CTA, active states, and focus rings. Never as a background fill across a whole region.
5. **Mono micro-labels are signature.** `KCAL · 1,420 · ↗ 8% WEEK` — set in Geist Mono uppercase with ≥0.14em tracking. Use them as section dividers, stat labels, timestamps, and deltas.
6. **No glassmorphism, no holographic gradients, no emoji.** See "Avoid" in README.

## Working on production code

The CSS tokens map cleanly to design tokens in any framework. The UI kit components in `ui_kits/nutrio_mobile/Common.jsx` are pragmatic (inline styles + React) — port their structure but use your team's actual styling system.

## If invoked with no guidance

Ask the user what they want to build. Ask about:
- Surface (mobile screen, marketing slide, landing page, settings flow?)
- Density (hero / data-heavy / minimal narrative?)
- Layer (Functional plumbing or an Emotional moment?)
- Format (static design canvas, click-through prototype, deck?)

Then act as an expert Nutrio designer and produce HTML.

// nutrio-onboarding.jsx — intro. Calm variant (trajectory + number) and Expressive
// variant (bold multicolor typographic splash, mixed fonts, organic blobs).

function Onboarding({ onDone }) {
  const t = useTheme();
  if (t.brut) return <BrutOnboarding onDone={onDone}/>;
  return <CalmOnboarding onDone={onDone}/>;
}

// ── Expressive splash ──
function BrutOnboarding({ onDone }) {
  const t = useTheme();
  const [i, setI] = React.useState(0);
  const slides = [
    {
      kicker: 'NUTRIO · EAT WITH INTENTION',
      // each word: [text, color, font, italic]
      words: [['Know', SEM.lime.fill, DISPLAY, false], ['every', NC.bone, DISPLAY, false], ['bite', SEM.violet.light, SERIF, true], ['.', SEM.lime.fill, DISPLAY, false]],
      blob: SEM.violet.fill, blob2: SEM.lime.fill,
      stat: '1-tap', statLabel: 'snap a plate → calories + macros',
      body: 'Point Nutrio at any meal. We read the plate and estimate calories and macros in seconds.',
    },
    {
      kicker: 'NUTRIO · BUILT AROUND YOU',
      words: [['Find', SEM.orange.fill, DISPLAY, false], ['your', NC.bone, DISPLAY, false], ['flavor', SEM.coral.light, SERIF, true], ['.', SEM.orange.fill, DISPLAY, false]],
      blob: SEM.orange.fill, blob2: SEM.coral.fill,
      stat: '120+', statLabel: 'recipes matched to your goals',
      body: 'Filter by diet, goal, time and macros. Nutrio surfaces what moves you forward — nothing that doesn’t.',
    },
  ];
  const s = slides[i];
  const last = i === slides.length - 1;

  return (
    <div style={{ position: 'absolute', inset: 0, background: NC.canvas, zIndex: 300, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <BgDots opacity={0.07}/>
      {/* ambient blobs — kept to the right, low opacity, blurred so text stays legible */}
      <Blob color={s.blob} size={300} variant={0} style={{ right: -120, top: -90, opacity: 0.55, filter: 'blur(6px)' }}/>
      <Blob color={s.blob2} size={170} variant={1} style={{ right: -40, bottom: '14%', opacity: 0.5, filter: 'blur(8px)' }}/>
      {/* contrast guard: keep the left (text) column dark + footer readable */}
      <div style={{ position: 'absolute', inset: 0, background: `linear-gradient(100deg, ${NC.canvas} 42%, ${NC.canvas}cc 60%, transparent 88%)` }}/>
      <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '30%', background: `linear-gradient(180deg, transparent, ${NC.canvas})` }}/>

      {/* skip */}
      <div style={{ position: 'relative', padding: '58px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone200 }}>{String(i+1).padStart(2,'0')} / {String(slides.length).padStart(2,'0')}</div>
        <Press onClick={onDone} style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone, padding: '8px 14px', background: NC.surface, border: `1px solid ${NC.border}`, borderRadius: 99 }}>Skip</Press>
      </div>

      {/* content */}
      <div key={'b' + i} style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 28px', animation: `nutrio-fade-up ${t.dur(460)}ms ${t.ease}` }}>
        <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: SEM.lime.fill, marginBottom: 18 }}>{s.kicker}</div>
        {/* the big multicolor headline, one word per line, offset */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {s.words.filter(w => w[0] !== '.').map((w, idx) => (
            <div key={idx} style={{
              fontFamily: w[2], fontWeight: w[2] === DISPLAY ? 800 : 400, fontStyle: w[3] ? 'italic' : 'normal',
              fontSize: w[2] === SERIF ? 92 : 84, lineHeight: 0.86, letterSpacing: w[2] === SERIF ? '0' : '-0.04em',
              color: w[1], marginLeft: idx === 1 ? 22 : idx === 2 ? 8 : 0,
            }}>{w[0]}{idx === s.words.filter(x=>x[0]!=='.').length - 1 ? <span style={{ color: SEM.lime.fill, fontFamily: DISPLAY }}>.</span> : ''}</div>
          ))}
        </div>

        {/* floating stat chip */}
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginTop: 26, padding: '7px 12px 7px 7px', background: NC.surface, border: `1px solid ${NC.border}`, borderRadius: 99, alignSelf: 'flex-start' }}>
          <span style={{ fontFamily: MONO, fontWeight: 600, fontSize: 13, color: i ? SEM.orange.fill : SEM.violet.light, letterSpacing: '-0.01em', background: i ? SEM.orange.soft : SEM.violet.soft, padding: '3px 9px', borderRadius: 99 }}>{s.stat}</span>
          <span style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.06em', textTransform: 'uppercase', color: NC.bone200 }}>{s.statLabel}</span>
        </div>

        <div style={{ fontSize: 15, color: NC.bone200, lineHeight: 1.55, marginTop: 22, maxWidth: 330 }}>{s.body}</div>
      </div>

      {/* footer */}
      <div style={{ position: 'relative', padding: '0 28px calc(40px + var(--safe-bottom))', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {slides.map((_, idx) => (
            <div key={idx} style={{ width: idx === i ? 28 : 9, height: 9, borderRadius: 99, background: idx === i ? SEM.lime.fill : NC.border, transition: `all ${t.dur(280)}ms ${t.ease}` }}/>
          ))}
        </div>
        <BrutCTA onClick={() => last ? onDone() : setI(i + 1)} label={last ? 'Get started' : 'Next'} last={last}/>
      </div>
    </div>
  );
}

function BrutCTA({ onClick, label, last }) {
  const t = useTheme();
  const [p, setP] = React.useState(false);
  const [h, setH] = React.useState(false);
  const sc = p ? 0.96 : (h ? 1.04 : 1);
  const ty = (h && !p) ? -2 : 0;
  return (
    <div onPointerDown={() => setP(true)} onPointerUp={() => setP(false)}
      onMouseEnter={() => setH(true)} onMouseLeave={() => { setH(false); setP(false); }} onClick={onClick}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '15px 16px 15px 22px', borderRadius: 18, background: SEM.lime.fill, cursor: 'pointer',
        transform: `translateY(${ty}px) rotate(-2deg) scale(${sc})`, transition: `transform ${t.dur(p ? 140 : 240)}ms ${t.spring}, box-shadow ${t.dur(240)}ms ${t.ease}`, boxShadow: h ? `0 16px 38px ${SEM.lime.glow}0.42)` : `0 10px 28px ${SEM.lime.glow}0.3)` }}>
      <span style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 17, color: SEM.lime.on, letterSpacing: '-0.01em' }}>{label}</span>
      <div style={{ width: 30, height: 30, borderRadius: '50%', background: SEM.lime.on, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <NIcon name="arrow_right" size={16} color={SEM.lime.fill} strokeWidth={2.4}/>
      </div>
    </div>
  );
}

// ── Calm splash (original) ──
function CalmOnboarding({ onDone }) {
  const t = useTheme();
  const [i, setI] = React.useState(0);
  const slides = [
    { eyebrow: 'WELCOME TO NUTRIO', bigNum: '2,000', bigUnit: 'kcal · your daily fuel', title: 'Food logging,\nin one tap', body: 'Snap your plate and Nutrio reads it — calories and macros, estimated in seconds.', icon: 'camera' },
    { eyebrow: 'BUILT AROUND YOU', bigNum: '120+', bigUnit: 'recipes matched to goals', title: 'Recipes that\nfit your day', body: 'Filter by diet, goal, time and macros. We surface what moves you forward.', icon: 'recipe' },
  ];
  const s = slides[i];
  const last = i === slides.length - 1;
  return (
    <div style={{ position: 'absolute', inset: 0, background: NC.canvas, zIndex: 300, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <BgDots opacity={t.dotOpacity}/>
      <GlowRing size={460} mult={1.1} style={{ top: '32%' }}/>
      <TrajectoryArc w={420} h={420} draw delay={120} key={'arc' + i} style={{ right: -120, top: '6%' }} opacity={Math.max(0.32, t.motifOpacity)}/>
      <div style={{ position: 'relative', padding: '60px 24px 0', display: 'flex', justifyContent: 'flex-end' }}>
        <Press onClick={onDone} style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone300, padding: 8 }}>Skip</Press>
      </div>
      <div key={'c' + i} style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 28px', animation: `nutrio-fade-up ${t.dur(420)}ms ${t.ease}` }}>
        <div style={{ width: 56, height: 56, borderRadius: t.radii.lg, background: t.accent.deep, border: `1px solid ${t.accent.soft}`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 26 }}>
          <NIcon name={s.icon} size={26} color={t.accent.a} strokeWidth={1.7}/>
        </div>
        <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: NC.bone300 }}>{s.eyebrow}</div>
        <div style={{ fontFamily: MONO, fontWeight: 500, color: t.accent.a, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.05em', fontSize: t.numFeature, lineHeight: 0.92, marginTop: 10 }}>{s.bigNum}</div>
        <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300, marginTop: 4 }}>{s.bigUnit}</div>
        <div style={{ fontSize: 30, fontWeight: 600, color: NC.bone, letterSpacing: '-0.025em', lineHeight: 1.12, marginTop: 24, whiteSpace: 'pre-line' }}>{s.title}</div>
        <div style={{ fontSize: 15, color: NC.bone200, lineHeight: 1.55, marginTop: 14, maxWidth: 320 }}>{s.body}</div>
      </div>
      <div style={{ position: 'relative', padding: '0 28px calc(40px + var(--safe-bottom))', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {slides.map((_, idx) => (
            <div key={idx} style={{ width: idx === i ? 26 : 8, height: 8, borderRadius: 99, background: idx === i ? t.accent.a : NC.border, transition: `all ${t.dur(280)}ms ${t.ease}` }}/>
          ))}
        </div>
        <PrimaryButton big icon={!last && <NIcon name="arrow_right" size={18} color={t.accent.on} strokeWidth={2}/>}
          onClick={() => last ? onDone() : setI(i + 1)}>
          {last ? 'Get started' : 'Next'}
        </PrimaryButton>
      </div>
    </div>
  );
}

window.Onboarding = Onboarding;

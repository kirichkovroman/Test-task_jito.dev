// nutrio-app.jsx — shell: state, routing, tab bar, sheets, tweaks. Mounts <NutrioApp/>.

const EXPR_MAP   = { Calm: 0.18, Balanced: 0.55, Bold: 1.0 };
const SHAPE_MAP  = { Sharp: 0.12, Soft: 0.5, Organic: 1.0 };
const MOTION_MAP = { Minimal: 0.15, Balanced: 0.55, Playful: 0.92 };
const ACCENT_HEX = { '#C8FF5E': 'lime', '#5FE3B0': 'mint', '#FFB088': 'peach', '#A99BFF': 'iris' };

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "skin": "Expressive",
  "accent": "#C8FF5E",
  "expr": "Bold",
  "shape": "Organic",
  "motion": "Playful"
}/*EDITMODE-END*/;

function NutrioApp() {
  const [tw, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const brut = tw.skin !== 'Calm';

  const theme = React.useMemo(() => makeTheme({
    accent: ACCENT_HEX[tw.accent] || 'lime',
    expr: EXPR_MAP[tw.expr] ?? 0.55,
    shape: SHAPE_MAP[tw.shape] ?? 0.5,
    motion: MOTION_MAP[tw.motion] ?? 0.9,
    brut,
  }), [tw.accent, tw.expr, tw.shape, tw.motion, brut]);

  const [phase, setPhase] = React.useState('onboarding'); // onboarding | app
  const [tab, setTab] = React.useState('today');
  const [log, setLog] = React.useState(SEED_LOG);
  const [animKey, setAnimKey] = React.useState(0);
  const [favs, setFavs] = React.useState(RECIPES.filter(r => r.fav).map(r => r.id));
  const [calorie, setCalorie] = React.useState({ open: false, meal: 'Lunch' });
  const [openRecipe, setOpenRecipe] = React.useState(null);
  const [toast, setToast] = React.useState(null);

  const showToast = (msg) => { setToast(msg); clearTimeout(showToast._t); showToast._t = setTimeout(() => setToast(null), 2600); };

  const goTab = (id) => { setTab(id); if (id === 'today') setAnimKey(k => k + 1); };

  const openCalorie = (meal = 'Lunch') => setCalorie({ open: true, meal });

  const logFood = (entry) => {
    setLog(l => [...l, entry]);
    setCalorie(c => ({ ...c, open: false }));
    setTab('today'); setAnimKey(k => k + 1);
    showToast(`${entry.k} kcal added to ${entry.meal.toLowerCase()}`);
  };

  const toggleFav = (id) => setFavs(f => f.includes(id) ? f.filter(x => x !== id) : [...f, id]);

  const cookRecipe = (r) => {
    setLog(l => [...l, { name: r.title, k: r.k, p: r.p, c: r.c, f: r.f, fi: r.fi, meal: 'Dinner', time: 'Planned', serving: '1 serving', icon: 'salad', tone: r.accentHue }]);
    setOpenRecipe(null); setTab('today'); setAnimKey(k => k + 1);
    showToast(`${r.title} added to dinner`);
  };

  return (
    <NutrioThemeContext.Provider value={theme}>
      <div className="app-root" style={{ position: 'absolute', inset: 0, background: NC.canvas, overflow: 'hidden', fontFamily: SANS, color: NC.bone }}>

        {/* scrollable screen region */}
        <div className="no-scrollbar" style={{ position: 'absolute', inset: 0, overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
          {tab === 'today' && (brut ? (
            <BentoHome log={log} animateKey={animKey}
              onMealTap={() => {}} onAddTo={(m) => openCalorie(m)}
              onScan={() => openCalorie('Lunch')} onRecipes={() => goTab('recipes')}
              onOpenRecipe={(r) => setOpenRecipe(r)}/>
          ) : (
            <HomeScreen log={log} animateKey={animKey}
              onMealTap={() => {}} onAddTo={(m) => openCalorie(m)}
              onScan={() => openCalorie('Lunch')} onRecipes={() => goTab('recipes')}
              onOpenRecipe={(r) => setOpenRecipe(r)}/>
          ))}
          {tab === 'recipes' && (
            <RecipesScreen favs={favs} onToggleFav={toggleFav} onOpen={(r) => setOpenRecipe(r)}/>
          )}
          {tab === 'saved' && (
            <SavedScreen favs={favs} onToggleFav={toggleFav} onOpen={(r) => setOpenRecipe(r)}/>
          )}
          {tab === 'you' && <YouScreen log={log}/>}
        </div>

        {/* recipe detail overlay */}
        {openRecipe && (
          <RecipeDetail recipe={openRecipe} fav={favs.includes(openRecipe.id)}
            onToggleFav={() => toggleFav(openRecipe.id)} onBack={() => setOpenRecipe(null)} onCook={cookRecipe}/>
        )}

        {/* tab bar */}
        <NutrioTabBar tab={tab} onTab={goTab} onAdd={() => openCalorie('Lunch')} brut={brut}/>

        {/* calorie flow sheet */}
        <Sheet open={calorie.open} onClose={() => setCalorie(c => ({ ...c, open: false }))}>
          <CalorieFlow defaultMeal={calorie.meal} onLog={logFood} onClose={() => setCalorie(c => ({ ...c, open: false }))}/>
        </Sheet>

        {/* toast */}
        <Toast msg={toast}/>

        {/* onboarding */}
        {phase === 'onboarding' && <Onboarding onDone={() => setPhase('app')}/>}

        {/* tweaks */}
        <TweaksPanel>
          <TweakSection label="Visual skin"/>
          <TweakRadio label="Skin" value={tw.skin} options={['Expressive', 'Calm']} onChange={(v) => setTweak('skin', v)}/>
          <TweakSection label="Brand accent"/>
          <TweakColor label="Accent" value={tw.accent}
            options={['#C8FF5E', '#5FE3B0', '#FFB088', '#A99BFF']}
            onChange={(v) => setTweak('accent', v)}/>
          <TweakSection label="Expression"/>
          <TweakRadio label="Expressiveness" value={tw.expr} options={['Calm', 'Balanced', 'Bold']} onChange={(v) => setTweak('expr', v)}/>
          <TweakRadio label="Card shape" value={tw.shape} options={['Sharp', 'Soft', 'Organic']} onChange={(v) => setTweak('shape', v)}/>
          <TweakRadio label="Motion" value={tw.motion} options={['Minimal', 'Balanced', 'Playful']} onChange={(v) => setTweak('motion', v)}/>
        </TweaksPanel>
      </div>
    </NutrioThemeContext.Provider>
  );
}

// ─── floating tab bar with center FAB ───
function NutrioTabBar({ tab, onTab, onAdd, brut }) {
  const t = useTheme();
  const TAB_SEM = { today: 'violet', recipes: 'orange', saved: 'coral', you: 'sky' };
  const Tab = ({ id, icon, label }) => {
    const active = tab === id;
    const s = brut ? SEM[TAB_SEM[id]] : null;
    const aColor = brut ? s.fill : t.accent.a;
    const aBg = brut ? s.fill : t.accent.deep;
    const aFg = brut ? s.on : t.accent.a;
    return (
      <Press onClick={() => onTab(id)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, padding: '4px 6px', minWidth: 48 }}>
        <div style={{ width: 44, height: 26, borderRadius: 99, display: 'flex', alignItems: 'center', justifyContent: 'center', background: active ? aBg : 'transparent', transition: `background ${t.dur(200)}ms ${t.ease}` }}>
          <NIcon name={icon} size={20} color={active ? aFg : NC.bone300} strokeWidth={1.7} fill={active && icon === 'heart' ? aFg : 'none'}/>
        </div>
        <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.06em', color: active ? aColor : NC.bone300 }}>{label}</span>
      </Press>
    );
  };
  return (
    <div style={{
      position: 'absolute', bottom: 26, left: 14, right: 14, height: 70,
      background: 'rgba(20,24,22,0.88)', backdropFilter: 'blur(20px) saturate(180%)', WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      borderRadius: brut ? 30 : 26, border: '1px solid rgba(255,255,255,0.06)', boxShadow: '0 8px 30px rgba(0,0,0,0.45)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px', zIndex: 100,
    }}>
      <Tab id="today" icon="home" label="Today"/>
      <Tab id="recipes" icon="recipe" label="Recipes"/>
      <Press onClick={onAdd} spring hover={1.08} lift={2} style={{ position: 'relative', top: -16 }}>
        <div style={{ width: 58, height: 58, borderRadius: brut ? 20 : '50%', background: t.accent.a, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: brut ? `rotate(${t.tilt(-8)}deg)` : 'none', boxShadow: `0 0 0 6px ${t.accent.glow}0.14), 0 10px 28px ${t.glow(1.2)}` }}>
          <NIcon name="plus" size={26} color={t.accent.on} strokeWidth={2.3} style={{ transform: brut ? `rotate(${t.tilt(8)}deg)` : 'none' }}/>
        </div>
      </Press>
      <Tab id="saved" icon="heart" label="Saved"/>
      <Tab id="you" icon="user" label="You"/>
    </div>
  );
}

// ─── toast ───
function Toast({ msg }) {
  const t = useTheme();
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => { setShown(!!msg); }, [msg]);
  return (
    <div style={{
      position: 'absolute', bottom: 112, left: '50%', zIndex: 250,
      transform: `translateX(-50%) translateY(${shown ? 0 : 16}px)`, opacity: shown ? 1 : 0,
      transition: `all ${t.dur(280)}ms ${t.spring}`, pointerEvents: 'none',
      display: 'flex', alignItems: 'center', gap: 9, padding: '11px 16px',
      background: NC.raised, border: `1px solid ${t.accent.soft}`, borderRadius: 99, boxShadow: '0 8px 30px rgba(0,0,0,0.5)',
      whiteSpace: 'nowrap',
    }}>
      <div style={{ width: 20, height: 20, borderRadius: '50%', background: t.accent.a, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <NIcon name="check" size={13} color={t.accent.on} strokeWidth={2.6}/>
      </div>
      <span style={{ fontSize: 13.5, fontWeight: 500, color: NC.bone }}>{msg}</span>
    </div>
  );
}

window.NutrioApp = NutrioApp;

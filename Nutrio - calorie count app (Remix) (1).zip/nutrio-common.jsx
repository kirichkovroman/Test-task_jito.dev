// nutrio-common.jsx — shared Nutrio components, theme-aware (read useTheme()).
// Exports: Press, BgDots, GlowRing, TrajectoryArc, useCountUp, MacroRing, MacroBar,
//   Chip, MonoChip, PrimaryButton, GhostButton, StatTile, SectionTitle, Avatar,
//   IconBtn, MacroPills, MacroDot, Sheet, Segmented, ProgressArc

// ─── Press wrapper (scale on tap; subtle lift/scale on hover; spring from theme.M) ───
function Press({ children, onClick, style = {}, as = 'div', spring = false, scale = 0.96, hover = 0, lift = 0, className }) {
  const t = useTheme();
  const [p, setP] = React.useState(false);
  const [h, setH] = React.useState(false);
  const E = as;
  const curve = spring ? t.spring : t.ease;
  const sc = p ? scale : (h && hover ? hover : 1);
  const ty = (h && !p && lift) ? -lift : 0;
  return (
    <E
      className={className}
      onPointerDown={() => setP(true)}
      onPointerUp={() => setP(false)}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => { setH(false); setP(false); }}
      onClick={onClick}
      style={{
        transition: `transform ${t.dur(h && !p ? 240 : 110)}ms ${curve}`,
        transform: `translateY(${ty}px) scale(${sc})`,
        cursor: onClick ? 'pointer' : 'default',
        userSelect: 'none', WebkitTapHighlightColor: 'transparent',
        ...style,
      }}>
      {children}
    </E>
  );
}

// ─── Dot grid texture ───
function BgDots({ opacity, size = 14, color = '251,249,240', style = {} }) {
  const t = useTheme();
  const op = opacity == null ? t.dotOpacity : opacity;
  return (
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none',
      backgroundImage: `radial-gradient(circle at 1px 1px, rgba(${color},${op}) 1px, transparent 0)`,
      backgroundSize: `${size}px ${size}px`, ...style,
    }}/>
  );
}

// ─── Radial glow halo ───
function GlowRing({ size = 280, mult = 1, blur = 10, style = {} }) {
  const t = useTheme();
  const c = t.accent.glow;
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)',
      width: size, height: size, borderRadius: '50%',
      background: `radial-gradient(circle, ${c}${(t.E*0.5*mult+0.18).toFixed(3)}), ${c}0.05) 38%, transparent 70%)`,
      filter: `blur(${blur}px)`, pointerEvents: 'none', ...style,
    }}/>
  );
}

// ─── Trajectory arc motif (the swept line + endpoint dot) ───
function TrajectoryArc({ w = 200, h = 200, stroke, opacity, draw = false, delay = 0, style = {} }) {
  const t = useTheme();
  const col = stroke || t.accent.a;
  const op = opacity == null ? t.motifOpacity : opacity;
  const len = 240;
  return (
    <svg width={w} height={h} viewBox="0 0 120 120" fill="none" style={{ position: 'absolute', pointerEvents: 'none', ...style }}>
      <path d="M8 112 Q 34 30, 112 16" stroke={col} strokeWidth="2.4" strokeLinecap="round" fill="none"
            opacity={op}
            style={draw ? { strokeDasharray: len, ['--dash']: len, animation: `nutrio-draw ${t.dur(900)}ms ${t.ease} ${delay}ms both` } : undefined}/>
      <circle cx="112" cy="16" r="4.5" fill={col} opacity={Math.min(1, op + 0.3)}/>
      <circle cx="8" cy="112" r="2.6" fill={col} opacity={op * 0.6}/>
    </svg>
  );
}

// ─── Count-up hook ───
function useCountUp(target, duration = 900, deps = []) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    let raf, start;
    const tick = (ts) => {
      if (!start) start = ts;
      const p = Math.min(1, (ts - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setV(Math.round(target * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, ...deps]);
  return v;
}

// ─── Macro dot + pills ───
function MacroDot({ color, size = 8 }) {
  return <div style={{ width: size, height: size, borderRadius: '50%', background: color, flexShrink: 0 }}/>;
}
function MacroPills({ macros, compact = false }) {
  const t = useTheme();
  const rows = [
    { key: 'p', label: 'Protein', color: NC.protein, unit: 'g' },
    { key: 'c', label: 'Carbs',   color: NC.carbs,   unit: 'g' },
    { key: 'f', label: 'Fat',     color: NC.fat,     unit: 'g' },
    { key: 'fi', label: 'Fiber',  color: NC.fiber,   unit: 'g' },
  ];
  return (
    <div style={{ display: 'flex', gap: compact ? 8 : 10 }}>
      {rows.map(r => (
        <div key={r.key} style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, minWidth: 0 }}>
            <MacroDot color={r.color} size={6}/>
            <span style={{ fontFamily: MONO, fontSize: 8.5, letterSpacing: '0.06em', textTransform: 'uppercase', color: NC.bone300, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.label}</span>
          </div>
          <span style={{ fontFamily: MONO, fontSize: compact ? 14 : 16, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em' }}>
            {macros[r.key] || 0}{r.unit}
          </span>
        </div>
      ))}
    </div>
  );
}

// ─── Macro bar ───
function MacroBar({ name, color, value, goal, unit = 'g' }) {
  const t = useTheme();
  const pct = Math.min(100, Math.round((value / goal) * 100));
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <MacroDot color={color}/>
      <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone200, width: 52 }}>{name}</div>
      <div style={{ flex: 1, height: 5, background: NC.sunken, borderRadius: 99, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: pct + '%', background: color, borderRadius: 99, transition: `width ${t.dur(700)}ms ${t.ease}` }}/>
      </div>
      <div style={{ fontFamily: MONO, fontSize: 11, color: NC.bone, width: 58, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{value}{unit}</div>
    </div>
  );
}

// ─── MacroRing — hero viz, number size scales with expressiveness ───
function MacroRing({ kcal = 1420, goal = 2000, size = 224, animateKey = 0 }) {
  const t = useTheme();
  const animated = useCountUp(kcal, t.dur(900), [animateKey]);
  const pct = Math.min(1, animated / goal);
  const C = 2 * Math.PI * 90;
  const left = Math.max(0, goal - animated);
  const gid = 'ringGrad_' + t.accentKey;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <GlowRing size={size * 1.45}/>
      <svg width={size} height={size} viewBox="0 0 200 200" style={{ transform: 'rotate(-90deg)', position: 'relative' }}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={t.accent.grad[0]}/>
            <stop offset="100%" stopColor={t.accent.grad[1]}/>
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="90" fill="none" stroke={NC.sunken} strokeWidth="12"/>
        <circle cx="100" cy="100" r="90" fill="none" stroke={`url(#${gid})`} strokeWidth="12" strokeLinecap="round"
                strokeDasharray={C} strokeDashoffset={C * (1 - pct)}
                style={{ transition: `stroke-dashoffset ${t.dur(900)}ms ${t.ease}`, filter: `drop-shadow(0 0 ${6 + t.E*8}px ${t.glow(1.2)})` }}/>
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, letterSpacing: '0.2em', textTransform: 'uppercase', color: NC.bone300 }}>Eaten · kcal</div>
        <div style={{ fontFamily: MONO, fontSize: t.numHero * 0.62, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.04em', lineHeight: 1, marginTop: 6 }}>
          {animated.toLocaleString()}
        </div>
        <div style={{ fontFamily: MONO, fontSize: 10, color: NC.bone300, marginTop: 7, letterSpacing: '0.05em' }}>
          <span style={{ color: t.accent.a }}>{left.toLocaleString()}</span> left · {Math.round(pct * 100)}%
        </div>
      </div>
    </div>
  );
}

// ─── ProgressArc — small semicircle gauge ───
function ProgressArc({ pct = 0.5, size = 56, color }) {
  const t = useTheme();
  const c = color || t.accent.a;
  const C = Math.PI * 26;
  return (
    <svg width={size} height={size / 2 + 6} viewBox="0 0 64 38">
      <path d="M6 32 A26 26 0 0 1 58 32" fill="none" stroke={NC.sunken} strokeWidth="6" strokeLinecap="round"/>
      <path d="M6 32 A26 26 0 0 1 58 32" fill="none" stroke={c} strokeWidth="6" strokeLinecap="round"
            strokeDasharray={C} strokeDashoffset={C * (1 - pct)}
            style={{ transition: `stroke-dashoffset ${t.dur(700)}ms ${t.ease}` }}/>
    </svg>
  );
}

// ─── Chips ───
function Chip({ children, active, onClick, icon }) {
  const t = useTheme();
  return (
    <Press onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '8px 14px', borderRadius: t.radii.pill, fontSize: 13, fontWeight: 500,
      background: active ? t.accent.a : NC.surface,
      color: active ? t.accent.on : NC.bone,
      border: active ? 'none' : `1px solid ${NC.border}`,
      whiteSpace: 'nowrap',
      boxShadow: active ? `0 4px 16px ${t.glow(0.8)}` : 'none',
    }}>{icon}{children}</Press>
  );
}
function MonoChip({ children, accent, color }) {
  const t = useTheme();
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: t.radii.xs,
      fontFamily: MONO, fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase',
      background: accent ? t.accent.deep : NC.surface,
      color: color || (accent ? t.accent.a : NC.bone200),
      border: accent ? `1px solid ${t.accent.soft}` : `1px solid ${NC.border}`,
    }}>{children}</span>
  );
}

// ─── Buttons ───
function PrimaryButton({ children, onClick, icon, full, big }) {
  const t = useTheme();
  return (
    <Press onClick={onClick} spring hover={1.025} lift={2} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      padding: big ? '17px 24px' : '14px 22px', borderRadius: t.radii.md,
      background: t.accent.a, color: t.accent.on,
      fontSize: big ? 16 : 15, fontWeight: 600, minHeight: big ? 54 : 48,
      width: full ? '100%' : undefined, boxSizing: 'border-box', border: 'none',
      boxShadow: `0 0 0 1px ${t.accent.deep}, 0 10px 30px ${t.glow(1.1)}`,
    }}>{icon}{children}</Press>
  );
}
function GhostButton({ children, onClick, icon, full }) {
  const t = useTheme();
  return (
    <Press onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      padding: '13px 18px', borderRadius: t.radii.md, background: NC.surface,
      color: NC.bone, border: `1px solid ${NC.border}`,
      fontSize: 15, fontWeight: 500, minHeight: 48, width: full ? '100%' : undefined, boxSizing: 'border-box',
    }}>{icon}{children}</Press>
  );
}

// ─── Stat tile ───
function StatTile({ label, value, unit, delta, deltaType = 'neutral', accent, icon }) {
  const t = useTheme();
  const deltaColors = {
    up:      { bg: '#2A1E0A',     fg: NC.warning },
    down:    { bg: t.accent.deep, fg: t.accent.a },
    neutral: { bg: NC.raised,     fg: NC.bone200 },
  }[deltaType];
  return (
    <div style={{
      padding: 18, background: accent ? t.accent.deep : NC.surface, borderRadius: t.radii.lg,
      border: accent ? `1px solid ${t.accent.soft}` : 'none', position: 'relative', overflow: 'hidden',
    }}>
      {accent && <TrajectoryArc w={90} h={90} style={{ right: -14, top: -14 }} opacity={t.motifOpacity * 0.8}/>}
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
        {icon && <NIcon name={icon} size={12} color={accent ? t.accent.a : NC.bone300}/>}
        <div style={{ fontFamily: MONO, fontSize: 9, fontWeight: 500, letterSpacing: '0.16em', textTransform: 'uppercase', color: accent ? t.accent.a : NC.bone300 }}>{label}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 12, position: 'relative' }}>
        <span style={{ fontFamily: MONO, fontSize: 30, fontWeight: 500, color: accent ? t.accent.a : NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.03em', lineHeight: 1 }}>{value}</span>
        {unit && <span style={{ fontFamily: MONO, fontSize: 11, color: accent ? t.accent.a : NC.bone300 }}>{unit}</span>}
      </div>
      {delta && (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 3, marginTop: 12, padding: '3px 8px', borderRadius: t.radii.xs, fontFamily: MONO, fontSize: 10, letterSpacing: '0.04em', background: deltaColors.bg, color: deltaColors.fg }}>{delta}</div>
      )}
    </div>
  );
}

// ─── Section title ───
function SectionTitle({ children, action, onAction, style = {} }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 20px', marginBottom: 12, ...style }}>
      <h2 style={{ margin: 0, fontFamily: MONO, fontSize: 10, fontWeight: 500, color: NC.bone300, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{children}</h2>
      {action && <Press as="span" onClick={onAction} style={{ fontFamily: MONO, fontSize: 10, color: t.accent.a, letterSpacing: '0.06em' }}>{action}</Press>}
    </div>
  );
}

// ─── Avatar ───
function Avatar({ initials = 'AC', size = 38, onClick }) {
  return (
    <Press onClick={onClick} style={{
      width: size, height: size, borderRadius: '50%', background: NC.peachDeep,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: MONO, fontSize: size * 0.34, fontWeight: 500, color: NC.peach300, border: `1px solid ${NC.border}`,
    }}>{initials}</Press>
  );
}

// ─── Icon button ───
function IconBtn({ icon, onClick, badge, active }) {
  const t = useTheme();
  return (
    <Press onClick={onClick} style={{
      width: 42, height: 42, borderRadius: t.radii.sm + 2,
      background: active ? t.accent.deep : NC.surface,
      border: `1px solid ${active ? t.accent.soft : NC.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative',
    }}>
      <NIcon name={icon} size={19} color={active ? t.accent.a : NC.bone}/>
      {badge && <div style={{ position: 'absolute', top: 9, right: 9, width: 6, height: 6, borderRadius: '50%', background: t.accent.a }}/>}
    </Press>
  );
}

// ─── Segmented control ───
function Segmented({ options, value, onChange }) {
  const t = useTheme();
  return (
    <div style={{ display: 'flex', background: NC.sunken, borderRadius: t.radii.sm + 2, padding: 4, gap: 4 }}>
      {options.map(o => {
        const active = o.value === value;
        return (
          <Press key={o.value} onClick={() => onChange(o.value)} style={{
            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            padding: '9px 8px', borderRadius: t.radii.sm,
            background: active ? NC.raised : 'transparent',
            color: active ? NC.bone : NC.bone300,
            fontSize: 13, fontWeight: 500,
            boxShadow: active ? '0 2px 8px rgba(0,0,0,0.3)' : 'none',
            transition: `all ${t.dur(160)}ms ${t.ease}`,
          }}>
            {o.icon && <NIcon name={o.icon} size={15} color={active ? t.accent.a : NC.bone300}/>}
            {o.label}
          </Press>
        );
      })}
    </div>
  );
}

// ─── Bottom sheet (slides up, scrim) ───
function Sheet({ open, onClose, children, maxH = '86%' }) {
  const t = useTheme();
  const [mounted, setMounted] = React.useState(open);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (open) { setMounted(true); requestAnimationFrame(() => requestAnimationFrame(() => setShown(true))); }
    else { setShown(false); const id = setTimeout(() => setMounted(false), t.dur(300)); return () => clearTimeout(id); }
  }, [open]);
  if (!mounted) return null;
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 200, display: 'flex', alignItems: 'flex-end' }}>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(6,8,7,0.72)',
        opacity: shown ? 1 : 0, transition: `opacity ${t.dur(280)}ms ${t.ease}`,
      }}/>
      <div style={{
        position: 'relative', width: '100%', maxHeight: maxH,
        background: NC.raised, borderTopLeftRadius: t.radii.xxl, borderTopRightRadius: t.radii.xxl,
        boxShadow: '0 -8px 40px rgba(0,0,0,0.6)', overflow: 'hidden',
        transform: shown ? 'translateY(0)' : 'translateY(102%)',
        transition: `transform ${t.dur(320)}ms ${shown ? t.spring : t.ease}`,
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 4px', flexShrink: 0 }}>
          <div style={{ width: 40, height: 5, borderRadius: 99, background: NC.border }}/>
        </div>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  Press, BgDots, GlowRing, TrajectoryArc, useCountUp,
  MacroRing, MacroBar, MacroPills, MacroDot, ProgressArc,
  Chip, MonoChip, PrimaryButton, GhostButton, StatTile,
  SectionTitle, Avatar, IconBtn, Segmented, Sheet,
});

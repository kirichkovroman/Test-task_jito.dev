// nutrio-theme.jsx — resolves the tweak dials into a concrete theme object.
// Exports: NC (static palette), MONO, lerp, ACCENTS, NutrioThemeContext, useTheme, makeTheme, useParallax

// ── Static base palette (DS tokens, mirrored for inline styles) ──
const NC = {
  canvas: '#0E1110', surface: '#191E1B', raised: '#222824', sunken: '#141816',
  border: '#2A312D', borderStrong: '#353D38',
  bone: '#FBF9F0', bone100: '#F1EEDF', bone200: '#DAD6C5', bone300: '#B0AC9C', bone400: '#888679',
  ink400: '#6C746F', ink300: '#8E958F', ink500: '#4A534D', ink600: '#353D38', ink700: '#222824',
  lime300: '#C8FF5E', lime200: '#D4FF80', lime400: '#B5F03F', lime600: '#7BB014', lime700: '#5C8410',
  limeDeep: '#1F2814', limeGlow: 'rgba(200, 255, 94, 0.25)',
  peach300: '#FFC9A8', peach400: '#FFB088', peachDeep: '#2A1B12',
  carbs: '#FFB547', protein: '#C8FF5E', fat: '#FF9F73', fiber: '#5FE3B0',
  success: '#5FE3B0', warning: '#FFB547', danger: '#FF7A6B', info: '#7CB8FF',
};
const MONO = "'Geist Mono', 'JetBrains Mono', 'SF Mono', Menlo, monospace";
const SANS = "'Geist', system-ui, -apple-system, sans-serif";
const DISPLAY = "'Bricolage Grotesque', 'Geist', system-ui, sans-serif";
const SERIF = "'Instrument Serif', Georgia, serif";

// ── Semantic vibrant palette (Expressive skin) — used together, one screen ──
// fill = solid card · on = primary text on fill · mut = muted label on fill · ink = deep tint surface
const SEM = {
  violet: { key: 'violet', fill: '#6457D6', on: '#FFFFFF', mut: 'rgba(255,255,255,0.90)', ink: '#191634', glow: 'rgba(100,87,214,', soft: 'rgba(100,87,214,0.20)', light: '#C9C2FF' },
  amber:  { key: 'amber',  fill: '#F4C20D', on: '#1A1400', mut: 'rgba(26,20,0,0.74)',    ink: '#2A2200', glow: 'rgba(244,194,13,',  soft: 'rgba(244,194,13,0.18)',  light: '#FFE588' },
  orange: { key: 'orange', fill: '#FF7A2F', on: '#2A1304', mut: 'rgba(42,19,4,0.82)',    ink: '#2C1404', glow: 'rgba(255,122,47,',  soft: 'rgba(255,122,47,0.18)',  light: '#FFC0A0' },
  lime:   { key: 'lime',   fill: '#C8FF5E', on: '#0E1110', mut: 'rgba(14,17,16,0.66)',   ink: '#1F2814', glow: 'rgba(200,255,94,',  soft: 'rgba(200,255,94,0.18)',  light: '#E4FFAE' },
  coral:  { key: 'coral',  fill: '#FF5E57', on: '#2E0908', mut: 'rgba(46,9,8,0.88)',     ink: '#2C0B0A', glow: 'rgba(255,94,87,',   soft: 'rgba(255,94,87,0.18)',   light: '#FFB3AF' },
  mint:   { key: 'mint',   fill: '#54E0A8', on: '#04140D', mut: 'rgba(4,20,13,0.66)',    ink: '#0F2520', glow: 'rgba(84,224,168,',  soft: 'rgba(84,224,168,0.18)',  light: '#A8F2D4' },
  sky:    { key: 'sky',    fill: '#5BB8FF', on: '#021426', mut: 'rgba(2,20,38,0.7)',     ink: '#0A2236', glow: 'rgba(91,184,255,',  soft: 'rgba(91,184,255,0.18)',  light: '#B3DDFF' },
};

const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (x) => Math.max(0, Math.min(1, x));

// ── Accent families (the "accent color" tweak) ──
const ACCENTS = {
  lime: {
    key: 'lime', label: 'Lime',
    a: '#C8FF5E', a2: '#D4FF80', a3: '#B5F03F', deep: '#1F2814',
    glow: 'rgba(200,255,94,', on: '#0E1110', soft: 'rgba(200,255,94,0.16)',
    grad: ['#D4FF80', '#7BB014'],
  },
  mint: {
    key: 'mint', label: 'Mint',
    a: '#5FE3B0', a2: '#8AF0C8', a3: '#3CCB95', deep: '#0F2520',
    glow: 'rgba(95,227,176,', on: '#06140F', soft: 'rgba(95,227,176,0.16)',
    grad: ['#8AF0C8', '#1E9E72'],
  },
  peach: {
    key: 'peach', label: 'Peach',
    a: '#FFB088', a2: '#FFC9A8', a3: '#F08F62', deep: '#2A1B12',
    glow: 'rgba(255,176,136,', on: '#1A0E07', soft: 'rgba(255,176,136,0.18)',
    grad: ['#FFC9A8', '#E07A4B'],
  },
  iris: {
    key: 'iris', label: 'Iris',
    a: '#A99BFF', a2: '#C2B8FF', a3: '#8E7BF5', deep: '#171430',
    glow: 'rgba(169,155,255,', on: '#0B0A18', soft: 'rgba(169,155,255,0.18)',
    grad: ['#C2B8FF', '#6F58E0'],
  },
};

// ── Build the resolved theme from raw tweak values ──
// accent: key string · expr: 0..1 (calm→bold) · shape: 0..1 (sharp→organic) · motion: 0..1 · brut: bool
function makeTheme({ accent = 'lime', expr = 0.5, shape = 0.5, motion = 0.6, brut = false } = {}) {
  const ac = ACCENTS[accent] || ACCENTS.lime;
  // Dials drive the look directly (no clamping) so every tweak is clearly visible.
  // The Expressive skin just ships with bold defaults (set in TWEAK_DEFAULTS).
  const E = clamp01(expr), S = clamp01(shape), M = clamp01(motion);

  // radius multiplier: sharp (0) → tight 0.5x, organic (1) → loose 1.55x
  const rk = lerp(0.5, 1.55, S);
  const radii = {
    xs: Math.round(6 * rk), sm: Math.round(10 * rk), md: Math.round(14 * rk),
    lg: Math.round(20 * rk), xl: Math.round(28 * rk), xxl: Math.round(36 * rk),
    pill: 9999,
  };

  // glow alpha scales with expressiveness
  const glow = (mult = 1) => ac.glow + (lerp(0.1, 0.4, E) * mult).toFixed(3) + ')';

  // big number moment sizes
  const numHero = Math.round(lerp(58, 92, E));   // ring center number
  const numFeature = Math.round(lerp(76, 132, E)); // full-bleed moments

  // motif (trajectory arcs, concentric rings, dot grid) prominence
  const motifOpacity = lerp(0.05, 0.5, E);
  const dotOpacity = lerp(0.04, 0.1, E);

  // motion
  const ease = 'cubic-bezier(0.2, 0.8, 0.2, 1)';
  const spring = M > 0.45 ? 'cubic-bezier(0.34, 1.5, 0.5, 1)' : ease;
  const dur = (base) => Math.round(base * lerp(0.55, 1.15, M));
  const parallaxMax = lerp(0, 9, M); // deg of tilt

  // expressiveness drives how far decorative tiles tilt (0 = perfectly straight)
  const tiltScale = lerp(0, 1.35, E);
  const tilt = (deg) => +(deg * tiltScale).toFixed(2);
  // blob/glow decoration opacity multiplier
  const decor = lerp(0.35, 1, E);

  return {
    accent: ac, accentKey: accent,
    brut,
    E, S, M,
    radii, glow, tilt, tiltScale, decor,
    numHero, numFeature, motifOpacity, dotOpacity,
    ease, spring, dur, parallaxMax,
    NC, MONO, SANS, DISPLAY, SERIF, SEM,
    sem: (k) => SEM[k] || SEM.lime,
  };
}

const NutrioThemeContext = React.createContext(makeTheme());
const useTheme = () => React.useContext(NutrioThemeContext);

// recipe accentHue → semantic color (Expressive skin)
const SEM_FOR_HUE = { lime: 'lime', mint: 'mint', peach: 'orange', iris: 'violet' };
function recipeSem(recipe) { return SEM[SEM_FOR_HUE[recipe && recipe.accentHue] || 'lime']; }

// ── Pointer parallax hook (card tilt; intensity from theme.M) ──
function useParallax(maxDeg = 8) {
  const ref = React.useRef(null);
  const [tf, setTf] = React.useState('');
  const onMove = (e) => {
    const el = ref.current; if (!el || maxDeg <= 0) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setTf(`perspective(700px) rotateY(${px * maxDeg}deg) rotateX(${-py * maxDeg}deg)`);
  };
  const reset = () => setTf('');
  return { ref, style: { transform: tf || 'perspective(700px)', transition: tf ? 'none' : 'transform 400ms cubic-bezier(0.2,0.8,0.2,1)' }, onMove, reset };
}

Object.assign(window, { NC, MONO, SANS, DISPLAY, SERIF, SEM, lerp, ACCENTS, makeTheme, NutrioThemeContext, useTheme, useParallax, SEM_FOR_HUE, recipeSem });

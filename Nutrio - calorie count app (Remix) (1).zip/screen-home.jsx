// screen-home.jsx — Today dashboard. Hero number moment + dual entry points to both flows.

function HomeScreen({ log, animateKey, onMealTap, onAddTo, onScan, onRecipes, onOpenRecipe }) {
  const t = useTheme();
  const goal = 2000;
  const totalKcal = log.reduce((a, m) => a + m.k, 0);
  const macros = { p: 0, c: 0, f: 0, fi: 0 };
  log.forEach(m => { macros.p += m.p||0; macros.c += m.c||0; macros.f += m.f||0; macros.fi += m.fi||0; });

  const meals = [
    { name: 'Breakfast', goal: 500 },
    { name: 'Lunch',     goal: 700 },
    { name: 'Dinner',    goal: 600 },
    { name: 'Snacks',    goal: 200 },
  ].map(g => ({ ...g, items: log.filter(m => m.meal === g.name) }));

  const recmd = RECIPES.filter(r => r.kcalLevel === 'dinner').slice(0, 4);
  const week = [1280, 1640, 1490, 2010, 1720, 1880, totalKcal];

  return (
    <div style={{ paddingBottom: 132, animation: `nutrio-fade ${t.dur(300)}ms ${t.ease}` }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', padding: '64px 20px 14px' }}>
        <div>
          <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300 }}>THU · 28 MAY</div>
          <div style={{ fontSize: 24, fontWeight: 500, color: NC.bone, letterSpacing: '-0.02em', marginTop: 4, whiteSpace: 'nowrap' }}>Good morning, <span style={{ color: t.accent.a }}>Alex</span></div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <IconBtn icon="bell" badge/>
          <Avatar/>
        </div>
      </div>

      {/* HERO — ring + macro legend */}
      <div style={{
        margin: '0 20px 14px', padding: '26px 20px 22px',
        background: NC.raised, borderRadius: t.radii.xxl, position: 'relative', overflow: 'hidden',
      }}>
        <BgDots/>
        <TrajectoryArc w={230} h={230} style={{ right: -56, top: -52 }} draw delay={150}/>
        <div style={{ position: 'absolute', right: -70, top: -70, width: 220, height: 220, borderRadius: '50%', border: `1px solid ${t.accent.glow}${(0.06+t.E*0.08).toFixed(2)})` }}/>

        <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <MacroRing kcal={totalKcal} goal={goal} animateKey={animateKey}/>
          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <MonoChip accent>↗ 8% vs last week</MonoChip>
            <MonoChip>{Math.round(macros.p/110*100)}% protein</MonoChip>
          </div>
        </div>

        <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 10, position: 'relative' }}>
          <MacroBar name="Carbs"   color={NC.carbs}   value={macros.c}  goal={250}/>
          <MacroBar name="Protein" color={NC.protein} value={macros.p}  goal={110}/>
          <MacroBar name="Fat"     color={NC.fat}     value={macros.f}  goal={70}/>
          <MacroBar name="Fiber"   color={NC.fiber}   value={macros.fi} goal={28}/>
        </div>
      </div>

      {/* WEEKLY TREND — decorative chart card */}
      <div style={{ margin: '0 20px 22px', padding: 18, background: NC.surface, borderRadius: t.radii.xl, position: 'relative', overflow: 'hidden' }}>
        <TrajectoryArc w={130} h={130} style={{ right: -26, top: -22 }} opacity={0.16}/>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: MONO, fontSize: 9.5, fontWeight: 500, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300 }}>This week · kcal trend</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8 }}>
              <span style={{ fontFamily: MONO, fontWeight: 500, fontSize: 28, color: NC.bone, letterSpacing: '-0.04em', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>1,673</span>
              <span style={{ fontFamily: MONO, fontSize: 11, color: NC.bone300 }}>avg/day</span>
            </div>
          </div>
          <MonoChip accent>↗ 8% vs last</MonoChip>
        </div>
        <div style={{ marginTop: 16, position: 'relative' }}>
          <BarField data={week.map(v => Math.round(v/20))} color={t.accent.a} height={52} highlightLast rounded/>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 9, fontFamily: MONO, fontSize: 9, letterSpacing: '0.1em', color: NC.bone400 }}>
          {['M','T','W','T','F','S','S'].map((d,i)=><span key={i}>{d}</span>)}
        </div>
      </div>

      {/* DUAL ENTRY POINTS — the two core flows */}
      <div style={{ margin: '0 20px 22px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <ActionCard
          onClick={onScan} primary
          eyebrow="LOG IN SECONDS" title="Snap a meal"
          sub="AI reads the plate" icon="camera"/>
        <ActionCard
          onClick={onRecipes}
          eyebrow="FOR YOUR GOALS" title="Find recipes"
          sub="Matched to you" icon="recipe"/>
      </div>

      {/* QUICK STATS */}
      <div style={{ margin: '0 20px 26px', display: 'grid', gridTemplateColumns: '1.3fr 1fr 1fr', gap: 10 }}>
        <StatTile label="Streak" value="5" unit="days" accent icon="flame"/>
        <StatTile label="Water"  value="1.4" unit="L" delta="↗ on track" deltaType="down"/>
        <StatTile label="Sleep"  value="7.2" unit="h" delta="↘ –30m" deltaType="up"/>
      </div>

      {/* MEALS */}
      <SectionTitle action="↗ Day plan">Today’s meals</SectionTitle>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {meals.map(group => {
          const kc = group.items.reduce((s, i) => s + i.k, 0);
          return (
            <div key={group.name}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 24px 8px' }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
                  <span style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, color: NC.bone, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{group.name}</span>
                  {group.items[0]?.time && <span style={{ fontFamily: MONO, fontSize: 10, color: NC.bone400, letterSpacing: '0.05em' }}>· {group.items[0].time}</span>}
                </div>
                <span style={{ fontFamily: MONO, fontSize: 11, color: NC.bone200, fontVariantNumeric: 'tabular-nums' }}>
                  {kc} / {group.goal} kcal
                </span>
              </div>
              <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
                {group.items.length === 0 ? (
                  <Press onClick={() => onAddTo(group.name)} style={{
                    padding: '14px 16px', borderRadius: t.radii.md, border: `1px dashed ${NC.border}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  }}>
                    <span style={{ fontSize: 13, color: NC.bone300 }}>Add to {group.name.toLowerCase()}</span>
                    <NIcon name="plus" size={16} color={NC.bone300}/>
                  </Press>
                ) : group.items.map((item, i) => (
                  <FoodRow key={i} item={item} onClick={() => onMealTap(item)}/>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* RECOMMENDED */}
      <SectionTitle action="See all" onAction={onRecipes} style={{ marginTop: 26 }}>Recommended for dinner</SectionTitle>
      <div className="no-scrollbar" style={{ padding: '0 20px', overflowX: 'auto', display: 'flex', gap: 12, scrollSnapType: 'x mandatory' }}>
        {recmd.map((r, i) => (
          <div key={r.id} style={{ flex: '0 0 224px', scrollSnapAlign: 'start' }}>
            <RecipeMiniCard recipe={r} onClick={() => onOpenRecipe(r)}/>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── dual-entry action card ───
function ActionCard({ eyebrow, title, sub, icon, onClick, primary }) {
  const t = useTheme();
  return (
    <Press onClick={onClick} spring scale={0.97} style={{
      position: 'relative', overflow: 'hidden',
      padding: '16px 16px 18px', borderRadius: t.radii.xl, minHeight: 152,
      background: primary ? t.accent.a : NC.surface,
      color: primary ? t.accent.on : NC.bone,
      border: primary ? 'none' : `1px solid ${NC.border}`,
      boxShadow: primary ? `0 10px 30px ${t.glow(1)}` : 'none',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
    }}>
      {primary && <TrajectoryArc w={120} h={120} stroke={t.accent.on} opacity={0.18} style={{ right: -22, bottom: -28 }}/>}
      {!primary && <TrajectoryArc w={120} h={120} style={{ right: -22, bottom: -28 }}/>}
      <div style={{
        width: 42, height: 42, borderRadius: t.radii.md,
        background: primary ? 'rgba(14,17,16,0.12)' : t.accent.deep,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        border: primary ? 'none' : `1px solid ${t.accent.soft}`,
      }}>
        <NIcon name={icon} size={22} color={primary ? t.accent.on : t.accent.a} strokeWidth={1.7}/>
      </div>
      <div style={{ position: 'relative' }}>
        <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.16em', textTransform: 'uppercase', opacity: primary ? 0.7 : 1, color: primary ? t.accent.on : NC.bone300 }}>{eyebrow}</div>
        <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 5 }}>{title}</div>
        <div style={{ fontSize: 12, marginTop: 2, opacity: primary ? 0.7 : 1, color: primary ? t.accent.on : NC.bone300 }}>{sub}</div>
      </div>
    </Press>
  );
}

// ─── food log row ───
function FoodRow({ item, onClick }) {
  const t = useTheme();
  const tone = ACCENTS[item.tone] || ACCENTS.lime;
  return (
    <Press onClick={onClick} scale={0.97} style={{
      display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', background: NC.surface, borderRadius: t.radii.md,
    }}>
      <div style={{ width: 44, height: 44, borderRadius: t.radii.sm + 2, background: tone.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, border: `1px solid ${tone.soft}` }}>
        <NIcon name={item.icon} size={20} color={tone.a}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone300 }}>{item.serving || item.brand}</div>
        <div style={{ fontSize: 15, fontWeight: 500, color: NC.bone, marginTop: 3, letterSpacing: '-0.008em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontFamily: MONO, fontSize: 18, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em', lineHeight: 1 }}>{item.k}</div>
        <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.18em', color: NC.bone300, textTransform: 'uppercase', marginTop: 4 }}>kcal</div>
      </div>
    </Press>
  );
}

// ─── recipe mini card (carousel) ───
const SEM_FOR_HUE = { lime: 'lime', mint: 'mint', peach: 'orange', iris: 'violet' };
function RecipeMiniCard({ recipe, onClick }) {
  const t = useTheme();
  const hue = ACCENTS[recipe.accentHue] || t.accent;
  if (t.brut) {
    const s = SEM[SEM_FOR_HUE[recipe.accentHue] || 'lime'];
    return (
      <Press onClick={onClick} scale={0.97} hover={1.03} lift={3} className="n-card" style={{ borderRadius: t.radii.xl, background: NC.surface, overflow: 'hidden', border: `1px solid ${NC.border}` }}>
        <div style={{ aspectRatio: '16/10', background: NC.sunken, position: 'relative', overflow: 'hidden' }}>
          <div className="n-thumb-bg" style={{ position: 'absolute', inset: 0, background: recipe.grad }}>
            <BgDots opacity={0.1} size={10}/>
            <Blob color={s.glow + '0.5)'} size={150} variant={1} style={{ right: -36, top: -40 }}/>
          </div>
          <div className="n-thumb-sheen"/>
          <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '64%', background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.78))' }}/>
          <div style={{ position: 'absolute', top: 12, left: 12, display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 10px 5px 8px', borderRadius: 99, background: s.fill }}>
            <NIcon name="clock" size={11} color={s.on}/>
            <span style={{ fontFamily: MONO, fontSize: 10, fontWeight: 600, letterSpacing: '0.04em', color: s.on }}>{recipe.min}m</span>
          </div>
          <div style={{ position: 'absolute', bottom: 13, left: 15, right: 15, fontFamily: DISPLAY, fontSize: 19, fontWeight: 700, color: NC.bone, letterSpacing: '-0.025em', lineHeight: 0.98 }}>{recipe.title}</div>
        </div>
        <div style={{ padding: '13px 16px 15px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <Stat n={recipe.k} u="kcal"/>
          <div style={{ width: 1, height: 26, background: NC.border }}/>
          <Stat n={recipe.p + 'g'} u="protein"/>
          <div style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 4, padding: '4px 9px', borderRadius: 99, background: s.fill }}>
            <NIcon name="star" size={12} color={s.on} fill={s.on}/>
            <span style={{ fontFamily: MONO, fontSize: 12, fontWeight: 600, color: s.on }}>{recipe.rating}</span>
          </div>
        </div>
      </Press>
    );
  }
  return (
    <Press onClick={onClick} scale={0.97} hover={1.03} lift={3} className="n-card" style={{ borderRadius: t.radii.lg, background: NC.surface, overflow: 'hidden' }}>
      <div style={{ aspectRatio: '16/10', background: NC.sunken, position: 'relative', overflow: 'hidden' }}>
        <div className="n-thumb-bg" style={{ position: 'absolute', inset: 0, background: recipe.grad }}>
          <BgDots opacity={0.08} size={10}/>
          <TrajectoryArc w={120} h={120} stroke={hue.a} opacity={0.4} style={{ right: -20, top: -16 }}/>
        </div>
        <div className="n-thumb-sheen"/>
        <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '60%', background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.72))' }}/>
        <div style={{ position: 'absolute', top: 10, left: 10 }}><MonoChip>{recipe.min} min</MonoChip></div>
        <div style={{ position: 'absolute', bottom: 11, left: 12, right: 12, fontSize: 15, fontWeight: 600, color: NC.bone, letterSpacing: '-0.01em', lineHeight: 1.2 }}>{recipe.title}</div>
      </div>
      <div style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <Stat n={recipe.k} u="kcal"/>
        <div style={{ width: 1, height: 26, background: NC.border }}/>
        <Stat n={recipe.p + 'g'} u="protein"/>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 3 }}>
          <NIcon name="star" size={13} color={t.accent.a} fill={t.accent.a}/>
          <span style={{ fontFamily: MONO, fontSize: 12, color: NC.bone200 }}>{recipe.rating}</span>
        </div>
      </div>
    </Press>
  );
}
function Stat({ n, u }) {
  return (
    <div>
      <div style={{ fontFamily: MONO, fontSize: 14, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{n}</div>
      <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>{u}</div>
    </div>
  );
}

Object.assign(window, { HomeScreen, FoodRow, RecipeMiniCard });

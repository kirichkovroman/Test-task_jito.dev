// flow-calorie.jsx — the "calculate calories" flow.
// Method picker (AI photo hero · search · barcode) → result breakdown → confirm-to-log.
// Exported: CalorieFlow (renders inside a Sheet body).

function CalorieFlow({ defaultMeal = 'Lunch', onLog, onClose }) {
  const t = useTheme();
  const [method, setMethod] = React.useState('photo'); // photo | search | barcode
  const [stage, setStage] = React.useState('input'); // input | scanning | result
  const [result, setResult] = React.useState(null); // {dish, total:{...}, items:[]}
  const [meal, setMeal] = React.useState(defaultMeal);
  const [query, setQuery] = React.useState('');

  const results = query.trim() ?
  FOODS.filter((f) => f.name.toLowerCase().includes(query.toLowerCase())) :
  FOODS.slice(0, 6);

  const startPhotoScan = () => {
    setStage('scanning');
    setTimeout(() => {
      setResult({
        dish: SCAN_RESULT.dish, confidence: SCAN_RESULT.confidence,
        total: SCAN_RESULT.total, items: SCAN_RESULT.items, source: 'photo'
      });
      setStage('result');
    }, 2100);
  };

  const startBarcodeScan = () => {
    setStage('scanning');
    setTimeout(() => {
      const b = BARCODE_RESULT;
      setResult({
        dish: b.name, sub: b.brand, code: b.code,
        total: { k: b.k, p: b.p, c: b.c, f: b.f, fi: b.fi },
        items: null, source: 'barcode'
      });
      setStage('result');
    }, 1700);
  };

  const pickFood = (f) => {
    setResult({ dish: f.name, sub: f.brand, total: { k: f.k, p: f.p, c: f.c, f: f.f, fi: f.fi }, items: null, source: 'search', tone: f.tone, icon: f.icon });
    setStage('result');
  };

  const commit = () => {
    const r = result;
    onLog({
      name: r.dish, k: r.total.k, p: r.total.p, c: r.total.c, f: r.total.f, fi: r.total.fi,
      meal, time: 'Just now', serving: r.sub || 'Scanned plate', icon: r.icon || 'salad', tone: r.tone || t.accentKey
    });
  };

  // ── RESULT BREAKDOWN ──
  if (stage === 'result' && result) {
    return <CalorieResult result={result} meal={meal} setMeal={setMeal} onBack={() => setStage('input')} onLog={commit} />;
  }

  // ── SCANNING ──
  if (stage === 'scanning') {
    return <Scanning method={method} onCancel={() => setStage('input')} />;
  }

  // ── INPUT ──
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: 0, flex: 1 }}>
      <div style={{ padding: '22px 20px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase', color: t.brut ? t.accent.a : NC.bone300 }}>ADD FOOD · {meal.toUpperCase()}</div>
          <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontSize: t.brut ? 26 : 21, fontWeight: t.brut ? 700 : 600, color: NC.bone, letterSpacing: '-0.03em', marginTop: t.brut ? 4 : 3 }}>Calculate <span style={{ color: t.brut ? t.accent.a : 'inherit' }}>calories</span></div>
        </div>
        <Press onClick={onClose} style={{ width: 34, height: 34, borderRadius: '50%', background: NC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${NC.border}` }}>
          <NIcon name="close" size={16} color={NC.bone200} />
        </Press>
      </div>

      <div style={{ padding: '0 20px 14px' }}>
        <Segmented
          options={[
          { value: 'photo', label: 'AI photo', icon: 'camera' },
          { value: 'search', label: 'Search', icon: 'search' },
          { value: 'barcode', label: 'Barcode', icon: 'barcode' }]
          }
          value={method} onChange={setMethod} />
      </div>

      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '4px 20px 24px' }}>
        {method === 'photo' && <PhotoPane onScan={startPhotoScan} />}
        {method === 'barcode' && <BarcodePane onScan={startBarcodeScan} />}
        {method === 'search' &&
        <SearchPane query={query} setQuery={setQuery} results={results} onPick={pickFood} />
        }
      </div>
    </div>);

}

// ── AI photo pane ──
function PhotoPane({ onScan }) {
  const t = useTheme();
  return (
    <div style={{ animation: `nutrio-fade-up ${t.dur(260)}ms ${t.ease}` }}>
      <Press onClick={onScan} spring style={{
        position: 'relative', borderRadius: t.radii.xl, overflow: 'hidden', aspectRatio: '4/3',
        background: `radial-gradient(120% 90% at 50% 0%, ${t.accent.deep}, ${NC.sunken})`,
        border: `1px solid ${NC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <BgDots opacity={0.1} size={16} />
        <GlowRing size={220} mult={1.2} />
        {/* viewfinder corners */}
        {[['8px', '8px', '', '', ''], ['8px', '', '', '8px', ''], ['', '8px', '8px', '', ''], ['', '', '8px', '8px', '']].map((c, i) =>
        <div key={i} style={{ position: 'absolute', top: c[0] || undefined, right: c[1] || undefined, bottom: c[2] || undefined, left: c[3] || undefined, margin: 18, width: 26, height: 26,
          borderTop: c[0] ? `2px solid ${t.accent.a}` : 'none', borderRight: c[1] ? `2px solid ${t.accent.a}` : 'none',
          borderBottom: c[2] ? `2px solid ${t.accent.a}` : 'none', borderLeft: c[3] ? `2px solid ${t.accent.a}` : 'none',
          borderTopLeftRadius: c[0] && c[3] ? 10 : 0, borderTopRightRadius: c[0] && c[1] ? 10 : 0, borderBottomLeftRadius: c[2] && c[3] ? 10 : 0, borderBottomRightRadius: c[2] && c[1] ? 10 : 0,
          opacity: 0.8 }} />
        )}
        <div style={{ position: 'relative', textAlign: 'center' }}>
          <div style={{ width: 70, height: 70, borderRadius: t.brut ? 22 : '50%', background: t.accent.a, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto', transform: t.brut ? 'rotate(-6deg)' : 'none', boxShadow: `0 8px 30px ${t.glow(1.2)}` }}>
            <NIcon name="camera" size={30} color={t.accent.on} strokeWidth={1.8} style={{ transform: t.brut ? 'rotate(6deg)' : 'none' }} />
          </div>
          <div style={{ fontFamily: t.brut ? DISPLAY : SANS, marginTop: 14, fontSize: t.brut ? 20 : 15, fontWeight: t.brut ? 700 : 600, letterSpacing: t.brut ? '-0.02em' : '0', color: NC.bone }}>Point at your plate</div>
          <div style={{ marginTop: 3, fontSize: 12.5, color: NC.bone300 }}>We estimate calories and macros</div>
        </div>
      </Press>

      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
        <SmallTile icon="image" label="From library" sem="sky" />
        <SmallTile icon="sparkles" label="Describe it" sem="violet" />
      </div>

      <div style={{ marginTop: 18, padding: '15px 16px', borderRadius: t.radii.lg, background: t.brut ? SEM.violet.fill : SEM.violet.ink, border: t.brut ? 'none' : `1px solid ${SEM.violet.soft}`, display: 'flex', gap: 11, alignItems: 'flex-start', boxShadow: t.brut ? `0 8px 22px ${SEM.violet.glow}0.24)` : 'none' }}>
        <NIcon name="sparkles" size={17} color={t.brut ? SEM.violet.on : SEM.violet.light} style={{ marginTop: 1, flexShrink: 0 }} />
        <div style={{ fontSize: 12.5, color: t.brut ? SEM.violet.on : NC.bone200, lineHeight: 1.5, opacity: t.brut ? 0.95 : 1 }}>
          Nutrio breaks a plate into ingredients and estimates each one. You can adjust any item before logging.
        </div>
      </div>
    </div>);

}
function SmallTile({ icon, label, sem }) {
  const t = useTheme();
  const s = sem ? SEM[sem] : null;
  // Expressive skin: solid color fill (matches bento tiles). Calm: subtle dark tint.
  if (t.brut && s) {
    return (
      <Press style={{ flex: 1, padding: '14px 13px', borderRadius: t.radii.md, background: s.fill, display: 'flex', alignItems: 'center', gap: 9, boxShadow: `0 6px 18px ${s.glow}0.22)` }}>
        <NIcon name={icon} size={18} color={s.on} strokeWidth={1.9} />
        <span style={{ fontSize: 13, color: s.on, fontWeight: 600 }}>{label}</span>
      </Press>);

  }
  return (
    <Press style={{ flex: 1, padding: '14px 12px', borderRadius: t.radii.md, background: s ? s.ink : NC.surface, border: `1px solid ${s ? s.soft : NC.border}`, display: 'flex', alignItems: 'center', gap: 9 }}>
      <NIcon name={icon} size={18} color={s ? s.light : NC.bone200} />
      <span style={{ fontSize: 13, color: NC.bone, fontWeight: 500 }}>{label}</span>
    </Press>);

}

// ── barcode pane ──
function BarcodePane({ onScan }) {
  const t = useTheme();
  return (
    <div style={{ animation: `nutrio-fade-up ${t.dur(260)}ms ${t.ease}` }}>
      <Press onClick={onScan} spring style={{
        position: 'relative', borderRadius: t.radii.xl, overflow: 'hidden', aspectRatio: '4/3',
        background: NC.sunken, border: `1px solid ${NC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <div style={{ width: '64%', height: 2, background: t.accent.a, boxShadow: `0 0 14px ${t.glow(1.4)}`, position: 'absolute' }} />
        <div style={{ display: 'flex', gap: 5, opacity: 0.5 }}>
          {[3, 1, 2, 1, 3, 2, 1, 1, 3, 1, 2, 3, 1, 2].map((w, i) => <div key={i} style={{ width: w * 3, height: 90, background: NC.bone200 }} />)}
        </div>
        <div style={{ position: 'absolute', bottom: 16, fontFamily: MONO, fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300 }}>Align the barcode</div>
      </Press>
      <div style={{ marginTop: 14, textAlign: 'center', fontSize: 13, color: NC.bone300 }}>Tap the frame to simulate a scan</div>
    </div>);

}

// ── search pane ──
function SearchPane({ query, setQuery, results, onPick }) {
  const t = useTheme();
  return (
    <div style={{ animation: `nutrio-fade-up ${t.dur(220)}ms ${t.ease}` }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px', height: 50, borderRadius: t.radii.md, background: NC.sunken, border: `1.5px solid ${query ? t.accent.soft : NC.border}` }}>
        <NIcon name="search" size={18} color={NC.bone300} />
        <input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search foods, brands…"
        style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: NC.bone, fontSize: 15, fontFamily: SANS }} />
        {query && <Press onClick={() => setQuery('')} style={{ padding: 4 }}><NIcon name="close" size={15} color={NC.bone300} /></Press>}
      </div>
      <div style={{ marginTop: 16, fontFamily: MONO, fontSize: 9, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300 }}>
        {query ? `${results.length} results` : 'Recent & popular'}
      </div>
      <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {results.map((f) => {
          const tone = ACCENTS[f.tone] || ACCENTS.lime;
          return (
            <Press key={f.id} onClick={() => onPick(f)} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', background: NC.surface, borderRadius: t.radii.md }}>
              <div style={{ width: 40, height: 40, borderRadius: t.radii.sm, background: tone.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${tone.soft}` }}>
                <NIcon name={f.icon} size={18} color={tone.a} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14.5, fontWeight: 500, color: NC.bone, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</div>
                <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.08em', color: NC.bone300, marginTop: 2 }}>{f.brand}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: MONO, fontSize: 15, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{f.k}</div>
                <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300 }}>kcal</div>
              </div>
              <NIcon name="plus" size={18} color={t.accent.a} />
            </Press>);

        })}
      </div>
    </div>);

}

// ── scanning animation ──
function Scanning({ method, onCancel }) {
  const t = useTheme();
  const photo = method !== 'barcode';
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '8px 20px 28px', minHeight: 360 }}>
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Press onClick={onCancel} style={{ width: 34, height: 34, borderRadius: '50%', background: NC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${NC.border}` }}>
          <NIcon name="close" size={16} color={NC.bone200} />
        </Press>
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ position: 'relative', width: 130, height: 130, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <GlowRing size={180} mult={1.4} />
          <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `2px solid ${t.accent.deep}` }} />
          <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `2px solid transparent`, borderTopColor: t.accent.a, animation: `spin ${t.dur(900)}ms linear infinite` }} />
          <NIcon name={photo ? 'sparkles' : 'barcode'} size={40} color={t.accent.a} style={{ animation: 'nutrio-pulse 1.4s ease-in-out infinite' }} />
        </div>
        <div style={{ marginTop: 24, fontSize: 17, fontWeight: 600, color: NC.bone }}>
          {photo ? 'Reading your plate' : 'Looking up product'}
        </div>
        <div style={{ marginTop: 6, fontFamily: MONO, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone300 }}>
          {photo ? 'Detecting ingredients…' : 'Matching barcode…'}
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>);

}

Object.assign(window, { CalorieFlow });
// flow-calorie-result.jsx — the result breakdown screen (big number moment + items + confirm).

function CalorieResult({ result, meal, setMeal, onBack, onLog }) {
  const t = useTheme();
  const animated = useCountUp(result.total.k, t.dur(900), [result.dish]);
  const [items, setItems] = React.useState(result.items || null);
  const [logged, setLogged] = React.useState(false);

  // recompute total when item portions are toggled off
  const liveTotal = items ?
  items.reduce((s, it) => s + (it.off ? 0 : it.k), 0) :
  result.total.k;
  const liveK = items ? liveTotal : animated;

  const toggleItem = (i) => {
    setItems(items.map((it, idx) => idx === i ? { ...it, off: !it.off } : it));
  };

  const macros = result.total;

  return (
    <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
      {/* top bar */}
      <div style={{ padding: '8px 20px 6px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Press onClick={onBack} style={{ width: 34, height: 34, borderRadius: '50%', background: NC.surface, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${NC.border}` }}>
          <NIcon name="arrow_left" size={17} color={NC.bone200} />
        </Press>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {result.confidence && <MonoChip accent><NIcon name="sparkles" size={11} color={t.accent.a} /> {result.confidence}% match</MonoChip>}
          {result.source === 'barcode' && <MonoChip>scanned</MonoChip>}
        </div>
      </div>

      {/* BIG NUMBER MOMENT — compact, fits the sheet */}
      <div style={{ position: 'relative', padding: '18px 20px 22px', textAlign: 'center', overflow: 'hidden' }}>
        {t.brut ?
        <Blob color={t.accent.glow + '0.16)'} size={150} variant={0} style={{ right: -70, top: -70 }} /> :
        <GlowRing size={240} mult={1} style={{ top: 24 }} />}
        <div style={{ position: 'relative' }}>
          <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: NC.bone300 }}>Estimated energy</div>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 7, marginTop: 10 }}>
            <span style={{ fontFamily: MONO, fontWeight: 500, color: t.brut ? t.accent.a : NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.05em', lineHeight: 1, fontSize: Math.min(t.numFeature, 52) }}>
              {liveK.toLocaleString()}
            </span>
            <span style={{ fontFamily: MONO, fontSize: 13, letterSpacing: '0.14em', textTransform: 'uppercase', color: t.accent.a }}>kcal</span>
          </div>
          <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontSize: t.brut ? 19 : 17, fontWeight: t.brut ? 700 : 600, color: NC.bone, marginTop: 12, letterSpacing: '-0.025em', lineHeight: 1.04 }}>{result.dish}</div>
          {result.sub && <div style={{ fontSize: 12.5, color: NC.bone300, marginTop: 4 }}>{result.sub}</div>}
        </div>
      </div>

      {/* macro split — colored tiles (adds color + separates from the number) */}
      <div style={{ margin: '4px 20px 18px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 8 }}>
        {[
        { k: 'p', label: 'Protein', sem: 'lime' },
        { k: 'c', label: 'Carbs', sem: 'amber' },
        { k: 'f', label: 'Fat', sem: 'coral' },
        { k: 'fi', label: 'Fiber', sem: 'mint' }].
        map((m) => {
          const s = SEM[m.sem];
          return (
            <div key={m.k} style={{ position: 'relative', overflow: 'hidden', padding: '12px 8px 12px 10px', borderRadius: t.radii.md, background: s.fill }}>
              <div style={{ fontFamily: MONO, fontSize: 8, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: s.on, opacity: 0.78, whiteSpace: 'nowrap' }}>{m.label}</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 1, marginTop: 6 }}>
                <span style={{ fontFamily: MONO, fontSize: 18, fontWeight: 500, color: s.on, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.03em', lineHeight: 1 }}>{macros[m.k] || 0}</span>
                <span style={{ fontFamily: MONO, fontSize: 9, color: s.on, opacity: 0.7 }}>g</span>
              </div>
            </div>);

        })}
      </div>

      {/* macro balance bar */}
      <div style={{ margin: '0 20px 18px', padding: '14px 16px', background: NC.surface, borderRadius: t.radii.lg }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 11 }}>
          <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300 }}>Macro balance</span>
          <div style={{ display: 'flex', gap: 10 }}>
            {[['Protein', SEM.lime.fill], ['Carbs', SEM.amber.fill], ['Fat', SEM.coral.fill], ['Fiber', SEM.mint.fill]].map(([n, c]) =>
            <span key={n} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: MONO, fontSize: 8, letterSpacing: '0.04em', textTransform: 'uppercase', color: NC.bone400 }}>
                <span style={{ width: 6, height: 6, borderRadius: 2, background: c }} />{n}
              </span>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', height: 10, borderRadius: 99, overflow: 'hidden', gap: 3 }}>
          {[['p', SEM.lime.fill], ['c', SEM.amber.fill], ['f', SEM.coral.fill], ['fi', SEM.mint.fill]].map(([k, c]) => {
            const tot = macros.p + macros.c + macros.f + macros.fi || 1;
            return <div key={k} style={{ width: `${macros[k] / tot * 100}%`, background: c, borderRadius: 99 }} />;
          })}
        </div>
      </div>

      {/* detected items (photo only) */}
      {items &&
      <div style={{ margin: '0 20px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300 }}>Detected · {items.filter((i) => !i.off).length} items</span>
            <span style={{ fontFamily: MONO, fontSize: 10, color: NC.bone400 }}>tap to include</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {items.map((it, i) => {
            const itemSem = [SEM.lime, SEM.amber, SEM.coral, SEM.mint, SEM.sky, SEM.violet][i % 6];
            return (
            <Press key={i} onClick={() => toggleItem(i)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: t.radii.md,
              background: NC.surface, opacity: it.off ? 0.45 : 1, transition: `opacity ${t.dur(160)}ms ${t.ease}`,
              borderLeft: `3px solid ${it.off ? NC.border : itemSem.fill}`
            }}>
                <div style={{ width: 24, height: 24, borderRadius: 7, border: `1.5px solid ${it.off ? NC.border : itemSem.fill}`, background: it.off ? 'transparent' : itemSem.fill, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  {!it.off && <NIcon name="check" size={14} color={itemSem.on} strokeWidth={2.4} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 500, color: NC.bone }}>{it.name}</div>
                  <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.06em', color: NC.bone300, marginTop: 2 }}>{it.g} · {it.conf}% sure</div>
                </div>
                <div style={{ fontFamily: MONO, fontSize: 15, fontWeight: 500, color: it.off ? NC.bone300 : itemSem.fill, fontVariantNumeric: 'tabular-nums' }}>{it.k}</div>
              </Press>);

          })}
          </div>
        </div>
      }

      {/* meal assignment */}
      <div style={{ margin: '0 20px 12px' }}>
        <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300, marginBottom: 10 }}>Add to</div>
        <div className="no-scrollbar" style={{ display: 'flex', gap: 8, overflowX: 'auto' }}>
          {['Breakfast', 'Lunch', 'Dinner', 'Snacks'].map((m) =>
          <Chip key={m} active={meal === m} onClick={() => setMeal(m)}>{m}</Chip>
          )}
        </div>
      </div>

      {/* sticky confirm */}
      <div style={{ marginTop: 'auto', padding: '14px 20px calc(20px + var(--safe-bottom))', background: `linear-gradient(180deg, transparent, ${NC.raised} 24%)`, position: 'sticky', bottom: 0 }}>
        <PrimaryButton full big icon={<NIcon name={logged ? 'check' : 'plus'} size={20} color={t.accent.on} strokeWidth={2} />}
        onClick={() => {if (!logged) {setLogged(true);setTimeout(onLog, 380);}}}>
          {logged ? 'Logged' : `Log ${liveK.toLocaleString()} kcal to ${meal.toLowerCase()}`}
        </PrimaryButton>
      </div>
    </div>);

}

window.CalorieResult = CalorieResult;
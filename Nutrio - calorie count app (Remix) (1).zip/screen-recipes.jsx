// screen-recipes.jsx — recipe discovery (filterable feed/grid) + detail screen.

function RecipesScreen({ favs, onToggleFav, onOpen }) {
  const t = useTheme();
  const [active, setActive] = React.useState({ diet: null, goal: null, time: null, macro: null });
  const [view, setView] = React.useState('feed'); // feed | grid
  const [sheetOpen, setSheetOpen] = React.useState(false);

  const setFilter = (group, val) => setActive(a => ({ ...a, [group]: a[group] === val ? null : val }));
  const activeCount = Object.values(active).filter(Boolean).length;
  const clearAll = () => setActive({ diet: null, goal: null, time: null, macro: null });

  const filtered = RECIPES.filter(r => {
    if (active.diet && !r.diet.includes(active.diet)) return false;
    if (active.goal && !r.goal.includes(active.goal)) return false;
    if (active.time && r.time !== active.time) return false;
    if (active.macro && !r.macro.includes(active.macro)) return false;
    return true;
  });

  // top quick chips: a curated mix across groups
  const quick = [
    { g: 'goal', v: 'Build muscle' }, { g: 'diet', v: 'High-protein' },
    { g: 'time', v: 'Under 15 min' }, { g: 'diet', v: 'Vegan' },
    { g: 'macro', v: 'High fiber' }, { g: 'diet', v: 'Keto' },
  ];

  const featured = RECIPES.find(r => r.id === 'r2');

  return (
    <div style={{ paddingBottom: 132, animation: `nutrio-fade ${t.dur(300)}ms ${t.ease}` }}>
      {/* header */}
      <div style={{ padding: '64px 20px 12px' }}>
        <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300 }}>FOR YOUR GOALS</div>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 4 }}>
          <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontWeight: t.brut ? 700 : 600, fontSize: t.brut ? 32 : 28, color: NC.bone, letterSpacing: '-0.03em', lineHeight: 1 }}>Discover</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <IconBtn icon={view === 'feed' ? 'grid' : 'list'} onClick={() => setView(view === 'feed' ? 'grid' : 'feed')}/>
            <IconBtn icon="sliders" onClick={() => setSheetOpen(true)} active={activeCount > 0} badge={activeCount > 0}/>
          </div>
        </div>
      </div>

      {/* quick filter chips */}
      <div className="no-scrollbar" style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '4px 20px 18px' }}>
        <Chip active={activeCount === 0} onClick={clearAll}>All</Chip>
        {quick.map((q, i) => (
          <Chip key={i} active={active[q.g] === q.v} onClick={() => setFilter(q.g, q.v)}>{q.v}</Chip>
        ))}
      </div>

      {/* active filter summary */}
      {activeCount > 0 && (
        <div style={{ padding: '0 20px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: MONO, fontSize: 11, color: NC.bone300, letterSpacing: '0.04em' }}>{filtered.length} recipe{filtered.length===1?'':'s'} match</span>
          <Press onClick={clearAll} style={{ fontFamily: MONO, fontSize: 11, color: t.accent.a }}>Clear filters</Press>
        </div>
      )}

      {/* featured hero (only when no filters) */}
      {activeCount === 0 && view === 'feed' && (
        <div style={{ padding: '0 20px 18px' }}>
          <SectionTitle action="↗ Top rated">Featured today</SectionTitle>
          <FeaturedCard recipe={featured} fav={favs.includes(featured.id)} onToggleFav={() => onToggleFav(featured.id)} onClick={() => onOpen(featured)}/>
        </div>
      )}

      {/* results */}
      {filtered.length === 0 ? (
        <EmptyState onClear={clearAll}/>
      ) : view === 'grid' ? (
        <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {filtered.map(r => <GridCard key={r.id} recipe={r} fav={favs.includes(r.id)} onToggleFav={() => onToggleFav(r.id)} onClick={() => onOpen(r)}/>)}
        </div>
      ) : (
        <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {(activeCount === 0 ? filtered.filter(r => r.id !== featured.id) : filtered).map(r =>
            <FeedCard key={r.id} recipe={r} fav={favs.includes(r.id)} onToggleFav={() => onToggleFav(r.id)} onClick={() => onOpen(r)}/>
          )}
        </div>
      )}

      {/* filter sheet */}
      <FilterSheet open={sheetOpen} onClose={() => setSheetOpen(false)} active={active} setFilter={setFilter} clearAll={clearAll} count={filtered.length}/>
    </div>
  );
}

// ── expressive recipe pill ──
function RPill({ recipe, children, icon, solid }) {
  const s = recipeSem(recipe);
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: icon ? '5px 10px 5px 8px' : '5px 10px', borderRadius: 99,
      background: solid ? s.fill : 'rgba(10,12,11,0.5)', backdropFilter: solid ? 'none' : 'blur(6px)',
      fontFamily: MONO, fontSize: 10, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase',
      color: solid ? s.on : NC.bone, border: solid ? 'none' : '1px solid rgba(255,255,255,0.12)' }}>
      {icon && <NIcon name={icon} size={11} color={solid ? s.on : NC.bone}/>}{children}
    </span>
  );
}

// ── featured hero card ──
function FeaturedCard({ recipe, fav, onToggleFav, onClick }) {
  const t = useTheme();
  const hue = ACCENTS[recipe.accentHue] || t.accent;
  const s = recipeSem(recipe);
  const par = useParallax(t.parallaxMax);
  return (
    <Press onClick={onClick} scale={0.98} hover={1.012} lift={2} className="n-card" style={{ borderRadius: t.radii.xl, overflow: 'hidden', position: 'relative' }}>
      <div ref={par.ref} onPointerMove={par.onMove} onPointerLeave={par.reset} style={{ ...par.style, position: 'relative', aspectRatio: '5/4', background: recipe.grad }}>
        <BgDots opacity={0.08} size={14}/>
        {t.brut
          ? <Blob color={s.glow + '0.5)'} size={230} variant={0} style={{ right: -54, top: -50 }}/>
          : <TrajectoryArc w={200} h={200} stroke={hue.a} opacity={0.45} style={{ right: -30, top: -24 }} draw/>}
        <div className="n-thumb-sheen"/>
        <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '62%', background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.78))' }}/>
        <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', gap: 6 }}>
          {t.brut ? <><RPill recipe={recipe} solid>{recipe.diet[0]}</RPill><RPill recipe={recipe} icon="clock">{recipe.min}m</RPill></>
            : <><MonoChip color={hue.a}>{recipe.diet[0]}</MonoChip><MonoChip>{recipe.min} min</MonoChip></>}
        </div>
        <FavBtn fav={fav} onClick={(e) => { e.stopPropagation(); onToggleFav(); }} style={{ position: 'absolute', top: 12, right: 12 }}/>
        <div style={{ position: 'absolute', bottom: 16, left: 16, right: 16 }}>
          <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontSize: t.brut ? 26 : 23, fontWeight: t.brut ? 700 : 600, color: NC.bone, letterSpacing: '-0.025em', lineHeight: t.brut ? 0.98 : 1.12 }}>{recipe.title}</div>
          <div style={{ fontSize: 13, color: NC.bone200, marginTop: 6, lineHeight: 1.45 }}>{recipe.blurb}</div>
          <div style={{ display: 'flex', gap: 16, marginTop: 12 }}>
            <BigStat n={recipe.k} u="kcal"/>
            <BigStat n={recipe.p + 'g'} u="protein"/>
            <BigStat n={recipe.fi + 'g'} u="fiber"/>
            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4 }}>
              {t.brut
                ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '4px 9px', borderRadius: 99, background: s.fill }}><NIcon name="star" size={12} color={s.on} fill={s.on}/><span style={{ fontFamily: MONO, fontSize: 12, fontWeight: 600, color: s.on }}>{recipe.rating}</span></span>
                : <><NIcon name="star" size={15} color={t.accent.a} fill={t.accent.a}/><span style={{ fontFamily: MONO, fontSize: 13, color: NC.bone }}>{recipe.rating}</span></>}
            </div>
          </div>
        </div>
      </div>
    </Press>
  );
}

// ── feed card (horizontal) ──
function FeedCard({ recipe, fav, onToggleFav, onClick }) {
  const t = useTheme();
  const hue = ACCENTS[recipe.accentHue] || t.accent;
  const s = recipeSem(recipe);

  // ── Expressive: bold editorial card — big image, accent rail, colored macro chips ──
  if (t.brut) {
    const macroChips = [
      { v: recipe.k, u: 'kcal', c: s.fill, on: s.on, icon: 'flame' },
      { v: recipe.p + 'g', u: 'protein', c: SEM.lime.fill, on: SEM.lime.on },
      { v: recipe.fi + 'g', u: 'fiber', c: SEM.mint.fill, on: SEM.mint.on },
    ];
    return (
      <Press onClick={onClick} scale={0.985} hover={1.02} className="n-card" style={{ position: 'relative', display: 'flex', gap: 0, borderRadius: t.radii.lg, background: NC.surface, overflow: 'hidden', border: `1px solid ${NC.border}` }}>
        {/* image */}
        <div style={{ position: 'relative', width: 118, alignSelf: 'stretch', minHeight: 132, flexShrink: 0, background: NC.sunken, overflow: 'hidden' }}>
          <div className="n-thumb-bg" style={{ position: 'absolute', inset: 0, background: recipe.grad }}>
            <BgDots opacity={0.1} size={9}/>
            <Blob color={s.glow + '0.6)'} size={120} variant={1} style={{ right: -30, top: -24 }}/>
          </div>
          <div className="n-thumb-sheen"/>
          <div style={{ position: 'absolute', bottom: 8, left: 8 }}><RPill recipe={recipe} icon="clock">{recipe.min}m</RPill></div>
        </div>
        {/* content */}
        <div style={{ flex: 1, minWidth: 0, padding: '13px 14px 13px 13px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, paddingRight: 34 }}>
            <span style={{ fontFamily: MONO, fontSize: 9, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: s.fill }}>{recipe.diet[0]}</span>
          </div>
          <div style={{ fontFamily: DISPLAY, fontSize: 18, fontWeight: 700, color: NC.bone, letterSpacing: '-0.025em', lineHeight: 0.98, marginTop: 6, paddingRight: 34 }}>{recipe.title}</div>
          {/* colored macro chips */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 'auto', paddingTop: 12 }}>
            {macroChips.map((m, i) => (
              <span key={i} style={{ display: 'inline-flex', alignItems: 'baseline', gap: 3, padding: '4px 9px', borderRadius: 99, background: m.c }}>
                <span style={{ fontFamily: MONO, fontSize: 11.5, fontWeight: 600, color: m.on, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em' }}>{m.v}</span>
                <span style={{ fontFamily: MONO, fontSize: 8, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: m.on, opacity: 0.7 }}>{m.u}</span>
              </span>
            ))}
          </div>
        </div>
        <FavBtn fav={fav} onClick={(e) => { e.stopPropagation(); onToggleFav(); }} style={{ position: 'absolute', top: 10, right: 10 }} small/>
      </Press>
    );
  }

  // ── Calm: clean horizontal mini ──
  return (
    <Press onClick={onClick} scale={0.98} hover={1.02} className="n-card" style={{ display: 'flex', gap: 14, padding: 12, borderRadius: t.radii.lg, background: NC.surface, alignItems: 'center' }}>
      <div style={{ position: 'relative', width: 96, height: 96, borderRadius: t.radii.md, overflow: 'hidden', flexShrink: 0, background: NC.sunken }}>
        <div className="n-thumb-bg" style={{ position: 'absolute', inset: 0, background: recipe.grad }}>
          <BgDots opacity={0.1} size={9}/>
          <TrajectoryArc w={80} h={80} stroke={hue.a} opacity={0.5} style={{ right: -14, top: -10 }}/>
        </div>
        <div className="n-thumb-sheen"/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
          <MonoChip color={hue.a}>{recipe.diet[0]}</MonoChip>
        </div>
        <div style={{ fontSize: 15.5, fontWeight: 600, color: NC.bone, letterSpacing: '-0.018em', lineHeight: 1.1 }}>{recipe.title}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
          <MiniStat n={recipe.k} u="kcal"/>
          <MiniStat n={recipe.p+'g'} u="prot"/>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontFamily: MONO, fontSize: 11, color: NC.bone300 }}>
            <NIcon name="clock" size={12} color={NC.bone300}/>{recipe.min}m
          </div>
        </div>
      </div>
      <FavBtn fav={fav} onClick={(e) => { e.stopPropagation(); onToggleFav(); }}/>
    </Press>
  );
}

// ── grid card ──
function GridCard({ recipe, fav, onToggleFav, onClick }) {
  const t = useTheme();
  const hue = ACCENTS[recipe.accentHue] || t.accent;
  const s = recipeSem(recipe);
  return (
    <Press onClick={onClick} scale={0.97} hover={1.03} lift={3} className="n-card" style={{ borderRadius: t.radii.lg, overflow: 'hidden', background: NC.surface, border: t.brut ? `1px solid ${NC.border}` : 'none' }}>
      <div style={{ position: 'relative', aspectRatio: '1/1', background: NC.sunken, overflow: 'hidden' }}>
        <div className="n-thumb-bg" style={{ position: 'absolute', inset: 0, background: recipe.grad }}>
          <BgDots opacity={0.09} size={10}/>
          {t.brut
            ? <Blob color={s.glow + '0.55)'} size={130} variant={0} style={{ right: -28, top: -22 }}/>
            : <TrajectoryArc w={120} h={120} stroke={hue.a} opacity={0.45} style={{ right: -18, top: -14 }}/>}
        </div>
        <div className="n-thumb-sheen"/>
        <FavBtn fav={fav} onClick={(e) => { e.stopPropagation(); onToggleFav(); }} style={{ position: 'absolute', top: 8, right: 8 }} small/>
        <div style={{ position: 'absolute', top: 8, left: 8 }}>{t.brut ? <RPill recipe={recipe} icon="clock">{recipe.min}m</RPill> : <MonoChip>{recipe.min}m</MonoChip>}</div>
      </div>
      <div style={{ padding: '10px 12px 12px' }}>
        <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontSize: t.brut ? 15 : 13.5, fontWeight: t.brut ? 700 : 600, color: NC.bone, lineHeight: 1.04, letterSpacing: '-0.02em', minHeight: 33 }}>{recipe.title}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <MiniStat n={recipe.k} u="kcal"/>
          <MiniStat n={recipe.p+'g'} u="prot"/>
        </div>
      </div>
    </Press>
  );
}

function FavBtn({ fav, onClick, style = {}, small }) {
  const t = useTheme();
  const s = small ? 30 : 38;
  return (
    <Press onClick={onClick} spring style={{
      width: s, height: s, borderRadius: '50%', background: 'rgba(10,12,11,0.5)', backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,0.1)', ...style,
    }}>
      <NIcon name={fav ? 'heart' : 'heart'} size={small ? 15 : 18} color={fav ? t.accent.a : NC.bone200} fill={fav ? t.accent.a : 'none'}/>
    </Press>
  );
}
function BigStat({ n, u }) {
  return (
    <div>
      <div style={{ fontFamily: MONO, fontSize: 16, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em' }}>{n}</div>
      <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: NC.bone300, marginTop: 2 }}>{u}</div>
    </div>
  );
}
function MiniStat({ n, u }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
      <span style={{ fontFamily: MONO, fontSize: 13, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{n}</span>
      <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone300 }}>{u}</span>
    </div>
  );
}

function EmptyState({ onClear }) {
  const t = useTheme();
  return (
    <div style={{ padding: '40px 40px', textAlign: 'center' }}>
      <div style={{ position: 'relative', width: 90, height: 90, margin: '0 auto 18px' }}>
        <TrajectoryArc w={90} h={90} opacity={0.6} style={{ inset: 0 }} draw/>
        <NIcon name="salad" size={34} color={NC.bone400} style={{ position: 'absolute', left: 28, top: 30 }}/>
      </div>
      <div style={{ fontSize: 16, fontWeight: 600, color: NC.bone }}>No recipes match</div>
      <div style={{ fontSize: 13, color: NC.bone300, marginTop: 6, lineHeight: 1.5 }}>Try loosening a filter — your combination is a little too specific.</div>
      <div style={{ marginTop: 18, display: 'flex', justifyContent: 'center' }}>
        <GhostButton onClick={onClear} icon={<NIcon name="refresh" size={16} color={NC.bone}/>}>Clear filters</GhostButton>
      </div>
    </div>
  );
}

// ── full filter sheet ──
function FilterSheet({ open, onClose, active, setFilter, clearAll, count }) {
  const t = useTheme();
  const groups = [
    { key: 'diet', label: 'Diet', opts: RECIPE_FILTERS.diet },
    { key: 'goal', label: 'Goal', opts: RECIPE_FILTERS.goal },
    { key: 'time', label: 'Time', opts: RECIPE_FILTERS.time },
    { key: 'macro', label: 'Macros', opts: RECIPE_FILTERS.macro },
  ];
  return (
    <Sheet open={open} onClose={onClose} maxH="80%">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 20px 14px' }}>
        <div style={{ fontSize: 19, fontWeight: 600, color: NC.bone, letterSpacing: '-0.02em' }}>Filter recipes</div>
        <Press onClick={clearAll} style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', color: t.accent.a }}>Reset</Press>
      </div>
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '0 20px 8px' }}>
        {groups.map(g => (
          <div key={g.key} style={{ marginBottom: 20 }}>
            <div style={{ fontFamily: MONO, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: NC.bone300, marginBottom: 11 }}>{g.label}</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {g.opts.map(o => <Chip key={o} active={active[g.key] === o} onClick={() => setFilter(g.key, o)}>{o}</Chip>)}
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding: '12px 20px calc(18px + var(--safe-bottom))', borderTop: `1px solid ${NC.border}` }}>
        <PrimaryButton full big onClick={onClose}>Show {count} recipe{count===1?'':'s'}</PrimaryButton>
      </div>
    </Sheet>
  );
}

Object.assign(window, { RecipesScreen });

// screen-home-bento.jsx — Expressive-skin dashboard. Asymmetric bento of vibrant
// offset tiles, decorative data viz, bold mixed-font hierarchy. Both flows reachable.

function BentoHome({ log, animateKey, onMealTap, onAddTo, onScan, onRecipes, onOpenRecipe }) {
  const t = useTheme();
  const goal = 2000;
  const totalKcal = log.reduce((a, m) => a + m.k, 0);
  const left = Math.max(0, goal - totalKcal);
  const pct = Math.min(100, Math.round((totalKcal / goal) * 100));
  const macros = { p: 0, c: 0, f: 0, fi: 0 };
  log.forEach(m => { macros.p += m.p||0; macros.c += m.c||0; macros.f += m.f||0; macros.fi += m.fi||0; });

  const kAnim = useCountUp(totalKcal, t.dur(900), [animateKey]);

  const meals = [
    { name: 'Breakfast', goal: 500, dot: SEM.amber.fill },
    { name: 'Lunch',     goal: 700, dot: SEM.lime.fill },
    { name: 'Dinner',    goal: 600, dot: SEM.violet.fill },
    { name: 'Snacks',    goal: 200, dot: SEM.coral.fill },
  ].map(g => ({ ...g, items: log.filter(m => m.meal === g.name) }));

  const recmd = RECIPES.filter(r => r.kcalLevel === 'dinner').slice(0, 4);
  const week = [1280, 1640, 1490, 2010, 1720, 1880, totalKcal];

  return (
    <div style={{ paddingBottom: 138, animation: `nutrio-fade ${t.dur(300)}ms ${t.ease}` }}>
      {/* ── HEADER — bold mixed type ── */}
      <div style={{ padding: '58px 20px 16px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 600, letterSpacing: '0.2em', textTransform: 'uppercase', color: NC.bone300 }}>THU · 28 MAY</div>
          <div style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 36, lineHeight: 0.94, letterSpacing: '-0.03em', color: NC.bone, marginTop: 8 }}>
            Hey, <span style={{ color: SEM.lime.fill }}>Alex</span>
          </div>
          <div style={{ fontFamily: SERIF, fontStyle: 'italic', fontWeight: 400, fontSize: 23, lineHeight: 1, color: SEM.violet.light, marginTop: 3 }}>— let’s eat well today.</div>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 22 }}>
          <IconBtn icon="bell" badge/>
          <Avatar/>
        </div>
      </div>

      {/* ── BENTO GRID ── */}
      <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>

        {/* HERO calories — violet, span 2 */}
        <BentoTile sem="violet" span={2} onClick={onScan} rot={t.tilt(-0.6)} pad={20}>
          <Blob color="rgba(255,255,255,0.10)" size={200} variant={0} style={{ right: -50, top: -70 }}/>
          <BgDots color="255,255,255" opacity={0.12} size={15}/>
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 18 }}>
            <div style={{ flex: 1 }}>
              <TileLabel sem="violet">TODAY · KCAL EATEN</TileLabel>
              <div style={{ fontFamily: MONO, fontWeight: 500, fontSize: 56, lineHeight: 0.9, letterSpacing: '-0.05em', color: '#fff', marginTop: 10, fontVariantNumeric: 'tabular-nums' }}>
                {kAnim.toLocaleString()}
              </div>
              <div style={{ display: 'flex', gap: 7, marginTop: 14, flexWrap: 'wrap' }}>
                <TilePill sem="violet"><b style={{ color: SEM.lime.fill }}>{left.toLocaleString()}</b>&nbsp;left</TilePill>
                <TilePill sem="violet">↗ {pct}% of goal</TilePill>
              </div>
            </div>
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <SegmentDonut size={104} stroke={15} segments={[
                { v: macros.c, color: SEM.amber.fill },
                { v: macros.p, color: SEM.lime.fill },
                { v: macros.f, color: SEM.orange.fill },
                { v: macros.fi, color: SEM.mint.fill },
              ]}/>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ fontFamily: MONO, fontSize: 20, fontWeight: 500, color: '#fff', letterSpacing: '-0.03em' }}>{pct}%</span>
                <span style={{ fontFamily: MONO, fontSize: 8, letterSpacing: '0.14em', color: 'rgba(255,255,255,0.9)' }}>FUEL</span>
              </div>
            </div>
          </div>
        </BentoTile>

        {/* STREAK — lime scallop */}
        <BentoTile sem="lime" rot={t.tilt(-1.2)} center pad={14}>
          <div style={{ position: 'relative' }}>
            <ScallopBadge size={108} fill={SEM.lime.on} teeth={16}>
              <div>
                <div style={{ fontFamily: MONO, fontWeight: 500, fontSize: 34, color: SEM.lime.fill, lineHeight: 1, letterSpacing: '-0.04em' }}>5</div>
                <div style={{ fontFamily: MONO, fontSize: 8, letterSpacing: '0.18em', color: 'rgba(200,255,94,0.7)', marginTop: 2 }}>DAYS</div>
              </div>
            </ScallopBadge>
          </div>
          <TileLabel sem="lime" style={{ marginTop: 12 }}>STREAK · ON A ROLL</TileLabel>
        </BentoTile>

        {/* PROTEIN — coral */}
        <BentoTile sem="coral" rot={t.tilt(0.9)} arrow pad={16}>
          <TileLabel sem="coral">PROTEIN</TileLabel>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 3, marginTop: 8 }}>
            <span style={{ fontFamily: MONO, fontWeight: 500, fontSize: 38, color: SEM.coral.on, letterSpacing: '-0.04em', lineHeight: 1 }}>{Math.round(macros.p)}</span>
            <span style={{ fontFamily: MONO, fontSize: 14, color: SEM.coral.on }}>g</span>
          </div>
          <div style={{ marginTop: 14 }}>
            <BarField data={[40,55,48,70,62,80,Math.min(100, macros.p)]} color={SEM.coral.on} height={34} highlightLast/>
          </div>
          <div style={{ fontFamily: MONO, fontSize: 9, fontWeight: 600, letterSpacing: '0.12em', color: SEM.coral.on, marginTop: 12 }}>88g GOAL · {Math.round(macros.p/110*100)}%</div>
        </BentoTile>

        {/* THIS WEEK — deep orange span 2, white text */}
        <BentoTile sem="orange" span={2} rot={t.tilt(0.5)} pad={22} bg="#B8440A" fg="#fff">
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontFamily: MONO, fontSize: 9.5, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#fff', opacity: 0.92 }}>THIS WEEK · KCAL TREND</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8 }}>
                <span style={{ fontFamily: MONO, fontWeight: 500, fontSize: 30, color: '#fff', letterSpacing: '-0.04em', lineHeight: 1 }}>1,673</span>
                <span style={{ fontFamily: MONO, fontSize: 11, color: 'rgba(255,255,255,0.92)' }}>avg/day</span>
              </div>
            </div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 99, background: 'rgba(255,255,255,0.2)', fontFamily: MONO, fontSize: 11, color: '#fff' }}>↗ steady</div>
          </div>
          <div style={{ marginTop: 16 }}>
            <BarField data={week.map(v => Math.round(v/20))} color="#fff" height={56} highlightLast rounded/>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, fontFamily: MONO, fontSize: 8.5, fontWeight: 600, letterSpacing: '0.1em', color: 'rgba(255,255,255,0.92)' }}>
            {['M','T','W','T','F','S','S'].map((d,i)=><span key={i}>{d}</span>)}
          </div>
        </BentoTile>

        {/* WATER — sky */}
        <BentoTile sem="sky" rot={t.tilt(-0.7)} pad={16}>
          <TileLabel sem="sky">WATER</TileLabel>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
              <span style={{ fontFamily: MONO, fontWeight: 500, fontSize: 34, color: SEM.sky.on, letterSpacing: '-0.04em', lineHeight: 1 }}>1.4</span>
              <span style={{ fontFamily: MONO, fontSize: 13, color: SEM.sky.mut }}>L</span>
            </div>
            <Donut pct={0.58} size={46} stroke={7} color={SEM.sky.on} track="rgba(2,20,38,0.18)"/>
          </div>
          <div style={{ fontFamily: MONO, fontSize: 9, fontWeight: 600, letterSpacing: '0.12em', color: SEM.sky.on, marginTop: 14 }}>2.4L GOAL · 58%</div>
        </BentoTile>

        {/* FIBER — mint */}
        <BentoTile sem="mint" rot={t.tilt(1.1)} pad={16}>
          <TileLabel sem="mint">FIBER</TileLabel>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 3, marginTop: 8 }}>
            <span style={{ fontFamily: MONO, fontWeight: 500, fontSize: 34, color: SEM.mint.on, letterSpacing: '-0.04em', lineHeight: 1 }}>{Math.round(macros.fi)}</span>
            <span style={{ fontFamily: MONO, fontSize: 13, color: SEM.mint.mut }}>g</span>
          </div>
          <div style={{ marginTop: 12 }}><Sparkline data={[6,9,7,12,10,14,Math.max(6,macros.fi)]} color={SEM.mint.on} w={130} h={32}/></div>
          <div style={{ fontFamily: MONO, fontSize: 9, fontWeight: 600, letterSpacing: '0.12em', color: SEM.mint.on, marginTop: 10 }}>28g GOAL · holding</div>
        </BentoTile>
      </div>

      {/* ── TWO FLOWS — bold action cards ── */}
      <div style={{ padding: '22px 20px 4px' }}>
        <ExpressiveHeading>What now<span style={{ color: SEM.lime.fill }}>?</span></ExpressiveHeading>
      </div>
      <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FlowCard sem="lime" onClick={onScan} icon="camera" rot={t.tilt(-1.5)}
          kicker="LOG IN SECONDS" title={'Snap\na meal'} sub="AI reads the plate"/>
        <FlowCard sem="violet" onClick={onRecipes} icon="recipe" rot={t.tilt(1.5)}
          kicker="FOR YOUR GOALS" title={'Find\nrecipes'} sub="Matched to you" light/>
      </div>

      {/* ── MEALS ── */}
      <div style={{ padding: '26px 20px 0' }}>
        <ExpressiveHeading>Today’s <span style={{ fontFamily: SERIF, fontStyle: 'italic', fontWeight: 400 }}>plate</span></ExpressiveHeading>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 14 }}>
        {meals.map(group => {
          const kc = group.items.reduce((s, i) => s + i.k, 0);
          return (
            <div key={group.name}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px 8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                  <div style={{ width: 9, height: 9, borderRadius: 3, background: group.dot, transform: 'rotate(45deg)' }}/>
                  <span style={{ fontFamily: MONO, fontSize: 11, fontWeight: 600, color: NC.bone, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{group.name}</span>
                  {group.items[0]?.time && <span style={{ fontFamily: MONO, fontSize: 10, color: NC.bone400 }}>· {group.items[0].time}</span>}
                </div>
                <span style={{ fontFamily: MONO, fontSize: 11, color: NC.bone200, fontVariantNumeric: 'tabular-nums' }}>{kc} / {group.goal}</span>
              </div>
              <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
                {group.items.length === 0 ? (
                  <Press onClick={() => onAddTo(group.name)} style={{ padding: '14px 16px', borderRadius: t.radii.md, border: `1.5px dashed ${NC.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 13, color: NC.bone300 }}>Add to {group.name.toLowerCase()}</span>
                    <div style={{ width: 26, height: 26, borderRadius: '50%', background: group.dot, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><NIcon name="plus" size={15} color="#0E1110" strokeWidth={2.4}/></div>
                  </Press>
                ) : group.items.map((item, i) => <FoodRow key={i} item={item} onClick={() => onMealTap(item)}/>)}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── RECOMMENDED ── */}
      <div style={{ padding: '28px 20px 0' }}>
        <ExpressiveHeading>For <span style={{ color: SEM.orange.fill }}>dinner</span></ExpressiveHeading>
      </div>
      <div className="no-scrollbar" style={{ padding: '14px 20px 0', overflowX: 'auto', display: 'flex', gap: 12, scrollSnapType: 'x mandatory' }}>
        {recmd.map((r) => (
          <div key={r.id} style={{ flex: '0 0 196px', scrollSnapAlign: 'start' }}>
            <RecipeMiniCard recipe={r} onClick={() => onOpenRecipe(r)}/>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Bento tile shell — colored, rounded, slightly offset ──
function BentoTile({ sem, span = 1, children, onClick, arrow, rot = 0, center, pad = 16, bg, fg }) {
  const t = useTheme();
  const s = SEM[sem] || SEM.lime;
  const [press, setPress] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const sc = press ? 0.975 : (hover && onClick ? 1.025 : 1);
  const ty = (hover && !press && onClick) ? -3 : 0;
  return (
    <div
      onPointerDown={onClick ? () => setPress(true) : undefined}
      onPointerUp={onClick ? () => setPress(false) : undefined}
      onMouseEnter={onClick ? () => setHover(true) : undefined}
      onMouseLeave={onClick ? () => { setHover(false); setPress(false); } : undefined}
      onClick={onClick}
      style={{
        gridColumn: span === 2 ? 'span 2' : 'span 1',
        position: 'relative', overflow: 'hidden',
        background: bg || s.fill, borderRadius: t.radii.xl, padding: pad, minHeight: 96,
        transform: `translateY(${ty}px) rotate(${rot}deg) scale(${sc})`,
        transition: `transform ${t.dur(press ? 140 : 240)}ms ${press ? t.ease : t.spring}, box-shadow ${t.dur(240)}ms ${t.ease}`,
        cursor: onClick ? 'pointer' : 'default',
        boxShadow: hover && onClick ? `0 16px 38px ${s.glow}0.34)` : `0 10px 26px ${s.glow}0.20)`,
        display: 'flex', flexDirection: 'column',
        alignItems: center ? 'center' : 'stretch', justifyContent: center ? 'center' : 'flex-start',
        textAlign: center ? 'center' : 'left',
      }}>
      {arrow && (
        <div style={{ position: 'absolute', top: 12, right: 12, width: 30, height: 30, borderRadius: '50%', background: 'rgba(255,255,255,0.22)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2 }}>
          <NIcon name="arrow_up_right" size={15} color={fg || s.on}/>
        </div>
      )}
      {children}
    </div>
  );
}

function TileLabel({ sem, children, style = {} }) {
  const s = SEM[sem] || SEM.lime;
  return <div style={{ fontFamily: MONO, fontSize: 9.5, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: s.on, opacity: 0.92, ...style }}>{children}</div>;
}
function TilePill({ sem, children }) {
  const s = SEM[sem] || SEM.lime;
  const white = sem === 'violet' || sem === 'coral';
  return <span style={{ display: 'inline-flex', alignItems: 'center', padding: '4px 9px', borderRadius: 99, background: white ? 'rgba(255,255,255,0.16)' : 'rgba(0,0,0,0.14)', fontFamily: MONO, fontSize: 10.5, color: s.on, letterSpacing: '0.02em' }}>{children}</span>;
}

// ── Expressive section heading (display font, big) ──
function ExpressiveHeading({ children }) {
  return <h2 style={{ margin: 0, fontFamily: DISPLAY, fontWeight: 700, fontSize: 26, letterSpacing: '-0.03em', color: NC.bone, lineHeight: 1 }}>{children}</h2>;
}

// ── Flow entry card — bold, mixed type, organic ──
function FlowCard({ sem, icon, kicker, title, sub, onClick, light, rot = 0 }) {
  const t = useTheme();
  const s = SEM[sem] || SEM.lime;
  const white = sem === 'violet' || sem === 'coral';
  const [press, setPress] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const sc = press ? 0.97 : (hover ? 1.025 : 1);
  const ty = (hover && !press) ? -3 : 0;
  return (
    <div
      onPointerDown={() => setPress(true)} onPointerUp={() => setPress(false)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => { setHover(false); setPress(false); }}
      onClick={onClick}
      className="n-card"
      style={{
        position: 'relative', overflow: 'hidden', cursor: 'pointer',
        background: s.fill, borderRadius: t.radii.xl, padding: '16px 16px 18px', minHeight: 168,
        transform: `translateY(${ty}px) rotate(${rot}deg) scale(${sc})`, transition: `transform ${t.dur(press ? 140 : 240)}ms ${press ? t.ease : t.spring}, box-shadow ${t.dur(240)}ms ${t.ease}`,
        boxShadow: hover ? `0 16px 40px ${s.glow}0.36)` : `0 10px 26px ${s.glow}0.22)`,
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      }}>
      <Blob color={white ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.10)'} size={150} variant={1} style={{ right: -44, bottom: -50 }}/>
      <div style={{ width: 44, height: 44, borderRadius: t.radii.md, background: white ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        <NIcon name={icon} size={22} color={s.on} strokeWidth={1.8}/>
      </div>
      <div style={{ position: 'relative' }}>
        <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.14em', textTransform: 'uppercase', color: s.mut }}>{kicker}</div>
        <div style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 24, lineHeight: 0.96, letterSpacing: '-0.03em', color: s.on, marginTop: 6, whiteSpace: 'pre-line' }}>{title}</div>
        <div style={{ fontSize: 12, color: s.mut, marginTop: 6 }}>{sub}</div>
      </div>
    </div>
  );
}

Object.assign(window, { BentoHome, BentoTile, ExpressiveHeading, FlowCard });

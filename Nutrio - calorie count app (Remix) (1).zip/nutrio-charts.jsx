// nutrio-charts.jsx — decorative, emotional data viz for the Expressive skin.
// Donut, colorful bar field, scalloped badge, sparkline. Storytelling > clinical.

// ── Donut: a thick ring with a hollow center, value label ──
function Donut({ pct = 0.62, size = 92, stroke = 13, color = '#0E1110', track = 'rgba(0,0,0,0.18)', children }) {
  const t = useTheme();
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const animPct = useCountUp(Math.round(pct * 100), t.dur(800), [pct]) / 100;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={track} strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={C} strokeDashoffset={C * (1 - animPct)}
          style={{ transition: `stroke-dashoffset ${t.dur(800)}ms ${t.ease}` }}/>
      </svg>
      {children && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{children}</div>}
    </div>
  );
}

// ── Multi-segment donut (macro split as one emotional ring) ──
function SegmentDonut({ segments, size = 96, stroke = 14, gap = 0.02 }) {
  const t = useTheme();
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const total = segments.reduce((s, x) => s + x.v, 0) || 1;
  let acc = 0;
  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={stroke}/>
      {segments.map((seg, i) => {
        const frac = seg.v / total;
        const len = Math.max(0, (frac - gap) * C);
        const off = -acc * C;
        acc += frac;
        return (
          <circle key={i} cx={size/2} cy={size/2} r={r} fill="none" stroke={seg.color} strokeWidth={stroke} strokeLinecap="round"
            strokeDasharray={`${len} ${C - len}`} strokeDashoffset={off}
            style={{ transition: `stroke-dasharray ${t.dur(700)}ms ${t.ease}` }}/>
        );
      })}
    </svg>
  );
}

// ── Decorative bar field — varied heights, optional multi-color, a "trend" feel ──
function BarField({ data, color, height = 64, gap = 3, rounded = true, highlightLast = true, palette }) {
  const t = useTheme();
  const max = Math.max(...data);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap, height }}>
      {data.map((v, i) => {
        const h = Math.max(8, (v / max) * height);
        const isLast = i === data.length - 1;
        const c = palette ? palette[i % palette.length] : color;
        return (
          <div key={i} style={{
            flex: 1, height: h, background: c,
            opacity: highlightLast ? (isLast ? 1 : 0.62) : 1,
            borderRadius: rounded ? '99px' : '3px',
            transformOrigin: 'bottom',
            animation: `barGrow ${t.dur(600)}ms ${t.ease} ${i * 35}ms both`,
          }}/>
        );
      })}
      <style>{`@keyframes barGrow{from{transform:scaleY(0.05);opacity:0}to{transform:scaleY(1)}}`}</style>
    </div>
  );
}

// ── Sparkline (smooth area) ──
function Sparkline({ data, color, w = 120, h = 40, fill = true }) {
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => [ (i / (data.length - 1)) * w, h - ((v - min) / range) * (h - 6) - 3 ]);
  const d = pts.map((p, i) => {
    if (i === 0) return `M${p[0]},${p[1]}`;
    const prev = pts[i-1];
    const cx = (prev[0] + p[0]) / 2;
    return `C${cx},${prev[1]} ${cx},${p[1]} ${p[0]},${p[1]}`;
  }).join(' ');
  const gid = 'spk' + color.replace(/[^a-z0-9]/gi, '');
  return (
    <svg width={w} height={h} style={{ display: 'block', overflow: 'visible' }}>
      <defs><linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={color} stopOpacity="0.35"/>
        <stop offset="100%" stopColor={color} stopOpacity="0"/>
      </linearGradient></defs>
      {fill && <path d={`${d} L${w},${h} L0,${h} Z`} fill={`url(#${gid})`}/>}
      <path d={d} fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="3.2" fill={color}/>
    </svg>
  );
}

// ── Scalloped badge (the AP "342k" stamp from the reference) ──
function ScallopBadge({ size = 120, fill, children, teeth = 14 }) {
  const cx = size/2, cy = size/2;
  const rOuter = size/2, rInner = size/2 - size*0.07;
  let path = '';
  const steps = teeth * 2;
  for (let i = 0; i <= steps; i++) {
    const ang = (i / steps) * Math.PI * 2 - Math.PI/2;
    const rr = i % 2 === 0 ? rOuter : rInner;
    const x = cx + Math.cos(ang) * rr, y = cy + Math.sin(ang) * rr;
    path += (i === 0 ? 'M' : 'L') + x.toFixed(1) + ',' + y.toFixed(1);
  }
  path += 'Z';
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ position: 'absolute', inset: 0 }}>
        <path d={path} fill={fill}/>
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>{children}</div>
    </div>
  );
}

// ── Blob — organic rounded shape for backgrounds ──
function Blob({ color, size = 160, style = {}, variant = 0 }) {
  const paths = [
    'M44,-58C56,-49,63,-33,67,-16C70,1,69,18,61,32C53,46,38,57,21,63C4,69,-15,70,-31,63C-47,56,-60,41,-66,23C-71,5,-69,-15,-60,-31C-51,-47,-35,-58,-18,-64C-1,-70,17,-71,44,-58Z',
    'M39,-52C53,-44,68,-35,72,-22C76,-9,69,8,60,23C51,38,40,51,25,58C10,65,-9,66,-26,60C-43,54,-58,40,-65,23C-72,6,-71,-14,-63,-30C-55,-46,-40,-58,-24,-64C-8,-70,9,-69,39,-52Z',
  ];
  return (
    <svg viewBox="-80 -80 160 160" width={size} height={size} style={{ position: 'absolute', pointerEvents: 'none', ...style }}>
      <path d={paths[variant % paths.length]} fill={color}/>
    </svg>
  );
}

Object.assign(window, { Donut, SegmentDonut, BarField, Sparkline, ScallopBadge, Blob });

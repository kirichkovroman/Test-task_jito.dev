// nutrio-data.jsx — food database + recipe catalog (window.FOODS, window.RECIPES, window.SEED_LOG)

// macro keys: k=kcal, p=protein, c=carbs, f=fat, fi=fiber  (per serving shown)
const FOODS = [
  { id: 'f1',  name: 'Greek yogurt with honey', brand: 'Fage · 170g',     icon: 'droplet', tone: 'peach', k: 180, p: 17, c: 22, f: 4,  fi: 0,  tags: ['Breakfast'] },
  { id: 'f2',  name: 'Grilled salmon fillet',    brand: 'Fresh · 140g',    icon: 'fish',    tone: 'peach', k: 280, p: 39, c: 0,  f: 13, fi: 0,  tags: ['Dinner'] },
  { id: 'f3',  name: 'Avocado toast',            brand: 'Sourdough · 1 slice', icon: 'leaf', tone: 'mint', k: 290, p: 8,  c: 30, f: 16, fi: 7,  tags: ['Breakfast'] },
  { id: 'f4',  name: 'Banana',                   brand: 'Medium · 118g',   icon: 'apple',   tone: 'lime',  k: 105, p: 1,  c: 27, f: 0,  fi: 3,  tags: ['Snacks'] },
  { id: 'f5',  name: 'Chicken caesar salad',     brand: 'Bowl · 320g',     icon: 'salad',   tone: 'lime',  k: 430, p: 35, c: 14, f: 26, fi: 4,  tags: ['Lunch'] },
  { id: 'f6',  name: 'Oatmeal with berries',     brand: 'Bowl · 250g',     icon: 'wheat',   tone: 'lime',  k: 240, p: 9,  c: 42, f: 5,  fi: 8,  tags: ['Breakfast'] },
  { id: 'f7',  name: 'Cold brew coffee',         brand: 'Black · 350ml',   icon: 'droplet', tone: 'peach', k: 5,   p: 0,  c: 1,  f: 0,  fi: 0,  tags: ['Snacks'] },
  { id: 'f8',  name: 'Beef & quinoa bowl',       brand: 'Bowl · 380g',     icon: 'beef',    tone: 'peach', k: 520, p: 42, c: 48, f: 18, fi: 9,  tags: ['Dinner','Lunch'] },
  { id: 'f9',  name: 'Almonds',                  brand: 'Handful · 28g',   icon: 'apple',   tone: 'mint',  k: 164, p: 6,  c: 6,  f: 14, fi: 4,  tags: ['Snacks'] },
  { id: 'f10', name: 'Two scrambled eggs',       brand: 'Large · 2 eggs',  icon: 'egg',     tone: 'peach', k: 180, p: 13, c: 2,  f: 13, fi: 0,  tags: ['Breakfast'] },
  { id: 'f11', name: 'Protein shake',            brand: 'Whey · 1 scoop',  icon: 'droplet', tone: 'lime',  k: 130, p: 25, c: 4,  f: 2,  fi: 1,  tags: ['Snacks'] },
  { id: 'f12', name: 'Lentil spinach soup',      brand: 'Bowl · 300g',     icon: 'salad',   tone: 'mint',  k: 220, p: 14, c: 30, f: 4,  fi: 11, tags: ['Lunch','Dinner'] },
];

// What the AI photo scanner "detects" — a composed plate broken into parts.
const SCAN_RESULT = {
  dish: 'Chicken & roasted veg bowl',
  confidence: 92,
  total: { k: 548, p: 44, c: 39, f: 22, fi: 8 },
  items: [
    { name: 'Grilled chicken breast', g: '150g', k: 248, conf: 96 },
    { name: 'Roasted sweet potato',   g: '120g', k: 130, conf: 90 },
    { name: 'Charred broccoli',       g: '90g',  k: 55,  conf: 88 },
    { name: 'Tahini drizzle',         g: '20g',  k: 115, conf: 71 },
  ],
};

// Barcode "scan" target
const BARCODE_RESULT = {
  name: 'Skyr vanilla',
  brand: 'Siggi’s · 150g tub',
  code: '8 94807 00219 4',
  k: 110, p: 15, c: 11, f: 0, fi: 0,
};

const RECIPE_FILTERS = {
  diet:  ['High-protein', 'Vegan', 'Keto', 'Low-carb', 'Gluten-free', 'Mediterranean'],
  goal:  ['Lose weight', 'Build muscle', 'Maintain', 'More energy'],
  time:  ['Under 15 min', '15–30 min', '30+ min'],
  macro: ['High fiber', 'Low fat', 'High protein', 'Low sugar'],
};

const RECIPES = [
  { id: 'r1', title: 'Lemon herb chicken bowl', k: 412, p: 38, c: 28, f: 16, fi: 6, min: 15, kcalLevel: 'lunch',
    grad: 'linear-gradient(150deg,#243016,#12180f)', accentHue: 'lime',
    diet: ['High-protein','Gluten-free'], goal: ['Build muscle','Maintain'], time: 'Under 15 min', macro: ['High protein'], rating: 4.8, fav: false,
    blurb: 'Bright, fast and high in lean protein — built for a weekday lunch.' },
  { id: 'r2', title: 'Miso salmon & wild rice', k: 486, p: 32, c: 41, f: 18, fi: 5, min: 22, kcalLevel: 'dinner',
    grad: 'linear-gradient(150deg,#2a1d12,#16100b)', accentHue: 'peach',
    diet: ['High-protein','Mediterranean'], goal: ['Build muscle','More energy'], time: '15–30 min', macro: ['High protein'], rating: 4.9, fav: true,
    blurb: 'Umami-glazed salmon over nutty wild rice. Omega-rich and filling.' },
  { id: 'r3', title: 'Green lentil power soup', k: 286, p: 18, c: 38, f: 6, fi: 12, min: 25, kcalLevel: 'lunch',
    grad: 'linear-gradient(150deg,#16241b,#0f140f)', accentHue: 'mint',
    diet: ['Vegan','Gluten-free'], goal: ['Lose weight','Maintain'], time: '15–30 min', macro: ['High fiber','Low fat'], rating: 4.6, fav: false,
    blurb: 'A fiber-dense bowl that holds you for hours, under 300 kcal.' },
  { id: 'r4', title: 'Avocado & egg breakfast', k: 340, p: 16, c: 24, f: 20, fi: 8, min: 10, kcalLevel: 'breakfast',
    grad: 'linear-gradient(150deg,#1f2a16,#13180f)', accentHue: 'lime',
    diet: ['Vegetarian','Low-carb'], goal: ['More energy','Maintain'], time: 'Under 15 min', macro: ['High fiber'], rating: 4.7, fav: false,
    blurb: 'Creamy avocado, soft egg, chili crunch. Ten minutes, zero fuss.' },
  { id: 'r5', title: 'Tofu poke & edamame', k: 388, p: 24, c: 36, f: 14, fi: 9, min: 18, kcalLevel: 'dinner',
    grad: 'linear-gradient(150deg,#16221f,#0f1413)', accentHue: 'mint',
    diet: ['Vegan'], goal: ['Lose weight','Build muscle'], time: '15–30 min', macro: ['High fiber','High protein'], rating: 4.5, fav: false,
    blurb: 'Plant-forward poke with a sesame-lime dressing and crisp edamame.' },
  { id: 'r6', title: 'Steak & chimichurri', k: 540, p: 46, c: 8, f: 34, fi: 3, min: 28, kcalLevel: 'dinner',
    grad: 'linear-gradient(150deg,#2a1614,#16100e)', accentHue: 'peach',
    diet: ['Keto','Low-carb','High-protein'], goal: ['Build muscle'], time: '15–30 min', macro: ['High protein','Low sugar'], rating: 4.9, fav: true,
    blurb: 'Seared sirloin with herby chimichurri. Keto-friendly and rich.' },
  { id: 'r7', title: 'Overnight oats & berries', k: 298, p: 14, c: 44, f: 7, fi: 9, min: 5, kcalLevel: 'breakfast',
    grad: 'linear-gradient(150deg,#221c2e,#14111c)', accentHue: 'iris',
    diet: ['Vegetarian','High-protein'], goal: ['More energy','Maintain'], time: 'Under 15 min', macro: ['High fiber'], rating: 4.4, fav: false,
    blurb: 'Prep tonight, grab tomorrow. Slow carbs to start the day steady.' },
  { id: 'r8', title: 'Halloumi & grain salad', k: 430, p: 22, c: 34, f: 22, fi: 7, min: 20, kcalLevel: 'lunch',
    grad: 'linear-gradient(150deg,#2a2412,#16130c)', accentHue: 'peach',
    diet: ['Vegetarian','Mediterranean'], goal: ['Maintain','More energy'], time: '15–30 min', macro: ['High fiber'], rating: 4.6, fav: false,
    blurb: 'Golden halloumi over herbed grains, lemon and pomegranate.' },
];

// Pre-logged meals for "today" so the dashboard isn't empty.
const byId = (id) => FOODS.find(f => f.id === id);
const SEED_LOG = [
  { ...byId('f10'), meal: 'Breakfast', time: '8:14 AM',  serving: 'Large · 2 eggs' },
  { ...byId('f6'),  meal: 'Breakfast', time: '8:14 AM',  serving: 'Bowl · 250g' },
  { ...byId('f4'),  meal: 'Snacks',    time: '11:02 AM', serving: 'Medium · 118g' },
  { ...byId('f5'),  meal: 'Lunch',     time: '1:30 PM',  serving: 'Bowl · 320g' },
];

Object.assign(window, { FOODS, RECIPES, RECIPE_FILTERS, SCAN_RESULT, BARCODE_RESULT, SEED_LOG });

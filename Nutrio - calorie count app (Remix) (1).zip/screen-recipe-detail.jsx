// screen-recipe-detail.jsx — full recipe detail (hero, macros, ingredients, steps, cook).

function RecipeDetail({ recipe, fav, onToggleFav, onBack, onCook }) {
  const t = useTheme();
  const hue = ACCENTS[recipe.accentHue] || t.accent;
  const s = recipeSem(recipe);
  const ac = t.brut ? s.fill : t.accent.a;
  const kAnim = useCountUp(recipe.k, t.dur(800), [recipe.id]);

  const ingredients = recipe.ingredients || DEFAULT_INGREDIENTS(recipe);
  const steps = recipe.steps || DEFAULT_STEPS(recipe);

  return (
    <div className="no-scrollbar" style={{ position: 'absolute', inset: 0, background: NC.canvas, overflowY: 'auto', zIndex: 150, animation: `nutrio-fade ${t.dur(220)}ms ${t.ease}`, paddingBottom: 120 }}>
      {/* hero */}
      <div style={{ position: 'relative', height: 320, background: recipe.grad }}>
        <BgDots opacity={0.09} size={15}/>
        {t.brut
          ? <Blob color={s.glow + '0.5)'} size={300} variant={0} style={{ right: -70, top: -60 }}/>
          : <TrajectoryArc w={260} h={260} stroke={hue.a} opacity={0.5} style={{ right: -50, top: -30 }} draw delay={120}/>}
        <div style={{ position: 'absolute', inset: 'auto 0 0 0', height: '55%', background: `linear-gradient(180deg, transparent, ${NC.canvas})` }}/>
        {/* top controls */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '54px 20px 0', display: 'flex', justifyContent: 'space-between' }}>
          <Press onClick={onBack} style={{ width: 40, height: 40, borderRadius: '50%', background: 'rgba(10,12,11,0.5)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,0.1)' }}>
            <NIcon name="arrow_left" size={18} color={NC.bone}/>
          </Press>
          <FavBtn fav={fav} onClick={(e) => { e.stopPropagation(); onToggleFav(); }}/>
        </div>
        {/* title block */}
        <div style={{ position: 'absolute', bottom: 18, left: 20, right: 20 }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
            {recipe.diet.slice(0, 2).map(d => t.brut
              ? <span key={d} style={{ display: 'inline-flex', alignItems: 'center', padding: '5px 10px', borderRadius: 99, background: s.fill, fontFamily: MONO, fontSize: 10, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase', color: s.on }}>{d}</span>
              : <MonoChip key={d} color={hue.a}>{d}</MonoChip>)}
          </div>
          <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontSize: t.brut ? 32 : 27, fontWeight: t.brut ? 700 : 600, color: NC.bone, letterSpacing: '-0.03em', lineHeight: t.brut ? 0.98 : 1.08 }}>{recipe.title}</div>
        </div>
      </div>

      {/* big number + key facts */}
      <div style={{ padding: '20px 20px 0', display: 'flex', alignItems: 'flex-end', gap: 16 }}>
        <div>
          <div style={{ fontFamily: MONO, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.04em', fontSize: Math.round(t.numHero * 0.62), lineHeight: 0.9 }}>{kAnim}</div>
          <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', color: ac, marginTop: 4 }}>kcal · per serving</div>
        </div>
        <div style={{ flex: 1, display: 'flex', gap: 8, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
          <Fact icon="clock" v={recipe.min + 'm'} l="time"/>
          <Fact icon="star" v={recipe.rating} l="rating"/>
        </div>
      </div>

      {/* macro split */}
      <div style={{ margin: '20px 20px 0', padding: 16, background: NC.surface, borderRadius: t.radii.lg }}>
        <MacroPills macros={recipe}/>
        <div style={{ display: 'flex', height: 6, borderRadius: 99, overflow: 'hidden', marginTop: 14, gap: 2 }}>
          {[['p',NC.protein],['c',NC.carbs],['f',NC.fat],['fi',NC.fiber]].map(([k,c])=>{
            const tot = recipe.p+recipe.c+recipe.f+recipe.fi || 1;
            return <div key={k} style={{ width: `${(recipe[k]/tot)*100}%`, background: c }}/>;
          })}
        </div>
      </div>

      {/* why it matches */}
      <div style={{ margin: '16px 20px 0', padding: 16, borderRadius: t.radii.lg, background: t.brut ? s.fill : t.accent.deep, border: t.brut ? 'none' : `1px solid ${t.accent.soft}`, display: 'flex', gap: 11 }}>
        <NIcon name="sparkles" size={17} color={t.brut ? s.on : t.accent.a} style={{ marginTop: 1, flexShrink: 0 }}/>
        <div style={{ fontSize: 13, color: t.brut ? s.on : NC.bone100, lineHeight: 1.5 }}>{recipe.blurb} Matches your <b style={{ color: t.brut ? s.on : t.accent.a, fontWeight: 700 }}>{recipe.goal[0].toLowerCase()}</b> goal.</div>
      </div>

      {/* ingredients */}
      <div style={{ padding: '24px 20px 0' }}>
        <SectionTitle style={{ padding: 0 }}>Ingredients · serves 2</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, borderRadius: t.radii.md, overflow: 'hidden' }}>
          {ingredients.map((ing, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '13px 14px', background: NC.surface }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: ac }}/>
                <span style={{ fontSize: 14, color: NC.bone }}>{ing.n}</span>
              </div>
              <span style={{ fontFamily: MONO, fontSize: 12, color: NC.bone300 }}>{ing.q}</span>
            </div>
          ))}
        </div>
      </div>

      {/* steps */}
      <div style={{ padding: '24px 20px 0' }}>
        <SectionTitle style={{ padding: 0 }}>Method</SectionTitle>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {steps.map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 14 }}>
              <div style={{ width: 30, height: 30, borderRadius: t.brut ? 9 : '50%', flexShrink: 0, background: t.brut ? ac : NC.surface, border: t.brut ? 'none' : `1px solid ${t.accent.soft}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: t.brut ? DISPLAY : MONO, fontSize: t.brut ? 15 : 13, color: t.brut ? s.on : t.accent.a, fontWeight: t.brut ? 700 : 500 }}>{i + 1}</div>
              <div style={{ fontSize: 14, color: NC.bone200, lineHeight: 1.55, paddingTop: 4 }}>{s}</div>
            </div>
          ))}
        </div>
      </div>

      {/* sticky cook CTA */}
      <div style={{ position: 'sticky', bottom: 0, marginTop: 24, padding: '14px 20px calc(18px + var(--safe-bottom))', background: `linear-gradient(180deg, transparent, ${NC.canvas} 26%)`, display: 'flex', gap: 10 }}>
        <PrimaryButton full big icon={<NIcon name="plus" size={19} color={t.accent.on} strokeWidth={2}/>} onClick={() => onCook(recipe)}>Add to today’s plan</PrimaryButton>
      </div>
    </div>
  );
}

function Fact({ icon, v, l }) {
  const t = useTheme();
  return (
    <div style={{ padding: '8px 12px', borderRadius: t.radii.md, background: NC.surface, border: `1px solid ${NC.border}`, display: 'flex', alignItems: 'center', gap: 7 }}>
      <NIcon name={icon} size={15} color={t.accent.a} fill={icon === 'star' ? t.accent.a : 'none'}/>
      <div style={{ fontFamily: MONO, fontSize: 13, fontWeight: 500, color: NC.bone, fontVariantNumeric: 'tabular-nums' }}>{v}</div>
      <div style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase', color: NC.bone300 }}>{l}</div>
    </div>
  );
}

function DEFAULT_INGREDIENTS(r) {
  return [
    { n: 'Main protein', q: '300 g' },
    { n: 'Mixed vegetables', q: '250 g' },
    { n: 'Whole grain or base', q: '160 g' },
    { n: 'Olive oil', q: '1 tbsp' },
    { n: 'Lemon, garlic & herbs', q: 'to taste' },
    { n: 'Sea salt & pepper', q: 'to taste' },
  ];
}
function DEFAULT_STEPS(r) {
  return [
    'Prep and season the protein, then heat a pan over medium-high with the olive oil.',
    'Sear until golden and cooked through, resting it while the vegetables roast or sauté.',
    'Build the base, layer everything into a bowl and finish with lemon, herbs and a pinch of salt.',
  ];
}

window.RecipeDetail = RecipeDetail;

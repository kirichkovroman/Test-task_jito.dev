// screen-extra.jsx — Saved (favorites) + You (profile). Lightweight tabs to complete the shell.

function SavedScreen({ favs, onToggleFav, onOpen }) {
  const t = useTheme();
  const list = RECIPES.filter(r => favs.includes(r.id));
  return (
    <div style={{ paddingBottom: 132, animation: `nutrio-fade ${t.dur(300)}ms ${t.ease}` }}>
      <div style={{ padding: '64px 20px 18px' }}>
        <div style={{ fontFamily: MONO, fontSize: 10, fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: NC.bone300 }}>YOUR COLLECTION</div>
        <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontWeight: t.brut ? 700 : 600, fontSize: t.brut ? 32 : 28, color: NC.bone, letterSpacing: '-0.03em', marginTop: 4 }}>Saved <span style={{ color: t.brut ? SEM.coral.fill : 'inherit', fontStyle: t.brut ? 'italic' : 'normal', fontFamily: t.brut ? SERIF : 'inherit', fontWeight: t.brut ? 400 : 'inherit' }}>recipes</span></div>
      </div>
      {list.length === 0 ? (
        <div style={{ padding: '40px', textAlign: 'center' }}>
          <div style={{ position: 'relative', width: 90, height: 90, margin: '0 auto 16px' }}>
            <TrajectoryArc w={90} h={90} opacity={0.6} style={{ inset: 0 }} draw/>
            <NIcon name="heart" size={30} color={NC.bone400} style={{ position: 'absolute', left: 30, top: 32 }}/>
          </div>
          <div style={{ fontSize: 16, fontWeight: 600, color: NC.bone }}>Nothing saved yet</div>
          <div style={{ fontSize: 13, color: NC.bone300, marginTop: 6, lineHeight: 1.5 }}>Tap the heart on any recipe to keep it here.</div>
        </div>
      ) : (
        <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {list.map(r => <FeedCard key={r.id} recipe={r} fav onToggleFav={() => onToggleFav(r.id)} onClick={() => onOpen(r)}/>)}
        </div>
      )}
    </div>
  );
}

function YouScreen({ log }) {
  const t = useTheme();
  const totalK = log.reduce((a, m) => a + m.k, 0);
  const goals = [
    { label: 'Daily calories', value: '2,000', unit: 'kcal', icon: 'flame', accent: true, sem: 'violet' },
    { label: 'Protein target', value: '110', unit: 'g', icon: 'dumbbell', sem: 'coral' },
    { label: 'Goal', value: 'Build', unit: 'muscle', icon: 'target', sem: 'lime' },
    { label: 'Activity', value: 'High', unit: '', icon: 'zap', sem: 'amber' },
  ];
  const settings = [
    { icon: 'target', label: 'Goals & macros' },
    { icon: 'bell', label: 'Reminders' },
    { icon: 'sliders', label: 'Units & display' },
    { icon: 'lock', label: 'Privacy' },
    { icon: 'info', label: 'About Nutrio' },
  ];
  return (
    <div style={{ paddingBottom: 132, animation: `nutrio-fade ${t.dur(300)}ms ${t.ease}` }}>
      {/* profile hero */}
      <div style={{ position: 'relative', padding: '64px 20px 22px', overflow: 'hidden' }}>
        {t.brut
          ? <Blob color={SEM.violet.glow + '0.5)'} size={240} variant={0} style={{ right: -70, top: -50 }}/>
          : <TrajectoryArc w={220} h={220} style={{ right: -60, top: -20 }} draw/>}
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 16 }}>
          <Avatar size={64}/>
          <div>
            <div style={{ fontFamily: t.brut ? DISPLAY : SANS, fontSize: t.brut ? 26 : 22, fontWeight: t.brut ? 700 : 600, color: NC.bone, letterSpacing: '-0.03em' }}>Alex Carter</div>
            <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.08em', color: NC.bone300, marginTop: 3 }}>5-day streak · since Mar 2026</div>
          </div>
        </div>
      </div>

      {/* goal tiles */}
      <div style={{ padding: '0 20px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {goals.map(g => t.brut
          ? <YouGoalTile key={g.label} g={g}/>
          : <StatTile key={g.label} label={g.label} value={g.value} unit={g.unit} accent={g.accent} icon={g.icon}/>
        )}
      </div>

      {/* settings list */}
      <SectionTitle>Settings</SectionTitle>
      <div style={{ padding: '0 20px' }}>
        <div style={{ borderRadius: t.radii.lg, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 1 }}>
          {settings.map(s => (
            <Press key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '15px 16px', background: NC.surface }}>
              <div style={{ width: 34, height: 34, borderRadius: t.radii.sm, background: NC.raised, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <NIcon name={s.icon} size={17} color={NC.bone200}/>
              </div>
              <span style={{ flex: 1, fontSize: 15, color: NC.bone, fontWeight: 500 }}>{s.label}</span>
              <NIcon name="chevron_right" size={18} color={NC.bone400}/>
            </Press>
          ))}
        </div>
      </div>
    </div>
  );
}

// expressive goal tile (You screen)
function YouGoalTile({ g }) {
  const t = useTheme();
  const s = SEM[g.sem] || SEM.lime;
  return (
    <div style={{ position: 'relative', overflow: 'hidden', background: s.fill, borderRadius: t.radii.xl, padding: 18, minHeight: 116, transform: `rotate(${g.sem === 'coral' || g.sem === 'amber' ? 0.7 : -0.7}deg)`, boxShadow: `0 10px 26px ${s.glow}0.2)`, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <Blob color={(s.key === 'violet' || s.key === 'coral') ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.1)'} size={120} variant={1} style={{ right: -34, bottom: -42 }}/>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative' }}>
        <div style={{ fontFamily: MONO, fontSize: 9.5, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: s.on, opacity: 0.92 }}>{g.label}</div>
        <NIcon name={g.icon} size={16} color={s.on}/>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, position: 'relative' }}>
        <span style={{ fontFamily: MONO, fontWeight: 500, fontSize: 32, color: s.on, letterSpacing: '-0.04em', lineHeight: 1 }}>{g.value}</span>
        {g.unit && <span style={{ fontFamily: MONO, fontSize: 12, color: s.on, opacity: 0.85 }}>{g.unit}</span>}
      </div>
    </div>
  );
}

Object.assign(window, { SavedScreen, YouScreen });
